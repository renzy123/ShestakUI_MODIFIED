local T, C, L = unpack(ShestakUI)
if C.pulsecooldown.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Based on Doom Cooldown Pulse(by Woffle of Dark Iron, editor Affli)
----------------------------------------------------------------------------------------
local GetTime = GetTime
local fadeInTime, fadeOutTime, maxAlpha, elapsed, runtimer = 0.5, 0.7, 1, 0, 0
local animScale, iconSize, holdTime, threshold = C.pulsecooldown.anim_scale, C.pulsecooldown.size, C.pulsecooldown.hold_time, C.pulsecooldown.threshold
local cooldowns, animating, watching = {}, {}, {}
local cdDetails = {}
local watchingCount = 0
local cooldownsCount = 0

-- Pre-allocated reusable table pool for animating entries (avoids per-event table creation)
local animEntryPool = {}
local animEntryCount = 0
local function acquireAnimEntry(texture, isPet, name)
	local t
	if animEntryCount > 0 then
		t = animEntryPool[animEntryCount]
		animEntryPool[animEntryCount] = nil
		animEntryCount = animEntryCount - 1
	else
		t = {}
	end
	t[1] = texture
	t[2] = isPet
	t[3] = name
	return t
end
local function releaseAnimEntry(t)
	if not t then return end
	t[1] = nil
	t[2] = nil
	t[3] = nil
	animEntryCount = animEntryCount + 1
	animEntryPool[animEntryCount] = t
end

local anchor = CreateFrame("Frame", "PulseCDAnchor", UIParent)
anchor:SetSize(C.pulsecooldown.size, C.pulsecooldown.size)
anchor:SetPoint(unpack(C.position.pulse_cooldown))

local frame = CreateFrame("Frame", "PulseCDFrame", anchor, BackdropTemplateMixin and "BackdropTemplate")
frame:SetScript("OnEvent", function(self, event, ...) self[event](self, ...) end)
frame:SetBackdrop({
	bgFile = C.media.blank, edgeFile = C.media.blank, edgeSize = T.noscalemult,
	insets = {left = -T.noscalemult, right = -T.noscalemult, top = -T.noscalemult, bottom = -T.noscalemult}
})
frame:SetBackdropBorderColor(unpack(C.media.border_color))
frame:SetBackdropColor(unpack(C.media.backdrop_color))
frame:SetPoint("CENTER", anchor, "CENTER")

local icon = frame:CreateTexture(nil, "ARTWORK")
icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
icon:SetPoint("TOPLEFT", frame, "TOPLEFT", T.noscalemult * 2, -T.noscalemult * 2)
icon:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -T.noscalemult * 2, T.noscalemult * 2)

-- Utility Functions
local function GetPetActionIndexByName(name)
	for i = 1, NUM_PET_ACTION_SLOTS, 1 do
		if GetPetActionInfo(i) == name then
			return i
		end
	end
	return nil
end

-- Cooldown/Animation
local function OnUpdate(_, update)
	elapsed = elapsed + update
	if elapsed > 0.05 then
		local now = GetTime()
		for i, v in pairs(watching) do
			if now >= v[1] + 0.5 then
				wipe(cdDetails)
				local hasDetails = false
				if v[2] == "spell" then
					local start, duration, enabled = GetSpellCooldown(v[3])
					cdDetails.name = GetSpellInfo(v[3])
					cdDetails.texture = GetSpellTexture(v[3])
					cdDetails.start = start
					cdDetails.duration = duration
					cdDetails.enabled = enabled
					cdDetails.cdType = "spell"
					cdDetails.id = v[3]
					hasDetails = true
				elseif v[2] == "item" then
					local start, duration, enabled = C_Container.GetItemCooldown(i)
					cdDetails.name = GetItemInfo(i)
					cdDetails.texture = v[3]
					cdDetails.start = start
					cdDetails.duration = duration
					cdDetails.enabled = enabled
					cdDetails.cdType = "item"
					cdDetails.id = i
					hasDetails = true
				elseif v[2] == "pet" then
					local name, texture = GetPetActionInfo(v[3])
					local start, duration, enabled = GetPetActionCooldown(v[3])
					cdDetails.name = name
					cdDetails.texture = texture
					cdDetails.isPet = true
					cdDetails.start = start
					cdDetails.duration = duration
					cdDetails.enabled = enabled
					cdDetails.cdType = "pet"
					cdDetails.id = v[3]
					hasDetails = true
				end
				if hasDetails then
					if (C.pulsecooldown.whitelist and not T.pulse_ignored_spells[cdDetails.name]) or (not C.pulsecooldown.whitelist and T.pulse_ignored_spells[cdDetails.name]) then
						watching[i] = nil
						watchingCount = watchingCount - 1
					else
						if cdDetails.enabled ~= 0 then
							if cdDetails.duration and cdDetails.duration > threshold and cdDetails.texture then
								-- Reuse existing table if possible instead of creating new one
								local cd = cooldowns[i]
								if not cd then
									cd = {}
									cooldowns[i] = cd
								end
								cd.name = cdDetails.name
								cd.texture = cdDetails.texture
								cd.isPet = cdDetails.isPet
								cd.start = cdDetails.start
								cd.duration = cdDetails.duration
								cd.enabled = cdDetails.enabled
								cd.cdType = cdDetails.cdType
								cd.id = cdDetails.id
								cooldownsCount = cooldownsCount + 1
							end
						end
						if not (cdDetails.enabled == 0 and v[2] == "spell") then
							watching[i] = nil
							watchingCount = watchingCount - 1
						end
					end
				end
			end
		end
		for i, cooldown in pairs(cooldowns) do
			local remaining = cooldown.duration - (now - cooldown.start)
			if remaining <= 0.2 then
				-- 从池中获取 entry，避免每次 tinsert 新建 table
				tinsert(animating, acquireAnimEntry(cooldown.texture, cooldown.isPet, cooldown.name))
				cooldowns[i] = nil
				cooldownsCount = cooldownsCount - 1
			end
		end

		elapsed = 0
		if #animating == 0 and watchingCount == 0 and cooldownsCount == 0 then
			frame:SetScript("OnUpdate", nil)
			return
		end
	end

	if #animating > 0 then
		runtimer = runtimer + update
		if runtimer > (fadeInTime + holdTime + fadeOutTime) then
			local finished = tremove(animating, 1)
			if finished then releaseAnimEntry(finished) end
			runtimer = 0
			icon:SetTexture(0)
			frame:SetBackdropBorderColor(0, 0, 0, 0)
			frame:SetBackdropColor(0, 0, 0, 0)
		else
			if not icon:GetTexture() then
				icon:SetTexture(animating[1][1])
				if C.pulsecooldown.sound == true then
					PlaySoundFile(C.media.proc_sound, "Master")
				end
			end
			local alpha = maxAlpha
			if runtimer < fadeInTime then
				alpha = maxAlpha * (runtimer / fadeInTime)
			elseif runtimer >= fadeInTime + holdTime then
				alpha = maxAlpha - (maxAlpha * ((runtimer - holdTime - fadeInTime) / fadeOutTime))
			end
			frame:SetAlpha(alpha)
			local scale = iconSize + (iconSize * ((animScale - 1) * (runtimer / (fadeInTime + holdTime + fadeOutTime))))
			frame:SetWidth(scale)
			frame:SetHeight(scale)
			frame:SetBackdropBorderColor(unpack(C.media.border_color))
			frame:SetBackdropColor(unpack(C.media.backdrop_color))
		end
	end
end

-- Event Handlers
function frame:ADDON_LOADED()
	for _, v in pairs(T.pulse_ignored_spells) do
		T.pulse_ignored_spells[v] = true
	end
	self:UnregisterEvent("ADDON_LOADED")
end
frame:RegisterEvent("ADDON_LOADED")

function frame:SPELL_UPDATE_COOLDOWN()
	for _, cd in pairs(cooldowns) do
		if cd.cdType == "spell" then
			cd.start, cd.duration, cd.enabled = GetSpellCooldown(cd.id)
		elseif cd.cdType == "item" then
			cd.start, cd.duration, cd.enabled = C_Container.GetItemCooldown(cd.id)
		elseif cd.cdType == "pet" then
			cd.start, cd.duration, cd.enabled = GetPetActionCooldown(cd.id)
		end
	end
end
frame:RegisterEvent("SPELL_UPDATE_COOLDOWN")

function frame:UNIT_SPELLCAST_SUCCEEDED(unit, _, spellID)
	local texture = GetSpellTexture(spellID)
	local t1 = GetInventoryItemTexture("player", 13)
	local t2 = GetInventoryItemTexture("player", 14)
	if texture == t1 or texture == t2 then return end -- Fix wrong buff cd for trinket
	if watching[spellID] == nil then watchingCount = watchingCount + 1 end
	watching[spellID] = {GetTime(), "spell", spellID}
	self:SetScript("OnUpdate", OnUpdate)
end
frame:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player", "")

-- CLEU handler for PulseCD — registered via shared dispatcher
local function OnCLEU_PulseCD()
	local _, eventType, _, _, _, sourceFlags, _, _, _, _, _, spellID = CombatLogGetCurrentEventInfo()
	if eventType ~= "SPELL_CAST_SUCCESS" then return end
	if (bit.band(sourceFlags, COMBATLOG_OBJECT_TYPE_PET) == COMBATLOG_OBJECT_TYPE_PET and bit.band(sourceFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) == COMBATLOG_OBJECT_AFFILIATION_MINE) then
		local name = GetSpellInfo(spellID)
		local index = GetPetActionIndexByName(name)
		if index and not select(7, GetPetActionInfo(index)) then
			if watching[spellID] == nil then watchingCount = watchingCount + 1 end
			watching[spellID] = {GetTime(), "pet", index}
		elseif not index and spellID then
			if watching[spellID] == nil then watchingCount = watchingCount + 1 end
			watching[spellID] = {GetTime(), "spell", spellID}
		else
			return
		end
		frame:SetScript("OnUpdate", OnUpdate)
	end
end
T.CLEU_Register("SPELL_CAST_SUCCESS", OnCLEU_PulseCD)

function frame:PLAYER_ENTERING_WORLD()
	local _, instanceType = IsInInstance()
	if instanceType == "arena" then
		self:SetScript("OnUpdate", nil)
		wipe(cooldowns)
		wipe(watching)
		cooldownsCount = 0
		watchingCount = 0
	end
end
frame:RegisterEvent("PLAYER_ENTERING_WORLD")

hooksecurefunc("UseAction", function(slot)
	local actionType, itemID = GetActionInfo(slot)
	if actionType == "item" then
		local texture = GetActionTexture(slot)
		if texture == 136235 then return end -- prevent temp icon
		if watching[itemID] == nil then watchingCount = watchingCount + 1 end
		watching[itemID] = {GetTime(), "item", texture}
	end
end)

hooksecurefunc("UseInventoryItem", function(slot)
	local itemID = GetInventoryItemID("player", slot)
	if itemID then
		local texture = GetInventoryItemTexture("player", slot)
		if texture == 136235 then return end -- prevent temp icon
		if watching[itemID] == nil then watchingCount = watchingCount + 1 end
		watching[itemID] = {GetTime(), "item", texture}
	end
end)

if T.Classic then
	hooksecurefunc(_G.C_Container, "UseContainerItem", function(bag, slot)
		local itemID = C_Container.GetContainerItemID(bag, slot)
		if itemID then
			local texture = select(10, GetItemInfo(itemID))
			if texture == 136235 then return end -- prevent temp icon
			if watching[itemID] == nil then watchingCount = watchingCount + 1 end
			watching[itemID] = {GetTime(), "item", texture}
		end
	end)
end

SlashCmdList.PulseCD = function()
	tinsert(animating, {GetSpellTexture(87214)})
	if C.pulsecooldown.sound == true then
		PlaySoundFile(C.media.proc_sound, "Master")
	end
	frame:SetScript("OnUpdate", OnUpdate)
end
SLASH_PulseCD1 = "/pulsecd"
SLASH_PulseCD2 = "/згдыусв"
