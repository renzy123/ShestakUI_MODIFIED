local T, C, L = unpack(ShestakUI)

-- Localize frequently used globals for performance
local InCombatLockdown = InCombatLockdown
local UnitIsPlayer = UnitIsPlayer
local UnitIsConnected = UnitIsConnected
local UnitClass = UnitClass
local GetSpellInfo = GetSpellInfo
local GetSpellBonusDamage = GetSpellBonusDamage
local UnitBuff = UnitBuff

-- Cache constant spell names
local SPELL_FROST_PRESENCE = GetSpellInfo(48263)
local SPELL_SHAMAN_TANK = T.SoD and GetSpellInfo(408680)
local SPELL_WARLOCK_TANK = T.SoD and GetSpellInfo(403789)

----------------------------------------------------------------------------------------
--	Specialization Functions
----------------------------------------------------------------------------------------
function T.GetSpecialization(isInspect, isPet, specGroup)
	if T.Cata then
		return GetPrimaryTalentTree(isInspect, isPet, specGroup)
	else
		if (isInspect or isPet) then
			return
		end
		local specIndex
		local max = 0
		local numTabs = GetNumTalentTabs() or 0
		
		-- 添加安全检查，避免获取到nil值
		if numTabs > 0 then
			for tabIndex = 1, numTabs do
				-- 获取天赋点数，添加安全检查
				local _, _, spent = GetTalentTabInfo(tabIndex, "player", T.Wrath and specGroup)
				
				-- 修复：检查spent是否为有效数字
				if spent and type(spent) == "number" and spent > max then
					specIndex = tabIndex
					max = spent
				end
			end
		end
		return specIndex
	end
end

local isCaster = {
	DEATHKNIGHT = {nil, nil, nil},
	DRUID = {true},					-- Balance
	HUNTER = {nil, nil, nil},
	MAGE = {true, true, true},
	PALADIN = {nil, nil, nil},
	PRIEST = {nil, nil, true},		-- Shadow
	ROGUE = {nil, nil, nil},
	SHAMAN = {true},				-- Elemental
	WARLOCK = {true, true, true},
	WARRIOR = {nil, nil, nil}
}

function T.GetSpecializationRole()
	-- TODO: Use IsSpellKnownOrOverridesKnown instead for checking rune slot spellIDs
	local tree = T.GetSpecialization()
	
	-- 添加安全检查
	if not tree then
		-- 如果无法确定天赋，返回默认值
		return "MELEE"
	end
	
	-- eventually check for tank stats in case a tanking in a non-traditional spec (mostly for warriors)
	if (T.class == "DEATHKNIGHT" and T.CheckPlayerBuff(SPELL_FROST_PRESENCE))
	or (T.class == "DRUID" and GetBonusBarOffset() == 3)
	or (T.class == "PALADIN" and tree == 2)
	or (T.class == "ROGUE" and T.SoD and IsPlayerSpell(410412))
	or (T.class == "SHAMAN" and T.SoD and T.CheckPlayerBuff(SPELL_SHAMAN_TANK))
	or (T.class == "WARLOCK" and T.SoD and T.CheckPlayerBuff(SPELL_WARLOCK_TANK))
	or (T.class == "WARRIOR" and (tree == 3 or GetBonusBarOffset() == 2)) then
		return "TANK"
	elseif (T.class == "PALADIN" and tree == 1) or (T.class == "DRUID" and tree == 3) or (T.class == "SHAMAN" and tree == 3) or (T.class == "PRIEST" and tree ~= 3) then
		return "HEALER"
	else
		local base, posBuff, negBuff = UnitAttackPower("player")

		local best, bestVal = 1, 0
		for i = 1, 7 do
			local val = GetSpellBonusDamage(i) or 0
			if val > bestVal then
				best = i
				bestVal = val
			end
		end
		local spell = bestVal
		local ap = base + posBuff + negBuff
		local heal = GetSpellBonusHealing() or 0

		if T.class ~= "HUNTER" and heal >= ap and heal >= spell then
			return "HEALER" -- healing gear without having the majority of talents in a healing tree
		elseif T.class ~= "HUNTER" and (isCaster[T.class] and isCaster[T.class][tree] or spell >= ap) then
			return "CASTER" -- ordinarily "DAMAGER"
		else
			return "MELEE" -- ordinarily "DAMAGER"
		end
	end
end

----------------------------------------------------------------------------------------
--	Check if Classic or Burning Crusade Classic / Wrath of the Lich King Classic
----------------------------------------------------------------------------------------
if not T.Vanilla then return end

----------------------------------------------------------------------------------------
--	LibClassicDurations (by d87)
----------------------------------------------------------------------------------------
local LibClassicDurations = LibStub("LibClassicDurations")
if LibClassicDurations then
	LibClassicDurations:Register("ShestakUI")
end

----------------------------------------------------------------------------------------
--	TBC+ Shaman Coloring (config option later)
----------------------------------------------------------------------------------------
if not CUSTOM_CLASS_COLORS then
	local r, g, b, colorStr = 0, 0.44, 0.98, "ff0070de"

	-- for ShestakUI coloring
	if T.class == "SHAMAN" then
		T.color = {}
		T.color.r = r
		T.color.g = g
		T.color.b = b
		T.color.colorStr = colorStr

		if C and C.media then
			C.media.classborder_color = {T.color.r, T.color.g, T.color.b, 1}
		end
	end

	-- 泰坦80级适配：简化版着色函数
	local function UpdateShamanColors()
		if T.class == "SHAMAN" then
			T.color = {}
			T.color.r = r
			T.color.g = g
			T.color.b = b
			T.color.colorStr = colorStr
			
			if C and C.media then
				C.media.classborder_color = {T.color.r, T.color.g, T.color.b, 1}
			end
		end
	end

	hooksecurefunc("CompactUnitFrame_UpdateHealthColor", function(frame)
		-- Skip during combat to avoid taint propagation on 3.80.1
		if InCombatLockdown() then return end
		local opts = frame.optionTable
		if opts.healthBarColorOverride or not opts.useClassColors
				or not (opts.allowClassColorsForNPCs or UnitIsPlayer(frame.unit))
				or not UnitIsConnected(frame.unit) then
			return
		end

		local _, class = UnitClass(frame.unit)
		if not class or class ~= "SHAMAN" then return end

		frame.healthBar:SetStatusBarColor(r, g, b)
		if frame.optionTable.colorHealthWithExtendedColors then
			frame.selectionHighlight:SetVertexColor(r, g, b)
		end
	end)
end