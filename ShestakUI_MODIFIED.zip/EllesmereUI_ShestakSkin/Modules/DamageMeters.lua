-------------------------------------------------------------------------------
--  EllesmereUI_ShestakSkin - Modules/DamageMeters.lua
--  伤害统计美化模块：1px 像素边框、平滑 Flat 状态条、暗色底槽与紧凑标题栏
-------------------------------------------------------------------------------
local ADDON_NAME, ns = ...
local SK = ns.SK

-- 像素对齐微调间距常量
local HEADER_GAP = 2 -- 标题栏与第一行统计之间的垂直像素间距

-- 1. 美化单个状态条（伤害统计主行、技能明细行、置顶玩家行）
local function SkinBar(bar)
    if not bar or not bar.row or not bar.fill then return end

    -- (1) 强制设置状态条平滑材质 (Shestak Flat)
    bar.fill:SetStatusBarTexture(SK.Texture)
    local barTex = bar.fill:GetStatusBarTexture()
    if barTex then
        barTex:SetTexture(SK.Texture)
    end

    -- (2) 隐藏 Ellesmere 原生可能自带的多余边框与底色
    if bar._borderFrame then bar._borderFrame:Hide() end
    if bar._fillBorder then bar._fillBorder:Hide() end
    if bar._iconBorderFrame then bar._iconBorderFrame:Hide() end
    if bar._bg then bar._bg:SetAlpha(0) end

    -- 挂钩原生边框刷新函数，防止原生逻辑在刷新时重新显示旧边框
    if not bar._shetsakHooked then
        bar._shetsakHooked = true
        if bar.ApplyBorder then
            hooksecurefunc(bar, "ApplyBorder", function()
                if bar._borderFrame then bar._borderFrame:Hide() end
                if bar._fillBorder then bar._fillBorder:Hide() end
            end)
        end
        if bar.ApplyIconBorder then
            hooksecurefunc(bar, "ApplyIconBorder", function()
                if bar._iconBorderFrame then bar._iconBorderFrame:Hide() end
            end)
        end
        if bar.ApplyBg then
            hooksecurefunc(bar, "ApplyBg", function()
                if bar._bg then bar._bg:SetAlpha(0) end
            end)
        end
    end

    -- (3) 创建统一槽位底色（暗色半透明底槽）
    if not bar.shestakBg then
        bar.shestakBg = bar.row:CreateTexture(nil, "BACKGROUND", nil, -7)
        bar.shestakBg:SetAllPoints(bar.fill)
        bar.shestakBg:SetTexture(SK.Texture)
        bar.shestakBg:SetVertexColor(0.08, 0.08, 0.08, 0.6)
    end

    -- (4) 创建 1px 黑色像素边框（整体包裹专精/职业图标与状态条）
    if not bar.shestakBackdrop then
        local backdrop = CreateFrame("Frame", nil, bar.row)
        backdrop:SetFrameLevel(bar.row:GetFrameLevel() + 1)
        SK:CreatePixelBorder(backdrop)
        bar.shestakBackdrop = backdrop
    end

    -- 根据专精/职业图标的显示状态动态调整边框包裹范围
    local icon = bar.classIcon
    bar.shestakBackdrop:ClearAllPoints()
    if icon and icon:IsShown() then
        -- 图标边缘裁剪（去黑边与圆角）
        SK:CropIcon(icon)
        bar.shestakBackdrop:SetPoint("TOPLEFT", icon, -1, 1)
        bar.shestakBackdrop:SetPoint("BOTTOMRIGHT", bar.fill, 1, -1)
    else
        bar.shestakBackdrop:SetPoint("TOPLEFT", bar.fill, -1, 1)
        bar.shestakBackdrop:SetPoint("BOTTOMRIGHT", bar.fill, 1, -1)
    end

    -- (5) 字体大小统一为 8px，保持左右各 2px 内间距
    local function SetFontSize8(fs)
        if not fs or not fs.GetFont then return end
        local fontPath, _, flags = fs:GetFont()
        if fontPath then
            fs:SetFont(fontPath, 8, flags or "")
        end
    end

    local function ApplyShestakTextOffsets()
        if bar.pos then
            bar.pos:ClearAllPoints()
            bar.pos:SetPoint("LEFT", bar.fill, "LEFT", 2, 0)
            SetFontSize8(bar.pos)
        end
        if bar.amount then
            bar.amount:ClearAllPoints()
            bar.amount:SetPoint("RIGHT", bar.fill, "RIGHT", -2, 0)
            SetFontSize8(bar.amount)
        end
        if bar.label then
            bar.label:ClearAllPoints()
            if bar.pos and bar.pos:GetText() and bar.pos:GetText() ~= "" then
                bar.label:SetPoint("LEFT", bar.pos, "RIGHT", 2, 0)
            else
                bar.label:SetPoint("LEFT", bar.fill, "LEFT", 2, 0)
            end
            if bar.amount then
                bar.label:SetPoint("RIGHT", bar.amount, "LEFT", -2, 0)
            else
                bar.label:SetPoint("RIGHT", bar.fill, "RIGHT", -2, 0)
            end
            SetFontSize8(bar.label)
        end
    end

    -- 覆盖原生的文本偏移逻辑
    bar.ApplyTextOffsets = ApplyShestakTextOffsets
    ApplyShestakTextOffsets()
end

-- 2. 状态更新：持续确保原生底色与原生边框隐藏，维持标题与文本样式及 2px 间距
local function UpdateWindowState(W)
    if not W or not W.frame then return end
    local frame = W.frame
    local header = W.header

    -- 确保原生底色和原生外边框始终隐藏，防止原生逻辑在配置变更时重新显示
    if frame._bg then frame._bg:SetAlpha(0) end
    if W.windowBorderTarget then W.windowBorderTarget:Hide() end
    if W.sourceFrame and W.sourceFrame._bg then W.sourceFrame._bg:SetAlpha(0) end
    if header and header._hdrBg then header._hdrBg:SetAlpha(0) end
    if header and header._bottomBorder then header._bottomBorder:SetAlpha(0) end

    -- 重新应用标题栏文本与图标样式（10px 文本与 12px 图标）
    if W.ApplyHeaderStyling then
        W.ApplyHeaderStyling()
    end

    -- 维持标题行与首行统计之间的 2px 垂直间距
    if W.viewport and header then
        local numPoints = W.viewport:GetNumPoints()
        for pIdx = 1, numPoints do
            local point, relTo, relPoint, x, y = W.viewport:GetPoint(pIdx)
            if point == "TOPLEFT" and relTo == header and relPoint == "BOTTOMLEFT" and (y or 0) > -HEADER_GAP then
                W.viewport:SetPoint("TOPLEFT", header, "BOTTOMLEFT", x or 0, -HEADER_GAP)
                break
            end
        end
    end
    if W.sourceFrame and header then
        local numPoints = W.sourceFrame:GetNumPoints()
        for pIdx = 1, numPoints do
            local point, relTo, relPoint, x, y = W.sourceFrame:GetPoint(pIdx)
            if point == "TOPLEFT" and relTo == header and relPoint == "BOTTOMLEFT" and (y or 0) > -HEADER_GAP then
                W.sourceFrame:SetPoint("TOPLEFT", header, "BOTTOMLEFT", x or 0, -HEADER_GAP)
                break
            end
        end
    end
end

-- 3. 美化单个伤害统计窗口（支持最多 5 个多实例窗口）
local function SkinWindow(W)
    if not W or not W.frame then return end

    local frame = W.frame
    local header = W.header

    -- 首次美化初始化
    if not W._shetsakSkinned then
        W._shetsakSkinned = true

        -- (1) 主窗口外边框与半透明暗底 (1px 像素边框与暗黑半透明背景)
        SK:CreateBackdrop(frame, 0.85)

        -- (2) 标题栏背景美化与底部 1px 像素分界线
        if header then
            -- 标题栏暗色底板：使用纯色纹理填充，不使用带左右边框的样式
            if not header.shestakBg then
                local hBg = header:CreateTexture(nil, "BACKGROUND", nil, -5)
                hBg:SetAllPoints(header)
                hBg:SetTexture(SK.Blank)
                hBg:SetVertexColor(0.1, 0.1, 0.1, 1)
                header.shestakBg = hBg
            end

            -- 标题栏底部边框美化：创建 1px 黑色像素分界线，横向贴合两端
            if not header.shestakBottomBorder then
                local bBorder = header:CreateTexture(nil, "OVERLAY", nil, 7)
                bBorder:SetTexture(SK.Blank)
                bBorder:SetVertexColor(SK.BorderColor[1], SK.BorderColor[2], SK.BorderColor[3], SK.BorderColor[4])
                bBorder:SetPoint("BOTTOMLEFT", header, "BOTTOMLEFT", 0, 0)
                bBorder:SetPoint("BOTTOMRIGHT", header, "BOTTOMRIGHT", 0, 0)
                bBorder:SetHeight(1)
                header.shestakBottomBorder = bBorder
            end
            header.shestakBottomBorder:Show()

            -- 隐藏原生纯色背景与原生边线
            if header._hdrBg then header._hdrBg:SetAlpha(0) end
            if header._bottomBorder then header._bottomBorder:SetAlpha(0) end
        end

        -- (3) 标题栏文本（10px）与图标大小（12px）调整
        local function ApplyHeaderStyling()
            if not SK:IsModuleEnabled("damagemeters") then return end
            local cfg = SK.db and SK.db.damagemeters
            local isCompact = not cfg or cfg.compactHeader ~= false

            local fontSz = isCompact and 10 or 12
            local iconSz = isCompact and 12 or 14

            if W.titleText and W.titleText.GetFont then
                local font, _, flags = W.titleText:GetFont()
                if font then
                    W.titleText:SetFont(font, fontSz, flags or "")
                end
            end
            if W.timerText and W.timerText.GetFont then
                local font, _, flags = W.timerText:GetFont()
                if font then
                    W.timerText:SetFont(font, fontSz, flags or "")
                end
            end

            local btnPad = 2
            if W.hdrBtns then
                local bi = 0
                for _, btn in ipairs(W.hdrBtns) do
                    if btn:IsShown() then
                        bi = bi + 1
                        btn:SetSize(iconSz, iconSz)
                        btn:ClearAllPoints()
                        btn:SetPoint("RIGHT", W.header, "RIGHT", -(iconSz * (bi - 1) + btnPad * bi + 2), 0)
                    end
                end
            end
            if W.hdrIcons then
                for _, icon in ipairs(W.hdrIcons) do
                    icon:SetSize(iconSz, iconSz)
                end
            end
            if W._closeIconTex then
                W._closeIconTex:SetSize(iconSz, iconSz)
            end
            if W.FitTitle then
                W.FitTitle()
            end
        end

        W.ApplyHeaderStyling = ApplyHeaderStyling

        -- (4) 批量美化已有行池（主窗口 rowPool 和 技能池 spellPool）
        if W.rowPool then
            for _, bar in ipairs(W.rowPool) do
                SkinBar(bar)
            end
        end
        if W.spellPool then
            for _, bar in ipairs(W.spellPool) do
                SkinBar(bar)
            end
        end
        if W.stickyPlayer then
            SkinBar(W.stickyPlayer)
        end

        -- (5) 挂钩窗口刷新，确保数据更新、增量渲染时美化实时维持
        if W.Refresh then
            hooksecurefunc(W, "Refresh", function()
                ApplyHeaderStyling()
                if W.rowPool then
                    for _, bar in ipairs(W.rowPool) do
                        if bar.row and bar.row:IsShown() then
                            SkinBar(bar)
                            if bar.ApplyTextOffsets then
                                bar.ApplyTextOffsets()
                            end
                        end
                    end
                end
                if W.spellPool then
                    for _, bar in ipairs(W.spellPool) do
                        if bar.row and bar.row:IsShown() then
                            SkinBar(bar)
                            if bar.ApplyTextOffsets then
                                bar.ApplyTextOffsets()
                            end
                        end
                    end
                end
                if W.stickyPlayer and W.stickyPlayer.row and W.stickyPlayer.row:IsShown() then
                    SkinBar(W.stickyPlayer)
                    if W.stickyPlayer.ApplyTextOffsets then
                        W.stickyPlayer.ApplyTextOffsets()
                    end
                end
            end)
        end

        -- (6) 调整视口与首行统计间距（标题行和第一行统计之间保持 2px 间距）
        if W.viewport and not W.viewport._shestakGapHooked then
            W.viewport._shestakGapHooked = true
            local isAdjustingViewport = false
            hooksecurefunc(W.viewport, "SetPoint", function(self, point, relTo, relPoint, x, y)
                if isAdjustingViewport then return end
                if point == "TOPLEFT" and relTo == header and relPoint == "BOTTOMLEFT" then
                    isAdjustingViewport = true
                    self:SetPoint("TOPLEFT", header, "BOTTOMLEFT", x or 0, (y or 0) - HEADER_GAP)
                    isAdjustingViewport = false
                end
            end)
            isAdjustingViewport = true
            W.viewport:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -HEADER_GAP)
            isAdjustingViewport = false
        end

        -- 置顶玩家行：TOPLEFT 同样向下偏移 2px
        if W.stickyPlayer and W.stickyPlayer.row and not W.stickyPlayer.row._shestakGapHooked then
            W.stickyPlayer.row._shestakGapHooked = true
            local isAdjustingSticky = false
            hooksecurefunc(W.stickyPlayer.row, "SetPoint", function(self, point, relTo, relPoint, x, y)
                if isAdjustingSticky then return end
                if point == "TOPLEFT" and relTo == header and relPoint == "BOTTOMLEFT" then
                    isAdjustingSticky = true
                    self:SetPoint("TOPLEFT", header, "BOTTOMLEFT", x or 0, (y or 0) - HEADER_GAP)
                    isAdjustingSticky = false
                end
            end)
        end

        -- 来源技能明细视口容器：同样向下偏移 2px
        if W.sourceFrame and not W.sourceFrame._shestakGapHooked then
            W.sourceFrame._shestakGapHooked = true
            local isAdjustingSource = false
            hooksecurefunc(W.sourceFrame, "SetPoint", function(self, point, relTo, relPoint, x, y)
                if isAdjustingSource then return end
                if point == "TOPLEFT" and relTo == header and relPoint == "BOTTOMLEFT" then
                    isAdjustingSource = true
                    self:SetPoint("TOPLEFT", header, "BOTTOMLEFT", x or 0, (y or 0) - HEADER_GAP)
                    isAdjustingSource = false
                end
            end)
            isAdjustingSource = true
            W.sourceFrame:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -HEADER_GAP)
            isAdjustingSource = false
        end

        -- 挂钩来源技能详情刷新，保证技能明细行同样应用 1px 边框与平滑材质
        if W.RefreshBreakdown then
            hooksecurefunc(W, "RefreshBreakdown", function()
                if W.spellPool then
                    for _, bar in ipairs(W.spellPool) do
                        if bar.row and bar.row:IsShown() then
                            SkinBar(bar)
                            if bar.ApplyTextOffsets then
                                bar.ApplyTextOffsets()
                            end
                        end
                    end
                end
            end)
        end

        -- 挂钩主页选择，切换模式时维持标题与边框样式
        if W.ShowHome then
            hooksecurefunc(W, "ShowHome", function()
                UpdateWindowState(W)
            end)
        end

        -- 挂钩新建窗口按钮点击，在点击新增窗口的第一时间调度美化扫描
        if W.winActionBtn and not W.winActionBtn._shestakHooked then
            W.winActionBtn._shestakHooked = true
            W.winActionBtn:HookScript("OnClick", function()
                C_Timer.After(0.01, function()
                    SK:ApplyDamageMetersSkin()
                end)
            end)
        end

        SK:Log("成功美化伤害统计窗口 [%s]", tostring(W.idx or "?"))
    end

    -- 维持当前样式
    UpdateWindowState(W)
end

-- 4. 主执行函数：扫描并美化所有活跃窗口实例
function SK:ApplyDamageMetersSkin()
    if not self:IsModuleEnabled("damagemeters") then return 0 end

    local skinnedCount = 0
    local EUI = _G.EllesmereUI
    local edmNS = EUI and EUI._ModuleNS and EUI._ModuleNS["EllesmereUIDamageMeters"]
    local windows = edmNS and edmNS._windows

    -- 挂钩 EllesmereUIDamageMeters 原生生命周期函数
    if edmNS and not edmNS._shetsakLifecycleHooked then
        edmNS._shetsakLifecycleHooked = true

        if edmNS.ApplyWindowBorder then
            hooksecurefunc(edmNS, "ApplyWindowBorder", function()
                SK:ApplyDamageMetersSkin()
            end)
        end
        if edmNS.RegisterDMUnlock then
            hooksecurefunc(edmNS, "RegisterDMUnlock", function()
                SK:ApplyDamageMetersSkin()
            end)
        end
        if edmNS.ApplyHeader then
            hooksecurefunc(edmNS, "ApplyHeader", function()
                SK:ApplyDamageMetersSkin()
            end)
        end
        if edmNS.ApplyBackground then
            hooksecurefunc(edmNS, "ApplyBackground", function()
                SK:ApplyDamageMetersSkin()
            end)
        end
        if edmNS.ApplyBarTextOffsets then
            hooksecurefunc(edmNS, "ApplyBarTextOffsets", function()
                SK:ApplyDamageMetersSkin()
            end)
        end
    end

    -- 挂钩全局配置重置与 Profile 重建函数
    if _G._EDM_Apply and not _G._EDM_Apply_shetsakHooked then
        _G._EDM_Apply_shetsakHooked = true
        hooksecurefunc(_G, "_EDM_Apply", function()
            C_Timer.After(0.05, function()
                SK:ApplyDamageMetersSkin()
            end)
        end)
    end

    -- 扫描 _windows 表
    if windows then
        for _, W in ipairs(windows) do
            if W and W.frame then
                if not W._shetsakSkinned then
                    skinnedCount = skinnedCount + 1
                end
                SkinWindow(W)
            end
        end
    end

    -- 兜底扫描全局 Frame 对象 EllesmereUIDMFrame1 ~ EllesmereUIDMFrame5
    for i = 1, 5 do
        local frame = _G["EllesmereUIDMFrame" .. i]
        if frame then
            if not frame._shetsakOnShowHooked then
                frame._shetsakOnShowHooked = true
                frame:HookScript("OnShow", function()
                    SK:ApplyDamageMetersSkin()
                end)
            end

            local targetW = windows and windows[i]
            if targetW then
                if not targetW._shetsakSkinned then
                    skinnedCount = skinnedCount + 1
                end
                SkinWindow(targetW)
            elseif not frame._shetsakSkinned then
                frame._shetsakSkinned = true
                SK:CreateBackdrop(frame, 0.85)
                if frame._bg then frame._bg:SetAlpha(0) end
                skinnedCount = skinnedCount + 1
            end
        end
    end

    return skinnedCount
end

-- 模块事件加载与异步监控
local dmWatcher = CreateFrame("Frame")
dmWatcher:RegisterEvent("PLAYER_LOGIN")
dmWatcher:RegisterEvent("PLAYER_ENTERING_WORLD")
dmWatcher:RegisterEvent("ADDON_LOADED")

dmWatcher:SetScript("OnEvent", function(self, event, addon)
    if event == "ADDON_LOADED" and addon ~= "EllesmereUIDamageMeters" and addon ~= "EllesmereUI" and addon ~= ADDON_NAME then
        return
    end

    -- 延迟执行，确保 EllesmereUI 异步窗口创建完毕
    C_Timer.After(0.3, function()
        local count = SK:ApplyDamageMetersSkin()
        if count > 0 and not dmWatcher.logged then
            dmWatcher.logged = true
            SK:Log("伤害统计美化已激活 (已适配 %d 个窗口)", count)
        end
    end)
end)

-- 轻量轮询检测（最多 10 秒，每秒 1 次，确保捕获延迟创建的窗口）
local pollCount = 0
C_Timer.NewTicker(1.0, function(self)
    pollCount = pollCount + 1
    local count = SK:ApplyDamageMetersSkin()
    if count > 0 and not dmWatcher.logged then
        dmWatcher.logged = true
        SK:Log("伤害统计美化已激活 (已适配 %d 个窗口)", count)
    end
    if pollCount >= 10 then
        self:Cancel()
    end
end)
