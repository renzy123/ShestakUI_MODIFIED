local T, C, L = unpack(ShestakUI)
if C.skins.bigwigs ~= true then return end

----------------------------------------------------------------------------------------
--	BigWigs skin(by Affli)
----------------------------------------------------------------------------------------
-- Init some tables to store backgrounds
local freebg = {}

-- Styling functions
local createbg = function()
	local bg = CreateFrame("Frame")
	bg:SetTemplate("Default")
	return bg
end

local function freestyle(bar)
	-- Reparent and hide bar background
	local bg = bar:Get("bigwigs:shestakui:bg")
	if bg then
		bg:ClearAllPoints()
		bg:SetParent(UIParent)
		bg:Hide()
		freebg[#freebg + 1] = bg
	end

	-- Reparent and hide icon background
	local ibg = bar:Get("bigwigs:shestakui:ibg")
	if ibg then
		ibg:ClearAllPoints()
		ibg:SetParent(UIParent)
		ibg:Hide()
		freebg[#freebg + 1] = ibg
	end

	-- Replace dummies with original method functions
	bar.candyBarBar.SetPoint = bar.candyBarBar.OldSetPoint
	bar.candyBarIconFrame.SetWidth = bar.candyBarIconFrame.OldSetWidth
	bar.SetScale = bar.OldSetScale

	-- Reset Positions
	-- Icon
	bar.candyBarIconFrame:ClearAllPoints()
	bar.candyBarIconFrame:SetPoint("TOPLEFT")
	bar.candyBarIconFrame:SetPoint("BOTTOMLEFT")
	bar.candyBarIconFrame:SetTexCoord(0.1, 0.9, 0.1, 0.9)

	-- Status Bar
	bar.candyBarBar:ClearAllPoints()
	bar.candyBarBar:SetPoint("TOPRIGHT")
	bar.candyBarBar:SetPoint("BOTTOMRIGHT")

	-- BG
	bar.candyBarBackground:SetAllPoints()

	-- Duration
	bar.candyBarDuration:ClearAllPoints()
	bar.candyBarDuration:SetPoint("RIGHT", bar.candyBarBar, "RIGHT", -2, 0)

	-- Name
	bar.candyBarLabel:ClearAllPoints()
	bar.candyBarLabel:SetPoint("LEFT", bar.candyBarBar, "LEFT", 2, 0)
	bar.candyBarLabel:SetPoint("RIGHT", bar.candyBarBar, "RIGHT", -2, 0)
end

local applystyle = function(bar)
	-- General bar settings
	bar:SetHeight(15)
	bar:SetScale(1)
	bar.OldSetScale = bar.SetScale

	-- Set currect scale if bars attached to nameplates
	if not bar.hook then
		hooksecurefunc(bar, "SetParent", function()
			bar:SetScale(T.noscalemult)
		end)
		bar.hook = true
	end

	-- Create or reparent and use bar background
	local bg = nil
	if #freebg > 0 then
		bg = table.remove(freebg)
	else
		bg = createbg()
	end
	bg:SetParent(bar)
	bg:ClearAllPoints()
	bg:SetPoint("TOPLEFT", bar, "TOPLEFT", -2, 2)
	bg:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 2, -2)
	bg:SetFrameStrata("BACKGROUND")
	bg:Show()
	bar:Set("bigwigs:shestakui:bg", bg)

	-- Create or reparent and use icon background
	local ibg = nil
	if bar.candyBarIconFrame:GetTexture() then
		if #freebg > 0 then
			ibg = table.remove(freebg)
		else
			ibg = createbg()
		end
		ibg:SetParent(bar)
		ibg:ClearAllPoints()
		ibg:SetPoint("TOPLEFT", bar.candyBarIconFrame, "TOPLEFT", -2, 2)
		ibg:SetPoint("BOTTOMRIGHT", bar.candyBarIconFrame, "BOTTOMRIGHT", 2, -2)
		ibg:SetFrameStrata("BACKGROUND")
		ibg:Show()
		bar:Set("bigwigs:shestakui:ibg", ibg)
	end

	-- Setup timer and bar name fonts and positions
	bar.candyBarLabel:SetFont(C.font.stylization_font, C.font.stylization_font_size, C.font.stylization_font_style)
	bar.candyBarLabel:SetShadowOffset(C.font.stylization_font_shadow and 1 or 0, C.font.stylization_font_shadow and -1 or 0)
	bar.candyBarLabel:SetJustifyH("LEFT")
	bar.candyBarLabel:ClearAllPoints()
	bar.candyBarLabel:SetPoint("TOPLEFT", bar, "TOPLEFT", 2, 0)
	bar.candyBarLabel:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", -14, 0)

	bar.candyBarDuration:SetFont(C.font.stylization_font, C.font.stylization_font_size, C.font.stylization_font_style)
	bar.candyBarDuration:SetShadowOffset(C.font.stylization_font_shadow and 1 or 0, C.font.stylization_font_shadow and -1 or 0)
	bar.candyBarDuration:SetJustifyH("RIGHT")
	bar.candyBarDuration:ClearAllPoints()
	bar.candyBarDuration:SetPoint("RIGHT", bar, "RIGHT", 1, 0)

	-- Setup bar positions and look
	bar.candyBarBar:ClearAllPoints()
	bar.candyBarBar:SetAllPoints(bar)
	bar.candyBarBar.OldSetPoint = bar.candyBarBar.SetPoint
	bar.candyBarBar.SetPoint = T.dummy
	bar.candyBarBar:SetStatusBarTexture(C.media.texture)
	if not bar:Get("bigwigs:emphasized") then
		bar.candyBarBar:SetStatusBarColor(T.color.r, T.color.g, T.color.b, 1)
	end
	bar.candyBarBackground:SetTexture(C.media.texture)

	-- Setup icon positions and other things
	bar.candyBarIconFrame:ClearAllPoints()
	bar.candyBarIconFrame:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", -28, 0)
	bar.candyBarIconFrame:SetSize(21, 21)
	bar.candyBarIconFrame.OldSetWidth = bar.candyBarIconFrame.SetWidth
	bar.candyBarIconFrame.SetWidth = T.dummy
	bar.candyBarIconFrame:SetTexCoord(0.1, 0.9, 0.1, 0.9)
end

----------------------------------------------------------------------------------------
--	Skin BigWigs plugin frames (Proximity, AltPower, InfoBox)
----------------------------------------------------------------------------------------

local function skinBigWigsFrame(frame)
	if not frame or frame.bwSkinskinned then return end

	frame:SetTemplate("Transparent")

	-- Hide native background textures (replaced by template)
	for _, region in next, {frame:GetRegions()} do
		if region.GetDrawLayer and region:GetDrawLayer() == "BACKGROUND" then
			region:SetAlpha(0)
		end
	end

	-- Skin buttons (close, sound, expand)
	for _, child in next, {frame:GetChildren()} do
		if child:GetObjectType() == "Button" and not child.bwSkinskinned then
			local tex = child:GetNormalTexture()
			local texPath = tex and tex:GetTexture()
			child:ClearAllPoints()
			if texPath and texPath:find("close") then
				child:SetNormalTexture(0)
				child.SetNormalTexture = T.dummy
				child:SetPushedTexture(0)
				child.SetPushedTexture = T.dummy
				T.SkinCloseButton(child, nil, "x", false)
			else
				child:SkinButton()
			end
			child.bwSkinskinned = true
		end
	end

	frame.bwSkinskinned = true
end

local function skinInfoBox(display)
	if not display or display.ibSkinned then return end

	skinBigWigsFrame(display)

	-- Extra panels (for 11+ line mode)
	for _, panel in next, {display.display2, display.display3, display.display4} do
		if panel then skinBigWigsFrame(panel) end
	end

	-- Header frame
	if display.headerFrame then
		skinBigWigsFrame(display.headerFrame)
	end

	-- Update fonts to ShestakUI style
	if display.title then
		display.title:SetFont(C.media.normal_font, 12, "")
		display.title:SetShadowOffset(1, -1)
	end
	for i = 1, 40 do
		if display.text[i] then
			display.text[i]:SetFont(C.media.normal_font, 12, "")
			display.text[i]:SetShadowOffset(1, -1)
		end
	end

	display.ibSkinned = true
end

-- Find InfoBox display frame (it doesn't send BigWigs_FrameCreated message)
local function findAndSkinInfoBox()
	local frame = EnumerateFrames()
	while frame do
		if frame.headerFrame and frame.text and frame.title and frame.bar and frame.display2 then
			skinInfoBox(frame)
			return
		end
		frame = EnumerateFrames(frame)
	end
end

local function registerStyle(myProfile)
	if not BigWigs then return end
	if T.Classic then
		local bars = BigWigs:GetPlugin("Bars", true)
		if not bars then return end
		bars:RegisterBarStyle("ShestakUI", {
			apiVersion = 1,
			version = 1,
			GetSpacing = function() return T.Scale(13) end,
			ApplyStyle = applystyle,
			BarStopped = freestyle,
			GetStyleName = function() return "ShestakUI" end,
		})
	else
		BigWigsAPI:RegisterBarStyle("ShestakUI", {
			apiVersion = 1,
			version = 1,
			GetSpacing = function() return T.Scale(13) end,
			ApplyStyle = applystyle,
			BarStopped = freestyle,
			GetStyleName = function() return "ShestakUI" end,
		})
	end

	if BigWigsLoader and myProfile and myProfile.barStyle == "ShestakUI" then
		BigWigsLoader.RegisterMessage("BigWigs_Plugins", "BigWigs_BarEmphasized", function(_, _, bar)
			local module = bar:Get("bigwigs:module")
			local key = bar:Get("bigwigs:option")
			local colors = BigWigs:GetPlugin("Colors")
			bar.candyBarBar:SetStatusBarColor(colors:GetColor("barEmphasized", module, key))
		end)
	end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(_, event, addon)
	if event == "ADDON_LOADED" then
		if addon == "BigWigs_Plugins" then
			local myProfile
			if BigWigsClassicDB then
				if BigWigsClassicDB.profileKeys and BigWigsClassicDB.namespaces and BigWigsClassicDB.namespaces.BigWigs_Plugins_Bars and BigWigsClassicDB.namespaces.BigWigs_Plugins_Bars.profiles then
					myProfile = BigWigsClassicDB.namespaces.BigWigs_Plugins_Bars.profiles[BigWigsClassicDB.profileKeys[UnitName("player").." - "..GetRealmName()]]
				end
				if not myProfile or myProfile.InstalledBars ~= C.actionbar.bottombars then
					StaticPopup_Show("SETTINGS_BIGWIGS")
				end
			end

			if BigWigs3DB then
				if BigWigs3DB.profileKeys and BigWigs3DB.namespaces and BigWigs3DB.namespaces.BigWigs_Plugins_Bars and BigWigs3DB.namespaces.BigWigs_Plugins_Bars.profiles then
					myProfile = BigWigs3DB.namespaces.BigWigs_Plugins_Bars.profiles[BigWigs3DB.profileKeys[UnitName("player").." - "..GetRealmName()]]
				end
				if not myProfile or myProfile.InstalledBars ~= C.actionbar.bottombars then
					StaticPopup_Show("SETTINGS_BIGWIGS")
				end
			end

			registerStyle(myProfile)

			-- Hook InfoBox show to skin it (InfoBox doesn't send BigWigs_FrameCreated)
			local infoBoxPlugin = BigWigs:GetPlugin("InfoBox", true)
			if infoBoxPlugin and infoBoxPlugin.BigWigs_ShowInfoBox and not infoBoxPlugin._ibHooked then
				hooksecurefunc(infoBoxPlugin, "BigWigs_ShowInfoBox", function()
					findAndSkinInfoBox()
				end)
				infoBoxPlugin._ibHooked = true
			end

			f:UnregisterEvent("ADDON_LOADED")
		elseif addon == "ShestakUI" then
			if BigWigsLoader then
			BigWigsLoader.RegisterMessage(addon, "BigWigs_FrameCreated", function(_, frame, name)
				if name == "Proximity" then
					skinBigWigsFrame(frame)
					if frame.header then
						frame.header:SetFont(C.media.normal_font, 12, "")
						frame.header:SetShadowOffset(1, -1)
					end
					if frame.abilityName then
						frame.abilityName:SetFont(C.media.normal_font, 12, "")
						frame.abilityName:SetShadowOffset(1, -1)
					end
					if frame.text then
						frame.text:SetFont(C.media.normal_font, 16, "")
						frame.text:SetShadowOffset(1, -1)
					end
				end
				if name == "AltPower" then
					skinBigWigsFrame(frame)
					if frame.title then
						frame.title:SetFont(C.media.normal_font, 12, "")
						frame.title:SetShadowOffset(1, -1)
					end
					if frame.text then
						for i = 1, 26 do
							if frame.text[i] then
								frame.text[i]:SetFont(C.media.normal_font, 12, "")
								frame.text[i]:SetShadowOffset(1, -1)
							end
						end
					end
				end
				if name == "QueueTimer" and C.skins.blizzard_frames then
						frame:SetSize(240, 15)
						frame:StripTextures()
						frame:SetStatusBarTexture(C.media.texture)
						frame:CreateBackdrop("Overlay")
					end
				end)
			end
		end
	end
end)

function T.UploadBW()
	if not BigWigs then return end
	local bars = BigWigs:GetPlugin("Bars", true)
	if bars then
		bars.db.profile.barStyle = "ShestakUI"
		bars.db.profile.fontName = C.font.stylization_font
		bars.db.profile.BigWigsAnchor_width = 185
		bars.db.profile.BigWigsAnchor_x = 188 / UIParent:GetEffectiveScale()
		bars.db.profile.BigWigsEmphasizeAnchor_width = 184
		bars.db.profile.BigWigsEmphasizeAnchor_x = 620
		bars.db.profile.emphasizeGrowup = true
		bars.db.profile.InstalledBars = C.actionbar.bottombars
		if C.actionbar.bottombars == 1 then
			bars.db.profile.BigWigsAnchor_y = 185 * UIParent:GetEffectiveScale()
			bars.db.profile.BigWigsEmphasizeAnchor_y = 344 * UIParent:GetEffectiveScale()
		elseif C.actionbar.bottombars == 2 then
			bars.db.profile.BigWigsAnchor_y = 213 * UIParent:GetEffectiveScale()
			bars.db.profile.BigWigsEmphasizeAnchor_y = 372 * UIParent:GetEffectiveScale()
		elseif C.actionbar.bottombars == 3 then
			bars.db.profile.BigWigsAnchor_y = 241 * UIParent:GetEffectiveScale()
			bars.db.profile.BigWigsEmphasizeAnchor_y = 400 * UIParent:GetEffectiveScale()
		end
	end
	local mess = BigWigs:GetPlugin("Messages")
	if mess then
		mess.db.profile.fontName = "Calibri"
		mess.db.profile.fontSize = 20
		mess.db.profile.emphFontName = "Calibri"
		mess.db.profile.BWMessageAnchor_x = 615
		mess.db.profile.BWMessageAnchor_y = 440
		mess.db.profile.BWEmphasizeMessageAnchor_x = 618
		mess.db.profile.BWEmphasizeMessageAnchor_y = 495
		mess.db.profile.BWEmphasizeCountdownMessageAnchor_x = 665
		mess.db.profile.BWEmphasizeCountdownMessageAnchor_y = 477
	end
	local prox = BigWigs:GetPlugin("Proximity")
	if prox then
		prox.db.profile.fontName = "Calibri"
		prox.db.profile.objects.ability = false
	end
	local altpower = BigWigs:GetPlugin("AltPower")
	if altpower then
		altpower.db.profile.fontName = "Calibri"
	end
	if T.Classic then
		BigWigsIconClassicDB.hide = true
	else
		BigWigsIconDB.hide = true
	end
	if InCombatLockdown() then
		print("|cffffff00"..ERR_NOT_IN_COMBAT.."|r")
		print("|cffffff00Reload your UI to apply skin.|r")
	else
		ReloadUI()
	end
end

-- manual command /settings bw
StaticPopupDialogs.SETTINGS_BIGWIGS = {
	text = L_POPUP_SETTINGS_BW,
	button1 = ACCEPT,
	button2 = CANCEL,
	OnAccept = function() T.UploadBW() end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = true,
	preferredIndex = 5,
}

SlashCmdList.BWTEST = function(msg)
	if msg == "apply" then
		SlashCmdList["BigWigs"]()
		HideUIPanel(InterfaceOptionsFrame)
		StaticPopup_Show("SETTINGS_BIGWIGS")
	elseif msg == "test" then
		SlashCmdList["BigWigs"]()
		BigWigs:GetPlugin("Proximity").Test(BigWigs:GetPlugin("Proximity"))
		HideUIPanel(InterfaceOptionsFrame)
		BigWigs:Test()
		BigWigs:Test()
		BigWigs:Test()
		BigWigs:Test()
		BigWigs:Test()
	else
		print("|cffffff00Type /bwtest apply to apply BigWigs settings.|r")
		print("|cffffff00Type /bwtest test to launch BigWigs testmode.|r")
	end
end
SLASH_BWTEST1 = "/bwtest"
SLASH_BWTEST2 = "/ицеуые"