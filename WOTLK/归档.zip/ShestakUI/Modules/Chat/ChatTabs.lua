﻿local T, C, L = unpack(ShestakUI)
if C.chat.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Chat Tab Styling (NDUI-inspired: gold selected / gray unselected / red alert)
----------------------------------------------------------------------------------------

-- NDUI-style colors
local COLOR_SELECTED = {1, 0.8, 0}       -- gold
local COLOR_UNSELECTED = {0.7, 0.7, 0.7} -- gray
local COLOR_ALERTING = {1, 0.2, 0.2}     -- red

if C.chat.tabs_mouseover == true then
	CHAT_FRAME_TAB_SELECTED_NOMOUSE_ALPHA = 0
	CHAT_FRAME_TAB_NORMAL_NOMOUSE_ALPHA = 0
	CHAT_FRAME_TAB_ALERTING_NOMOUSE_ALPHA = 1
	CHAT_FRAME_TAB_SELECTED_MOUSEOVER_ALPHA = 1
	CHAT_FRAME_TAB_NORMAL_MOUSEOVER_ALPHA = 1
	CHAT_FRAME_TAB_ALERTING_MOUSEOVER_ALPHA = 1
end

local function ApplyTabColor(tab, isSelected)
	if not tab then return end
	local text = tab:GetFontString()
	if not text then return end
	text:SetFont(C.font.chat_tabs_font, C.font.chat_tabs_font_size, C.font.chat_tabs_font_style)
	text:SetShadowOffset(C.font.chat_tabs_font_shadow and 1 or 0, C.font.chat_tabs_font_shadow and -1 or 0)
	-- Remove shadow for OUTLINE font to avoid double-stroke
	if C.font.chat_tabs_font_style and C.font.chat_tabs_font_style ~= "" then
		text:SetShadowColor(0, 0, 0, 0)
	end
	if isSelected then
		text:SetTextColor(unpack(COLOR_SELECTED))
	else
		text:SetTextColor(unpack(COLOR_UNSELECTED))
	end
	-- Force alpha for non-mouseover mode
	if C.chat.tabs_mouseover ~= true then
		tab:SetAlpha(1)
	end
end

local function OnEnter(self)
	ApplyTabColor(self, true)
end

local function OnLeave(self)
	local id = self:GetID()
	local isSelected = (_G["ChatFrame"..id] == SELECTED_CHAT_FRAME)
	ApplyTabColor(self, isSelected)
end

-- Hook FCFTab_UpdateColors (called by Blizzard whenever tab state changes)
hooksecurefunc("FCFTab_UpdateColors", function(tab, selected)
	if not tab then return end
	if tab:GetParent() == _G.ChatConfigFrameChatTabManager then return end

	-- Ensure our hooks are installed
	if not tab._nduiHooked then
		tab:HookScript("OnEnter", OnEnter)
		tab:HookScript("OnLeave", OnLeave)
		-- Block Blizzard's alpha fading for non-mouseover mode
		if C.chat.tabs_mouseover ~= true then
			tab:SetAlpha(1)
			if tab:GetID() ~= 2 then
				tab.SetAlpha = UIFrameFadeRemoveFrame
			end
		end
		tab._nduiHooked = true
	end

	ApplyTabColor(tab, selected)
end)

-- Hook alert flash
hooksecurefunc("FCF_StartAlertFlash", function(frame)
	local tab = _G["ChatFrame"..frame:GetID().."Tab"]
	if tab then
		local text = tab:GetFontString()
		if text then
			text:SetTextColor(unpack(COLOR_ALERTING))
		end
	end
end)

-- Apply to all existing tabs immediately
for i = 1, NUM_CHAT_WINDOWS do
	local tab = _G["ChatFrame"..i.."Tab"]
	if tab then
		-- Install hooks
		if not tab._nduiHooked then
			tab:HookScript("OnEnter", OnEnter)
			tab:HookScript("OnLeave", OnLeave)
			if C.chat.tabs_mouseover ~= true then
				tab:SetAlpha(1)
				if i ~= 2 then
					tab.SetAlpha = UIFrameFadeRemoveFrame
				end
			end
			tab._nduiHooked = true
		end
		-- Apply initial colors
		local isSelected = (_G["ChatFrame"..i] == SELECTED_CHAT_FRAME)
		ApplyTabColor(tab, isSelected)
	end
end

-- Delayed re-apply to win over any Blizzard resets after FCF init
C_Timer.After(3, function()
	for i = 1, NUM_CHAT_WINDOWS do
		local tab = _G["ChatFrame"..i.."Tab"]
		if tab then
			local isSelected = (_G["ChatFrame"..i] == SELECTED_CHAT_FRAME)
			ApplyTabColor(tab, isSelected)
		end
	end
end)

-- Handle CombatLogQuickButtonFrame_Custom alpha
local Fane = CreateFrame("Frame")
Fane:RegisterEvent("ADDON_LOADED")
Fane:SetScript("OnEvent", function(self, event, addon)
	if addon == "Blizzard_CombatLog" then
		self:UnregisterEvent(event)
		if CombatLogQuickButtonFrame_Custom then
			CombatLogQuickButtonFrame_Custom:SetAlpha(0.4)
		end
	end
end)
