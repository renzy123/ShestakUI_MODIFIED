-------------------------------------------------------------------------------
--  EllesmereUI_ShestakSkin - Modules/Auras.lua
--  光环美化模块：BUFF/DEBUFF 1px 黑色像素边框、正方形裁切与紧凑倒计时排版
--  100% 对齐 ShestakUI BuffFrame 规范
--
--  关键修复：
--  1) 解决图标拉扁：强制设置 28x28 正方形尺寸 (SetSize(28, 28))，杜绝长方形变形；
--  2) 解决空红框问题：严禁盲目扫描预分配对象池 (allAuraFrames)；仅在光环真正显示
--     且存在有效纹理内容时才展示边框；无 DEBUFF 或槽位隐藏时彻底隐藏边框与背景。
-------------------------------------------------------------------------------
local ADDON_NAME, ns = ...
local SK = ns.SK

local AURA_SIZE = 28 -- ShestakUI 经典光环图标正方形尺寸

-- ShestakUI 紧凑时间格式化 (去除原生繁冗的空格与字母 "23 s" -> "23", "58 m" -> "58m")
-- 使用 SK:IsSecretValue 与 pcall 沙盒闭包彻底杜绝受保护数值比较/算术崩溃
local function FormatAuraTime(s)
    if not s or (SK.IsSecretValue and SK:IsSecretValue(s)) then return "" end
    local ok, res = pcall(function()
        if s < 0 then return "" end
        if s >= 86400 then
            return string.format("%dd", math.floor(s / 86400 + 0.5))
        elseif s >= 3600 then
            return string.format("%dh", math.floor(s / 3600 + 0.5))
        elseif s >= 60 then
            return string.format("%dm", math.floor(s / 60 + 0.5))
        else
            return string.format("%d", math.floor(s + 0.5))
        end
    end)
    if ok and type(res) == "string" then return res end
    return ""
end

-- 减益类型染色表
local DEBUFF_COLORS = {
    Magic    = { 0.20, 0.60, 1.00 },
    Curse    = { 0.60, 0.00, 1.00 },
    Disease  = { 0.60, 0.40, 0.00 },
    Poison   = { 0.00, 0.60, 0.00 },
    none     = { 0.80, 0.00, 0.00 },
}

-- 美化单个光环图标
local function SkinAuraButton(aura, isDebuff)
    if not aura then return end

    -- 强制正方形尺寸 (28x28)，彻底解决图标被拉扁的问题
    aura:SetSize(AURA_SIZE, AURA_SIZE)

    -- 检查光环是否真正处于活跃显示状态且具有有效图标纹理
    local icon = aura.Icon
    local hasValidTexture = false
    if icon and icon.GetTexture then
        local tex = icon:GetTexture()
        if tex and tex ~= "" and tex ~= 0 then
            hasValidTexture = true
        end
    end

    local isShown = aura:IsShown() and hasValidTexture

    -- 1. 隐藏原生浮雕圆角边框、遮罩与临时附魔高光
    if aura.Border then
        aura.Border:SetAlpha(0)
        aura.Border:SetTexture("")
    end
    if aura.TempEnchantBorder then
        aura.TempEnchantBorder:SetAlpha(0)
    end
    if aura.IconMask then
        aura.IconMask:Hide()
    end
    if aura.Symbol then
        aura.Symbol:Hide()
    end

    -- 2. 图标正方形裁切 (0.1, 0.9) 并内缩贴合
    if icon and icon.SetTexCoord then
        SK:CropIcon(icon)
        icon:ClearAllPoints()
        icon:SetPoint("TOPLEFT", aura, "TOPLEFT", 1, -1)
        icon:SetPoint("BOTTOMRIGHT", aura, "BOTTOMRIGHT", -1, 1)
        if icon.SetDrawLayer then
            icon:SetDrawLayer("BORDER")
        end
    end

    -- 3. 挂载 1px 黑色像素边框与暗黑底板
    local bdr = aura._shetsakBorder or SK:CreatePixelBorder(aura)
    if not aura._shetsakBg then
        local bg = aura:CreateTexture(nil, "BACKGROUND", nil, -8)
        bg:SetAllPoints(aura)
        bg:SetColorTexture(0.08, 0.08, 0.08, 1)
        aura._shetsakBg = bg
    end

    -- 核心防空框：如果光环未显示或无内容，彻底隐藏边框与背景，避免出现空红框
    if not isShown then
        if bdr then bdr:Hide() end
        if aura._shetsakBg then aura._shetsakBg:Hide() end
        return
    else
        if bdr then bdr:Show() end
        if aura._shetsakBg then aura._shetsakBg:Show() end
    end

    -- 4. 减益 DEBUFF 边框着色 (仅对有效 DEBUFF 染色，BUFF 保持黑色)
    if isDebuff and bdr then
        local col = DEBUFF_COLORS.none
        if aura.buttonInfo and aura.buttonInfo.debuffType and DEBUFF_COLORS[aura.buttonInfo.debuffType] then
            col = DEBUFF_COLORS[aura.buttonInfo.debuffType]
        elseif aura.debuffType and DEBUFF_COLORS[aura.debuffType] then
            col = DEBUFF_COLORS[aura.debuffType]
        end
        bdr:SetColor(col[1], col[2], col[3], 1)
    elseif bdr then
        -- BUFF 保持 ShestakUI 经典纯黑 1px 像素边框
        bdr:SetColor(0, 0, 0, 1)
    end

    -- 5. 持续时间文本排版与格式化 (居中纯白加阴影，统一 Shestak 紧凑时间)
    local duration = aura.Duration
    if duration and duration.SetFont then
        duration:ClearAllPoints()
        duration:SetPoint("CENTER", aura, "CENTER", 1, 0)
        duration:SetFont(SK.Font, 11, "OUTLINE")
        duration:SetShadowOffset(1, -1)
        duration:SetVertexColor(1, 1, 1)
        if duration.SetDrawLayer then duration:SetDrawLayer("OVERLAY", 7) end
    end

    -- 拦截持续时间刷新 (过滤受保护受限制的 secret number，使用 pcall 防护调用)
    if aura.UpdateDuration and not aura._shetsakDurHooked then
        aura._shetsakDurHooked = true
        hooksecurefunc(aura, "UpdateDuration", function(self, timeLeft)
            if timeLeft and self.Duration and not (SK.IsSecretValue and SK:IsSecretValue(timeLeft)) then
                local formatted = FormatAuraTime(timeLeft)
                if formatted ~= "" then
                    pcall(self.Duration.SetFormattedText, self.Duration, formatted)
                    pcall(self.Duration.SetVertexColor, self.Duration, 1, 1, 1)
                end
            end
        end)
    end

    -- 6. 堆叠层数排版 (右下角)
    local count = aura.Count
    if count and count.SetFont then
        count:ClearAllPoints()
        count:SetPoint("BOTTOMRIGHT", aura, "BOTTOMRIGHT", 1, 0)
        count:SetFont(SK.Font, 11, "OUTLINE")
        count:SetShadowOffset(1, -1)
        if count.SetDrawLayer then count:SetDrawLayer("OVERLAY", 7) end
    end

    -- 7. 挂钩显隐状态，保证光环隐藏时边框立即同步隐藏
    if not aura._shetsakVisHooked then
        aura._shetsakVisHooked = true
        aura:HookScript("OnShow", function(self)
            local tex = self.Icon and self.Icon:GetTexture()
            if tex and tex ~= "" and tex ~= 0 then
                if self._shetsakBorder then self._shetsakBorder:Show() end
                if self._shetsakBg then self._shetsakBg:Show() end
            else
                if self._shetsakBorder then self._shetsakBorder:Hide() end
                if self._shetsakBg then self._shetsakBg:Hide() end
            end
        end)
        aura:HookScript("OnHide", function(self)
            if self._shetsakBorder then self._shetsakBorder:Hide() end
            if self._shetsakBg then self._shetsakBg:Hide() end
        end)
    end

    aura._shetsakSkinned = true
end

-- 清理所有未激活或隐藏框体上的残留红框
local function CleanupDeadBorders()
    -- 清理 DebuffFrame 上的未激活对象池帧
    if DebuffFrame and DebuffFrame.AuraContainer and DebuffFrame.AuraContainer.allAuraFrames then
        for _, aura in ipairs(DebuffFrame.AuraContainer.allAuraFrames) do
            if not aura:IsShown() or not (aura.Icon and aura.Icon:GetTexture()) then
                if aura._shetsakBorder then aura._shetsakBorder:Hide() end
                if aura._shetsakBg then aura._shetsakBg:Hide() end
            end
        end
    end
    for i = 1, 32 do
        local dbtn = _G["DebuffButton" .. i]
        if dbtn and (not dbtn:IsShown() or not (dbtn.Icon and dbtn.Icon:GetTexture())) then
            if dbtn._shetsakBorder then dbtn._shetsakBorder:Hide() end
            if dbtn._shetsakBg then dbtn._shetsakBg:Hide() end
        end
    end
end

-- 全局扫描美化活跃的 BUFF / DEBUFF
local function SkinActiveAuras()
    if not SK:IsModuleEnabled("auras") then return end

    -- 隐藏折叠展开按钮
    if BuffFrame and BuffFrame.CollapseAndExpandButton then
        BuffFrame.CollapseAndExpandButton:Hide()
        BuffFrame.CollapseAndExpandButton.Show = function() end
    end

    -- 1. 仅美化当前实际显示在容器中的活跃光环
    if BuffFrame and BuffFrame.auraFrames then
        for _, aura in ipairs(BuffFrame.auraFrames) do
            if aura:IsShown() then
                SkinAuraButton(aura, false)
            end
        end
    end
    if DebuffFrame and DebuffFrame.auraFrames then
        for _, aura in ipairs(DebuffFrame.auraFrames) do
            if aura:IsShown() then
                SkinAuraButton(aura, true)
            else
                if aura._shetsakBorder then aura._shetsakBorder:Hide() end
                if aura._shetsakBg then aura._shetsakBg:Hide() end
            end
        end
    end

    -- 2. 经典版本活跃 BuffButton 与武器附魔
    for i = 1, 32 do
        local btn = _G["BuffButton" .. i]
        if btn and btn:IsShown() then SkinAuraButton(btn, false) end
        local dbtn = _G["DebuffButton" .. i]
        if dbtn and dbtn:IsShown() then
            SkinAuraButton(dbtn, true)
        elseif dbtn and dbtn._shetsakBorder then
            dbtn._shetsakBorder:Hide()
            if dbtn._shetsakBg then dbtn._shetsakBg:Hide() end
        end
    end
    for i = 1, 3 do
        local temp = _G["TempEnchant" .. i]
        if temp and temp:IsShown() then SkinAuraButton(temp, false) end
    end

    CleanupDeadBorders()
end

-- 挂钩容器网格更新事件 (这是现代 10.0+ / 11.0+ 获取实际活跃光环的最精确方式)
local function HookAuraContainers()
    if BuffFrame and BuffFrame.AuraContainer and BuffFrame.AuraContainer.UpdateGridLayout and not BuffFrame.AuraContainer._shetsakHooked then
        BuffFrame.AuraContainer._shetsakHooked = true
        hooksecurefunc(BuffFrame.AuraContainer, "UpdateGridLayout", function(_, auras)
            if not SK:IsModuleEnabled("auras") or not auras then return end
            for _, aura in ipairs(auras) do
                SkinAuraButton(aura, false)
            end
        end)
    end

    if DebuffFrame and DebuffFrame.AuraContainer and DebuffFrame.AuraContainer.UpdateGridLayout and not DebuffFrame.AuraContainer._shetsakHooked then
        DebuffFrame.AuraContainer._shetsakHooked = true
        hooksecurefunc(DebuffFrame.AuraContainer, "UpdateGridLayout", function(_, auras)
            if not SK:IsModuleEnabled("auras") then return end
            if auras and #auras > 0 then
                for _, aura in ipairs(auras) do
                    SkinAuraButton(aura, true)
                end
            end
            CleanupDeadBorders()
        end)
    end
end

SK.SkinAuras = SkinActiveAuras

-- 事件监听
local auraWatcher = CreateFrame("Frame")
auraWatcher:RegisterEvent("PLAYER_LOGIN")
auraWatcher:RegisterEvent("PLAYER_ENTERING_WORLD")
auraWatcher:RegisterUnitEvent("UNIT_AURA", "player")
auraWatcher:SetScript("OnEvent", function(self, event)
    SkinActiveAuras()
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        HookAuraContainers()
        C_Timer.After(0.5, SkinActiveAuras)
        C_Timer.After(1.5, SkinActiveAuras)
    end
end)
