local T, C, L = unpack(ShestakUI)
if C.skins.trinket_menu ~= true then return end

----------------------------------------------------------------------------------------
--	TrinketMenu skin
----------------------------------------------------------------------------------------
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function()
	if not IsAddOnLoaded("TrinketMenu") then return end

	-- Helper: skin an action-style trinket button (worn or menu)
	local function SkinTrinketButton(btn)
		if not btn or btn.__skinned then return end
		btn.__skinned = true

		-- Hide default border textures
		local icon = _G[btn:GetName().."IconTexture"] or btn.icon
		local normalTex = btn:GetNormalTexture()
		if normalTex then
			normalTex:SetTexture(0)
			normalTex:SetAlpha(0)
		end

		-- Crop and position icon
		if icon then
			icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
			icon:ClearAllPoints()
			icon:SetPoint("TOPLEFT", 1, -1)
			icon:SetPoint("BOTTOMRIGHT", -1, 1)
		end

		-- Create backdrop border
		if not btn.backdrop then
			btn:CreateBackdrop("Default")
			if C.actionbar.classcolor_border == true then
				btn.backdrop:SetBackdropBorderColor(unpack(C.media.classborder_color))
			end
		end

		-- Style push/hover
		local highlightTex = btn:GetHighlightTexture()
		if highlightTex then
			highlightTex:SetTexture(C.media.highlight)
			if icon then highlightTex:SetAllPoints(icon) end
		end
		local pushedTex = btn:GetPushedTexture()
		if pushedTex then
			pushedTex:SetTexture(0, 0, 0, 0.3)
			if icon then pushedTex:SetAllPoints(icon) end
		end

		-- Hide queue inset texture
		local queue = _G[btn:GetName().."Queue"]
		if queue then
			queue:SetDrawLayer("OVERLAY", 1)
		end

		-- Apply ShestakUI font to cooldown text
		local cooldownText = _G[btn:GetName().."Time"]
		if cooldownText then
			cooldownText:SetFont(C.font.stylization_font, C.font.stylization_font_size, C.font.stylization_font_style)
			cooldownText:SetShadowOffset(C.font.stylization_font_shadow and 1 or 0, C.font.stylization_font_shadow and -1 or 0)
		end

		-- Apply ShestakUI font to hotkey text
		local hotKey = _G[btn:GetName().."HotKey"]
		if hotKey then
			hotKey:SetFont(C.font.stylization_font, C.font.stylization_font_size, C.font.stylization_font_style)
			hotKey:SetShadowOffset(C.font.stylization_font_shadow and 1 or 0, C.font.stylization_font_shadow and -1 or 0)
		end

		-- Hide the AutoQueue check overlay from worn trinket buttons
		local check = _G[btn:GetName().."Check"]
		if check and check.SetTexture then
			check:SetTexture(0)
		end
	end

	-- Skin the AutoQueue check buttons (TrinketMenu_Trinket0Check / TrinketMenu_Trinket1Check)
	-- These are separate UICheckButtonTemplate objects, not part of the action button
	local function SkinTrinketCheckButton(cb)
		if not cb or cb.__skinned then return end
		cb.__skinned = true
		T.SkinCheckBox(cb, 20)
	end

	------------------------------------------------------------------------
	-- Main Frame (worn trinkets)
	------------------------------------------------------------------------
	local mainFrame = TrinketMenu_MainFrame
	if mainFrame then
		mainFrame:StripTextures()
		mainFrame:SetTemplate("Transparent")

		-- Hide dock textures
		for _, name in ipairs({"_MainDock_TOP", "_MainDock_TOPRIGHT", "_MainDock_RIGHT", "_MainDock_BOTTOMRIGHT", "_MainDock_BOTTOM", "_MainDock_BOTTOMLEFT", "_MainDock_LEFT", "_MainDock_TOPLEFT"}) do
			local dock = _G["TrinketMenu"..name]
			if dock then
				dock:SetTexture(0)
				dock:SetAlpha(0)
			end
		end

		-- Skin worn trinket buttons
		for i = 0, 1 do
			SkinTrinketButton(_G["TrinketMenu_Trinket"..i])
		end
	end

	------------------------------------------------------------------------
	-- Menu Frame (bag trinkets list)
	------------------------------------------------------------------------
	local menuFrame = TrinketMenu_MenuFrame
	if menuFrame then
		menuFrame:StripTextures()
		menuFrame:SetTemplate("Transparent")

		-- Hide dock textures
		for _, name in ipairs({"_MenuDock_TOP", "_MenuDock_TOPRIGHT", "_MenuDock_RIGHT", "_MenuDock_BOTTOMRIGHT", "_MenuDock_BOTTOM", "_MenuDock_BOTTOMLEFT", "_MenuDock_LEFT", "_MenuDock_TOPLEFT"}) do
			local dock = _G["TrinketMenu"..name]
			if dock then
				dock:SetTexture(0)
				dock:SetAlpha(0)
			end
		end

		-- Skin menu trinket buttons (up to 30)
		for i = 1, 30 do
			SkinTrinketButton(_G["TrinketMenu_Menu"..i])
		end
	end

	------------------------------------------------------------------------
	-- Options Frame
	------------------------------------------------------------------------
	local optFrame = TrinketMenu_OptFrame
	if optFrame then
		optFrame:StripTextures()
		optFrame:SetTemplate("Transparent")

		-- Skin close button
		if TrinketMenu_CloseButton then
			T.SkinCloseButton(TrinketMenu_CloseButton)
		end

		-- Skin lock button
		if TrinketMenu_LockButton then
			T.SkinCloseButton(TrinketMenu_LockButton)
		end

		-- Skin tab buttons
		for i = 1, 3 do
			local tab = _G["TrinketMenu_Tab"..i]
			if tab then
				T.SkinTab(tab)
			end
		end

		-- Skin Trinket0/1 auto-queue check buttons
		for i = 0, 1 do
			SkinTrinketCheckButton(_G["TrinketMenu_Trinket"..i.."Check"])
		end
	end

	------------------------------------------------------------------------
	-- Sub-frames (Options and Queue)
	------------------------------------------------------------------------
	-- SubOptFrame
	local subOptFrame = TrinketMenu_SubOptFrame
	if subOptFrame then
		subOptFrame:StripTextures()
		subOptFrame:SetTemplate("Transparent")

		-- Skin all option checkboxes
		local optCheckBoxes = {
			"TrinketMenu_OptLocked",
			"TrinketMenu_OptShowIcon",
			"TrinketMenu_OptDisableToggle",
			"TrinketMenu_OptSquareMinimap",
			"TrinketMenu_OptCooldownCount",
			"TrinketMenu_OptLargeCooldown",
			"TrinketMenu_OptShowTooltips",
			"TrinketMenu_OptTooltipFollow",
			"TrinketMenu_OptTinyTooltips",
			"TrinketMenu_OptShowHotKeys",
			"TrinketMenu_OptStopOnSwap",
			"TrinketMenu_OptRedRange",
			"TrinketMenu_OptHidePetBattle",
			"TrinketMenu_OptKeepDocked",
			"TrinketMenu_OptKeepOpen",
			"TrinketMenu_OptMenuOnShift",
			"TrinketMenu_OptMenuOnRight",
			"TrinketMenu_OptNotify",
			"TrinketMenu_OptNotifyThirty",
			"TrinketMenu_OptNotifyChatAlso",
			"TrinketMenu_OptSetColumns",
			"TrinketMenu_OptHideOnLoad",
		}
		for _, name in ipairs(optCheckBoxes) do
			local cb = _G[name]
			if cb then
				T.SkinCheckBox(cb, 20)
			end
		end

		-- Skin sliders
		local sliders = {
			"TrinketMenu_OptColumnsSlider",
			"TrinketMenu_OptMainScaleSlider",
			"TrinketMenu_OptMenuScaleSlider",
		}
		for _, name in ipairs(sliders) do
			local slider = _G[name]
			if slider then
				T.SkinSlider(slider)
			end
		end
	end

	-- SubQueueFrame
	local subQueueFrame = TrinketMenu_SubQueueFrame
	if subQueueFrame then
		subQueueFrame:StripTextures()
		subQueueFrame:SetTemplate("Transparent")

		-- Sort priority and keep-equipped checkboxes
		T.SkinCheckBox(TrinketMenu_SortPriority, 20)
		T.SkinCheckBox(TrinketMenu_SortKeepEquipped, 20)

		-- Skin the SortDelay edit box
		if TrinketMenu_SortDelay then
			T.SkinEditBox(TrinketMenu_SortDelay)
		end

		-- Skin move buttons (use SmallButton style)
		local moveButtons = {
			"TrinketMenu_MoveTop",
			"TrinketMenu_MoveUp",
			"TrinketMenu_MoveDown",
			"TrinketMenu_MoveBottom",
		}
		for _, name in ipairs(moveButtons) do
			local btn = _G[name]
			if btn then
				btn:StripTextures()
				btn:SetTemplate("Default")
				btn:StyleButton()
			end
		end

		-- Skin delete button
		if TrinketMenu_Delete then
			TrinketMenu_Delete:StripTextures()
			TrinketMenu_Delete:SetTemplate("Default")
			TrinketMenu_Delete:StyleButton()
		end

		-- Skin profiles button
		if TrinketMenu_Profiles then
			TrinketMenu_Profiles:StripTextures()
			TrinketMenu_Profiles:SetTemplate("Default")
			TrinketMenu_Profiles:StyleButton()
		end
	end

	------------------------------------------------------------------------
	-- Sort List Frame
	------------------------------------------------------------------------
	local sortListFrame = TrinketMenu_SortListFrame
	if sortListFrame then
		sortListFrame:StripTextures()
		sortListFrame:SetTemplate("Transparent")

		-- Skin sort scroll bar
		if TrinketMenu_SortScroll then
			T.SkinScrollBar(TrinketMenu_SortScroll)
		end
	end

	------------------------------------------------------------------------
	-- Profiles Frame
	------------------------------------------------------------------------
	local profilesFrame = TrinketMenu_ProfilesFrame
	if profilesFrame then
		profilesFrame:StripTextures()
		profilesFrame:SetTemplate("Transparent")

		-- Skin profile name edit box
		if TrinketMenu_ProfileName then
			T.SkinEditBox(TrinketMenu_ProfileName)
		end

		-- Skin profile buttons
		local profileButtons = {
			"TrinketMenu_ProfilesDelete",
			"TrinketMenu_ProfilesLoad",
			"TrinketMenu_ProfilesSave",
			"TrinketMenu_ProfilesCancel",
		}
		for _, name in ipairs(profileButtons) do
			local btn = _G[name]
			if btn and btn.StripTextures then
				btn:StripTextures()
				btn:SetTemplate("Default")
				btn:StyleButton()
			end
		end
	end

	------------------------------------------------------------------------
	-- Profiles List Frame
	------------------------------------------------------------------------
	local profilesListFrame = TrinketMenu_ProfilesListFrame
	if profilesListFrame then
		profilesListFrame:StripTextures()
		profilesListFrame:SetTemplate("Transparent")

		-- Skin profile scroll bar
		if TrinketMenu_ProfileScroll then
			T.SkinScrollBar(TrinketMenu_ProfileScroll)
		end
	end

	------------------------------------------------------------------------
	-- Minimap Button
	------------------------------------------------------------------------
	if TrinketMenu_IconFrame then
		-- Resize minimap button to match ShestakUI minimap button style
		TrinketMenu_IconFrame:SetSize(20, 20)
		TrinketMenu_IconFrame:CreateBackdrop("Default")
		TrinketMenu_IconFrame.backdrop:SetPoint("TOPLEFT", TrinketMenu_IconFrame, 2, -2)
		TrinketMenu_IconFrame.backdrop:SetPoint("BOTTOMRIGHT", TrinketMenu_IconFrame, -2, 2)

		local normalTex = TrinketMenu_IconFrame:GetNormalTexture()
		if normalTex then
			normalTex:SetTexCoord(0.1, 0.9, 0.1, 0.9)
			normalTex:ClearAllPoints()
			normalTex:SetPoint("TOPLEFT", 3, -3)
			normalTex:SetPoint("BOTTOMRIGHT", -3, 3)
		end

		local pushedTex = TrinketMenu_IconFrame:GetPushedTexture()
		if pushedTex then
			pushedTex:SetTexCoord(0.1, 0.9, 0.1, 0.9)
			pushedTex:ClearAllPoints()
			pushedTex:SetPoint("TOPLEFT", 3, -3)
			pushedTex:SetPoint("BOTTOMRIGHT", -3, 3)
		end

		local highlightTex = TrinketMenu_IconFrame:GetHighlightTexture()
		if highlightTex then
			highlightTex:SetAlpha(0)
		end
	end

	------------------------------------------------------------------------
	-- Hook to reskin menu trinkets when menu is rebuilt
	------------------------------------------------------------------------
	if TrinketMenu.BuildMenu then
		hooksecurefunc(TrinketMenu, "BuildMenu", function()
			for i = 1, 30 do
				local btn = _G["TrinketMenu_Menu"..i]
				if btn and btn:IsShown() then
					SkinTrinketButton(btn)
				end
			end
		end)
	end

	-- Hook to reskin worn trinkets when they update
	if TrinketMenu.UpdateWornTrinkets then
		hooksecurefunc(TrinketMenu, "UpdateWornTrinkets", function()
			for i = 0, 1 do
				SkinTrinketButton(_G["TrinketMenu_Trinket"..i])
			end
		end)
	end
end)
