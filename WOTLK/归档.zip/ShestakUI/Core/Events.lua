local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	ShestakUI_Reforged: 统一事件总线
--	参考 NDui Init.lua 的设计：
--	1) 全局唯一 host frame，所有事件在此 frame 上只注册一次
--	2) events[event] 是以 func 为 key 的 set，天然去重
--	3) CLEU 事件在 host 上只注册一次（多模块共享一个 OnEvent），
--	   订阅者按原版契约无参数调用，自行调 CombatLogGetCurrentEventInfo() 取参
--	4) 无订阅者自动 UnregisterEvent，避免空跑
--	5) 提供 RegisterUnitEvent 的统一入口
--	旧 API 兼容：T.CLEU_Register / T.CLEU_RegisterFull 保持原签名
----------------------------------------------------------------------------------------

-- upvalue 提升
local next, pairs = next, pairs
local CombatLogGetCurrentEventInfo = CombatLogGetCurrentEventInfo

local events = {}
local host = CreateFrame("Frame")
T.EventHost = host

host:SetScript("OnEvent", function(_, event, ...)
	local funcs = events[event]
	if not funcs then return end
	if event == "COMBAT_LOG_EVENT_UNFILTERED" then
		-- CLEU 契约与原版 CLEUDispatcher 保持一致：
		-- 订阅者无参数，由它们自行调用 CombatLogGetCurrentEventInfo() 取参。
		-- 3.80.1 环境下 CombatLogGetCurrentEventInfo() 多次调用成本极低（返回缓存值），
		-- 主要优化在于：CLEU 事件只在 host 注册一次，不再 N 个 frame 各自注册。
		for func in pairs(funcs) do
			func()
		end
	else
		for func in pairs(funcs) do
			func(event, ...)
		end
	end
end)

-- 订阅一个事件（func 作 key 自动去重）
function T:RegisterEvent(event, func, unit1, unit2)
	func = func or self
	if not events[event] then
		events[event] = {}
		if unit1 then
			host:RegisterUnitEvent(event, unit1, unit2)
		else
			host:RegisterEvent(event)
		end
	end
	events[event][func] = true
end

-- 注销一个事件
function T:UnregisterEvent(event, func)
	func = func or self
	local funcs = events[event]
	if funcs and funcs[func] then
		funcs[func] = nil
		if not next(funcs) then
			events[event] = nil
			host:UnregisterEvent(event)
		end
	end
end

-- 一次性事件：触发后自动注销
function T:RegisterOnceEvent(event, func)
	func = func or self
	local function once(...)
		T:UnregisterEvent(event, once)
		return func(...)
	end
	T:RegisterEvent(event, once)
end

----------------------------------------------------------------------------------------
--	CLEU Dispatcher 接口（向后兼容原 T.CLEU_Register / T.CLEU_RegisterFull）
--	内部统一走 T:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", ...) 的通道
--	CLEU 事件只在 host frame 注册一次，所有 CLEU 订阅者共享一次 host OnEvent。
--	契约（与原版 CLEUDispatcher 一致）：
--	  订阅者函数被调用时不接收任何参数，自行调用 CombatLogGetCurrentEventInfo() 取参。
----------------------------------------------------------------------------------------

-- T.CLEU_Register(subEvent, func):
--   订阅特定 subEvent（如 "SPELL_CAST_SUCCESS"）的 CLEU 事件。
--   命中 subEvent 的订阅者被无参数调用，func 内部自行调 CombatLogGetCurrentEventInfo() 取参。
local subEvent_callbacks = {}
local full_callbacks = {}

local function CLEU_OnEvent()
	-- 契约：无参数。自行读 subEvent 做分发，避免在 host 里建 table
	local _, subEvent = CombatLogGetCurrentEventInfo()
	local cbs = subEvent_callbacks[subEvent]
	if cbs then
		for i = 1, #cbs do
			cbs[i]()
		end
	end
	-- 全量回调
	local full = full_callbacks
	if full[1] then
		for i = 1, #full do
			full[i]()
		end
	end
end

-- 是否已注册到 host
local cleu_registered = false
local function ensureCleuRegistered()
	if not cleu_registered then
		T:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", CLEU_OnEvent)
		cleu_registered = true
	end
end

function T.CLEU_Register(subEvent, func)
	if not subEvent_callbacks[subEvent] then
		subEvent_callbacks[subEvent] = {}
	end
	subEvent_callbacks[subEvent][#subEvent_callbacks[subEvent] + 1] = func
	ensureCleuRegistered()
end

function T.CLEU_RegisterFull(func)
	full_callbacks[#full_callbacks + 1] = func
	ensureCleuRegistered()
end

-- 移除 CLEU 订阅
function T.CLEU_Unregister(subEvent, func)
	local cbs = subEvent_callbacks[subEvent]
	if not cbs then return end
	for i = #cbs, 1, -1 do
		if cbs[i] == func then
			tremove(cbs, i)
		end
	end
	if #cbs == 0 then
		subEvent_callbacks[subEvent] = nil
	end
end

function T.CLEU_UnregisterFull(func)
	for i = #full_callbacks, 1, -1 do
		if full_callbacks[i] == func then
			tremove(full_callbacks, i)
		end
	end
end

----------------------------------------------------------------------------------------
--	Frame Pool：仿 NDui EnemyCD/RaidCD 的池化模式（统一封装以便 Filger/DR 复用）
--	用法：
--	local pool = T.CreateFramePool("Button", parent, "BackdropTemplate")
--	local frame = pool:Acquire()  -- 取一个空闲 frame，无则新建
--	pool:Release(frame)           -- 归还
----------------------------------------------------------------------------------------
function T.CreateFramePool(frameType, template, parent, createFunc)
	local pool = { cache = {}, active = {} }
	function pool:Acquire()
		local f = tremove(pool.cache, 1)
		if not f then
			f = createFunc and createFunc() or CreateFrame(frameType, nil, parent, template)
		end
		pool.active[f] = true
		f:Show()
		return f
	end
	function pool:Release(f)
		if not f then return end
		f:Hide()
		f:SetParent(nil)
		f:ClearAllPoints()
		pool.active[f] = nil
		pool.cache[#pool.cache + 1] = f
	end
	function pool:ReleaseAll()
		for f in pairs(pool.active) do
			self:Release(f)
		end
	end
	return pool
end

----------------------------------------------------------------------------------------
--	统一倒计时调度器（替代 per-aura / per-cooldown 独立 OnUpdate）
--	参考 NDui FormatTime 的自适应 nextUpdate 设计
--	用法：
--	T.TimerScheduler:Register(timerFrame, timerText, expiration, getRemainFunc)
--	T.TimerScheduler:Unregister(timerFrame)
----------------------------------------------------------------------------------------
local DAY, HOUR, MINUTE = 86400, 3600, 60
local scheduler = {
	active = {},
	_count = 0,
	_elapsed = 0,
}
T.TimerScheduler = scheduler

local updaters = CreateFrame("Frame")
updaters:Hide()
updaters:SetScript("OnUpdate", function(self, elapsed)
	-- 0.1s 节流批量刷新，避免每帧
	scheduler._elapsed = scheduler._elapsed + elapsed
	if scheduler._elapsed < 0.1 then return end
	scheduler._elapsed = 0

	local now = GetTime()
	-- 遍历所有激活的计时器
	for owner, info in pairs(scheduler.active) do
		local remain = info.expiration - now
		if remain <= 0 then
			-- 到期：清空文本（不隐藏框架，由调用方决定），移除调度
			if info.text and info.text.SetText then
				info.text:SetText("")
			end
			scheduler.active[owner] = nil
			scheduler._count = scheduler._count - 1
			if info.onExpire then info.onExpire(owner) end
		else
			-- 自适应文字生成：对齐 Functions.lua 原 FormatTime 的阈值与四舍五入
			-- remain>=5 显示整数（+0.5 后截断=四舍五入），<5 显示 1 位小数
			if info.text and info.text.SetText then
				local t
				if remain >= DAY then
					t = format("%dd", remain / DAY + 0.5)
				elseif remain >= HOUR then
					t = format("%dh", remain / HOUR + 0.5)
				elseif remain >= MINUTE then
					t = format("%dm", remain / MINUTE + 0.5)
				elseif remain >= 5 then
					t = format("%d", remain + 0.5)
				else
					t = format("%.1f", remain)
				end
				info.text:SetText(t)
			end
		end
	end

	-- 无激活计时器时停帧，避免常驻 OnUpdate
	if scheduler._count == 0 then
		self:Hide()
	end
end)

function scheduler:Register(owner, text, expiration, onExpire)
	if not owner then return end
	self.active[owner] = {
		text = text,
		expiration = expiration,
		onExpire = onExpire,
	}
	if not self.active[owner]._wasActive then
		self._count = self._count + 1
		self.active[owner]._wasActive = true
	end
	updaters:Show()
end

function scheduler:Unregister(owner)
	if self.active[owner] then
		self._count = self._count - 1
		self.active[owner] = nil
		if self._count <= 0 then
			self._count = 0
			updaters:Hide()
		end
	end
end

function scheduler:IsActive()
	return self._count > 0
end

-- 兼容旧接口：T.CreateAuraTimer 的 OnUpdate 现在统一走调度器
-- 原 button:SetScript("OnUpdate", T.CreateAuraTimer) 改为 T.RegisterAuraTimer(button, text, expiration)
-- text 通常是 button.remaining 或 button.timer (FontString)，expiration 是绝对时间戳 (GetTime 域)
function T.RegisterAuraTimer(button, text, expiration)
	if not button then return end
	text = text or button.timer or button.remaining
	expiration = expiration or button.expiration or button.timeLeft
	if not text then return end
	-- 如果之前已经注册过，先清理 per-aura OnUpdate（以防残留）
	button:SetScript("OnUpdate", nil)
	if expiration and expiration > 0 then
		scheduler:Register(button, text, expiration, function(b)
			-- 到期时隐藏/清空倒计时文本（兼容 remaining/timer 字段名）
			if b.remaining then b.remaining:Hide() end
			if b.timer then b.timer:SetText("") end
		end)
	else
		scheduler:Unregister(button)
	end
end

function T.UnregisterAuraTimer(button)
	if button then
		scheduler:Unregister(button)
	end
end

----------------------------------------------------------------------------------------
--	自适应 FormatTime：返回 text + nextUpdate（仿 NDui FormatTime）
--	用于需要单独处理下次刷新时机的场景（不同于 scheduler 内部固定 0.1s 节流）
----------------------------------------------------------------------------------------
function T.FormatTimeSmart(s)
	if s >= DAY then
		return format("%dd", s / DAY + 0.5), s % DAY
	elseif s >= HOUR then
		return format("%dh", s / HOUR + 0.5), s % HOUR
	elseif s >= MINUTE then
		return format("%dm", s / MINUTE + 0.5), s % MINUTE
	elseif s > 10 then
		return format("%d", s + 0.5), s - floor(s)
	elseif s > 3 then
		return format("%d", s + 0.5), s - floor(s)
	else
		return format("%.1f", s), s - tonumber(format("%.1f", s))
	end
end
