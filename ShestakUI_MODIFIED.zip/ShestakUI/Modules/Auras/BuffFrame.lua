local T, C, L = unpack(ShestakUI)
if C.aura.player_auras ~= true then return end

----------------------------------------------------------------------------------------
--	Style player buff(by Tukz)
----------------------------------------------------------------------------------------
local rowbuffs = 16
local alpha = 0
local space = 3

local GetFormattedTime = function(s)
	if s >= 86400 then
		return format("%dd", floor(s / 86400 + 0.5))
	elseif s >= 3600 then
		return format("%dh", floor(s / 3600 + 0.5))
	elseif s >= 60 then
		return format("%dm", floor(s / 60 + 0.5))
	end
	return floor(s + 0.5)
end

local BuffsAnchor = CreateFrame("Frame", "BuffsAnchor", UIParent)
BuffsAnchor:SetPoint(unpack(C.position.player_buffs))
BuffsAnchor:SetSize((15 * C.aura.player_buff_size) + 42, (C.aura.player_buff_size * 2) + space)

local function UpdateDuration(aura, timeLeft)
	local duration = aura.Duration
	if timeLeft and C.aura.show_timer == true then
		duration:SetVertexColor(1, 1, 1)
		if canaccessvalue(timeLeft) then -- BETA
			duration:SetFormattedText(GetFormattedTime(timeLeft))
		end
	else
		duration:Hide()
	end
end

-- Reposition
C_Timer.After(0.2, function()
	local left = T.IsFramePositionedLeft(BuffsAnchor)
	if left then
		local previousBuff, aboveBuff
		for index, aura in ipairs(BuffFrame.auraFrames) do
			aura:ClearAllPoints()
			if (index > 1) and (mod(index, rowbuffs) == 1) then
				aura:SetPoint("TOP", aboveBuff, "BOTTOM", 0, -space)
				aboveBuff = aura
			elseif index == 1 then
				aura:SetPoint("TOPLEFT", BuffsAnchor, "TOPLEFT", 0, 0)
				aboveBuff = aura
			else
				aura:SetPoint("LEFT", previousBuff, "RIGHT", space, 0)
			end
			previousBuff = aura
		end
	end
end)

hooksecurefunc(BuffFrame.AuraContainer, "UpdateGridLayout", function(_, auras)
	local previousBuff, aboveBuff
	for index, aura in ipairs(auras) do
		aura:SetSize(C.aura.player_buff_size, C.aura.player_buff_size)
		-- 私有光环锚点由系统管理，跳过常规样式美化
		if not aura.isAuraAnchor then
			aura:SetTemplate("Default")

			if aura.TempEnchantBorder then
				aura.TempEnchantBorder:SetAlpha(0)
				hooksecurefunc(aura.TempEnchantBorder, "Show", function()
					aura:SetBackdropBorderColor(0.6, 0.1, 0.6)
				end)

				hooksecurefunc(aura.TempEnchantBorder, "Hide", function()
					if C.aura.classcolor_border == true then
						aura:SetBackdropBorderColor(unpack(C.media.classborder_color))
					else
						aura:SetBackdropBorderColor(unpack(C.media.border_color))
					end
				end)
			end
		end

		aura:ClearAllPoints()
		if (index > 1) and (mod(index, rowbuffs) == 1) then
			aura:SetPoint("TOP", aboveBuff, "BOTTOM", 0, -space)
			aboveBuff = aura
		elseif index == 1 then
			aura:SetPoint("TOPRIGHT", BuffsAnchor, "TOPRIGHT", 0, 0)
			aboveBuff = aura
		else
			aura:SetPoint("RIGHT", previousBuff, "LEFT", -space, 0)
		end

		previousBuff = aura

		-- 仅对普通纹理类型的 Icon 应用裁切和图层设置
		if aura.Icon and aura.Icon.SetTexCoord then
			aura.Icon:CropIcon()
			if aura.Icon.SetDrawLayer then
				aura.Icon:SetDrawLayer("BORDER")
			end
		end

		local duration = aura.Duration
		if duration and duration.SetFont then
			duration:ClearAllPoints()
			duration:SetPoint("CENTER", 2, 1)
			duration:SetDrawLayer("ARTWORK")
			duration:SetFont(C.font.auras_font, C.font.auras_font_size, C.font.auras_font_style)
			duration:SetShadowOffset(C.font.auras_font_shadow and 1 or 0, C.font.auras_font_shadow and -1 or 0)
		end

		if aura.UpdateDuration and not aura.hook then
			hooksecurefunc(aura, "UpdateDuration", function(aura, timeLeft)
				UpdateDuration(aura, timeLeft)
			end)
			if C.aura.player_buff_mouseover then
				aura:SetParent(BuffsAnchor)
				aura:HookScript("OnEnter", function()
					BuffsAnchor:SetAlpha(1)
				end)
				aura:HookScript("OnLeave", function()
					BuffsAnchor:SetAlpha(alpha)
				end)
			end
			aura.hook = true
		end

		if aura.Count and aura.Count.SetFont then -- need to check exist to prevent error in EditMode
			aura.Count:ClearAllPoints()
			aura.Count:SetPoint("BOTTOMRIGHT", 2, 0)
			aura.Count:SetDrawLayer("ARTWORK")
			aura.Count:SetFont(C.font.auras_font, C.font.auras_font_size, C.font.auras_font_style)
			aura.Count:SetShadowOffset(C.font.auras_font_shadow and 1 or 0, C.font.auras_font_shadow and -1 or 0)
		end
	end
end)

-- Mouseover
if C.aura.player_buff_mouseover then
	BuffsAnchor:SetAlpha(alpha)
	BuffsAnchor:HookScript("OnEnter", function()
		BuffsAnchor:SetAlpha(1)
	end)
	BuffsAnchor:HookScript("OnLeave", function()
		BuffsAnchor:SetAlpha(alpha)
	end)
end

-- Hide collapse button
BuffFrame.CollapseAndExpandButton:Kill()

-- Hide debuffs
DebuffFrame.AuraContainer:Hide()

-- Move Private Auras
local PrivateAnchor = CreateFrame("Frame", "PrivateAnchor", UIParent)
PrivateAnchor:SetPoint("TOPRIGHT", BuffsAnchor, "BOTTOMRIGHT", 0, -5)
PrivateAnchor:SetSize((3 * (C.aura.player_buff_size + space)) - space, (C.aura.player_buff_size * 2) - (space * 2))

hooksecurefunc(DebuffFrame.AuraContainer, "UpdateGridLayout", function(_, auras)
	local previousBuff, aboveBuff
	for index, aura in ipairs(auras) do
		aura:ClearAllPoints()
		if (index > 1) and (mod(index, rowbuffs) == 1) then
			aura:SetPoint("TOP", aboveBuff, "BOTTOM", 0, -space)
			aboveBuff = aura
		elseif index == 1 then
			aura:SetPoint("TOPRIGHT", PrivateAnchor, "TOPRIGHT", 1, C.aura.player_buff_size * 2 - (space * 2))
			aboveBuff = aura
		else
			aura:SetPoint("RIGHT", previousBuff, "LEFT", -space, 0)
		end

		previousBuff = aura
	end
end)