local T, C, L = unpack(ShestakUI)
if C.actionbar.enable ~= true or C.actionbar.micromenu ~= true then return end

----------------------------------------------------------------------------------------
--	Micro menu (rewritten for 3.80.1 NewClassicUI)
--	Keeps Blizzard native textures, wraps each button in a backdrop frame,
--	and positions them dynamically in a horizontal row.
----------------------------------------------------------------------------------------

local _G = _G
local tinsert = tinsert

local microMenu = CreateFrame("Frame", "MicroAnchor", T_PetBattleFrameHider or UIParent)
microMenu:SetPoint(unpack(C.position.micro_menu))

if C.actionbar.micromenu_mouseover then
	microMenu:SetAlpha(0)
	microMenu:SetScript("OnEnter", function() microMenu:SetAlpha(1) end)
	microMenu:SetScript("OnLeave", function() microMenu:SetAlpha(0) end)
end

----------------------------------------------------------------------------------------
--	Build button list for 3.80.1 NewClassicUI
----------------------------------------------------------------------------------------
local buttonList = {}

local microButtonNames = {
	"CharacterMicroButton",
	"SpellbookMicroButton",
	"TalentMicroButton",
	"AchievementMicroButton",
	"QuestLogMicroButton",
	"SocialsMicroButton",
	"PVPMicroButton",
	"LFGMicroButton",
	"CollectionsMicroButton",
	-- StoreMicroButton removed: not available on 3.80.1 时光服
	"MainMenuMicroButton",
}

local guildButtonName = "GuildMicroButton"

----------------------------------------------------------------------------------------
--	Create wrapper frame for a real Blizzard micro button
--	Keeps native textures, just reskins the border/background.
----------------------------------------------------------------------------------------
local btnSize = 22
local btnSpacing = 3

local function CreateButtonWrapper(parent, buttonName)
	local bu = _G[buttonName]
	if not bu then return end

	-- Wrapper frame with backdrop border
	local wrapper = CreateFrame("Frame", nil, parent)
	wrapper:SetSize(btnSize, btnSize)
	wrapper:SetTemplate("Default")
	tinsert(buttonList, wrapper)

	-- Store reference
	bu.__owner = wrapper

	-- Reparent the real button into the wrapper
	bu:SetParent(wrapper)
	-- Prevent Blizzard from re-parenting it back
	hooksecurefunc(bu, "SetParent", function(self, newParent)
		if newParent ~= self.__owner and not self.__reparenting then
			self.__reparenting = true
			self:SetParent(self.__owner)
			self.__reparenting = false
		end
	end)

	-- Keep the button filling the wrapper
	bu:ClearAllPoints()
	bu:SetAllPoints()
	hooksecurefunc(bu, "SetPoint", function(self)
		if self:GetNumPoints() > 1 or (self:GetNumPoints() == 1 and select(2, self:GetPoint()) ~= self.__owner) then
			self:ClearAllPoints()
			self:SetAllPoints()
		end
	end)

	-- Set hit rect so the entire wrapper area is clickable
	bu:SetHitRectInsets(0, 0, 0, 0)

	-- Skin native textures: crop and reposition inside the backdrop border
	local normal = bu:GetNormalTexture()
	local pushed = bu:GetPushedTexture()
	local disabled = bu:GetDisabledTexture()

	-- Classic texture coord crop (removes the bulky button border from the icon)
	local texCoord = {0.17, 0.87, 0.5, 0.908}

	if normal then
		normal:SetTexCoord(unpack(texCoord))
		normal:ClearAllPoints()
		normal:SetPoint("TOPLEFT", wrapper, "TOPLEFT", 2, -2)
		normal:SetPoint("BOTTOMRIGHT", wrapper, "BOTTOMRIGHT", -2, 2)
	end

	if pushed then
		pushed:SetTexCoord(unpack(texCoord))
		pushed:ClearAllPoints()
		pushed:SetPoint("TOPLEFT", wrapper, "TOPLEFT", 2, -2)
		pushed:SetPoint("BOTTOMRIGHT", wrapper, "BOTTOMRIGHT", -2, 2)
	end

	if disabled then
		disabled:SetTexCoord(unpack(texCoord))
		disabled:ClearAllPoints()
		disabled:SetPoint("TOPLEFT", wrapper, "TOPLEFT", 2, -2)
		disabled:SetPoint("BOTTOMRIGHT", wrapper, "BOTTOMRIGHT", -2, 2)
	end

	-- Flash texture cleanup
	local flash = bu.Flash
	if flash then
		flash:SetTexture(0)
	end

	-- CharacterMicroButton: reposition portrait inside backdrop
	if buttonName == "CharacterMicroButton" then
		hooksecurefunc("UpdateMicroButtons", function()
			local portrait = _G.MicroButtonPortrait
			if portrait then
				portrait:ClearAllPoints()
				portrait:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				portrait:SetPoint("TOPLEFT", wrapper, "TOPLEFT", 2, -2)
				portrait:SetPoint("BOTTOMRIGHT", wrapper, "BOTTOMRIGHT", -2, 2)
			end
		end)
	end

	-- PVP button: replace missing texture with faction icon
	if buttonName == "PVPMicroButton" then
		local faction = UnitFactionGroup("player")
		local iconPath = faction == "Horde" and "Interface\\Icons\\inv_bannerpvp_01" or "Interface\\Icons\\inv_bannerpvp_02"
		-- Set the icon on all three texture layers of the native button
		-- Reset TexCoord for square icon (override the micro-button crop)
		if normal then
			normal:SetTexture(iconPath)
			normal:SetTexCoord(0.05, 0.95, 0.05, 0.95)
		end
		if pushed then
			pushed:SetTexture(iconPath)
			pushed:SetTexCoord(0.05, 0.95, 0.05, 0.95)
		end
		if disabled then
			disabled:SetTexture(iconPath)
			disabled:SetTexCoord(0.05, 0.95, 0.05, 0.95)
		end
	end

	-- MainMenu: hide performance bar and kill OnUpdate
	if buttonName == "MainMenuMicroButton" then
		local perfBar = _G.MainMenuBarPerformanceBar
		if perfBar then perfBar:SetTexture(0) end
		bu:SetScript("OnUpdate", nil)
	end

	-- Highlight texture
	bu:SetHighlightTexture(0)

	-- Hook for class color border on hover
	bu:HookScript("OnEnter", function()
		wrapper:SetBackdropBorderColor(unpack(C.media.classborder_color))
		if C.actionbar.micromenu_mouseover then
			microMenu:SetAlpha(1)
		end
	end)
	bu:HookScript("OnLeave", function()
		wrapper:SetBackdropBorderColor(unpack(C.media.border_color))
		if C.actionbar.micromenu_mouseover then
			microMenu:SetAlpha(0)
		end
	end)

	return wrapper
end

----------------------------------------------------------------------------------------
--	Create all micro buttons
----------------------------------------------------------------------------------------
local wrappers = {}
for i, name in pairs(microButtonNames) do
	local wrapper = CreateButtonWrapper(microMenu, name)
	if wrapper then
		wrappers[name] = wrapper
	end
end

-- GuildMicroButton: overlay on top of SocialsMicroButton
local guildBu = _G[guildButtonName]
if guildBu and wrappers["SocialsMicroButton"] then
	local socialWrapper = wrappers["SocialsMicroButton"]
	guildBu:SetParent(socialWrapper)
	guildBu:ClearAllPoints()
	guildBu:SetAllPoints()
	guildBu.__owner = socialWrapper
	hooksecurefunc(guildBu, "SetParent", function(self, newParent)
		if newParent ~= self.__owner and not self.__reparenting then
			self.__reparenting = true
			self:SetParent(self.__owner)
			self.__reparenting = false
		end
	end)
	hooksecurefunc(guildBu, "SetPoint", function(self)
		self:ClearAllPoints()
		self:SetAllPoints()
	end)
	-- Skin GuildMicroButton textures
	local gNormal = guildBu:GetNormalTexture()
	local gPushed = guildBu:GetPushedTexture()
	local gDisabled = guildBu:GetDisabledTexture()
	local texCoord = {0.17, 0.87, 0.5, 0.908}
	if gNormal then
		gNormal:SetTexCoord(unpack(texCoord))
		gNormal:ClearAllPoints()
		gNormal:SetPoint("TOPLEFT", socialWrapper, "TOPLEFT", 2, -2)
		gNormal:SetPoint("BOTTOMRIGHT", socialWrapper, "BOTTOMRIGHT", -2, 2)
	end
	if gPushed then
		gPushed:SetTexCoord(unpack(texCoord))
		gPushed:ClearAllPoints()
		gPushed:SetPoint("TOPLEFT", socialWrapper, "TOPLEFT", 2, -2)
		gPushed:SetPoint("BOTTOMRIGHT", socialWrapper, "BOTTOMRIGHT", -2, 2)
	end
	if gDisabled then
		gDisabled:SetTexCoord(unpack(texCoord))
		gDisabled:ClearAllPoints()
		gDisabled:SetPoint("TOPLEFT", socialWrapper, "TOPLEFT", 2, -2)
		gDisabled:SetPoint("BOTTOMRIGHT", socialWrapper, "BOTTOMRIGHT", -2, 2)
	end
	if guildBu.Flash then guildBu.Flash:SetTexture(0) end
	guildBu:SetHighlightTexture(0)
end

----------------------------------------------------------------------------------------
--	Position buttons dynamically (horizontal row)
----------------------------------------------------------------------------------------
local function LayoutButtons()
	local numButtons = #buttonList
	if numButtons == 0 then return end

	for i = 1, numButtons do
		local btn = buttonList[i]
		btn:SetSize(btnSize, btnSize)
		btn:ClearAllPoints()
		if i == 1 then
			btn:SetPoint("TOPLEFT", microMenu, "TOPLEFT")
		else
			btn:SetPoint("LEFT", buttonList[i - 1], "RIGHT", btnSpacing, 0)
		end
	end

	local width = numButtons * btnSize + (numButtons - 1) * btnSpacing
	local height = btnSize
	microMenu:SetSize(width, height)
end

LayoutButtons()

----------------------------------------------------------------------------------------
--	Handle UpdateMicroButtons (Blizzard re-anchors buttons, we need to re-assert)
----------------------------------------------------------------------------------------
if T.Classic then
	hooksecurefunc("UpdateMicroButtons", function()
		-- Re-layout after Blizzard repositions things
		LayoutButtons()
		-- Re-position portrait for CharacterMicroButton
		local portrait = _G.MicroButtonPortrait
		local charWrapper = wrappers["CharacterMicroButton"]
		if portrait and charWrapper then
			portrait:ClearAllPoints()
			portrait:SetTexCoord(0.1, 0.9, 0.1, 0.9)
			portrait:SetPoint("TOPLEFT", charWrapper, "TOPLEFT", 2, -2)
			portrait:SetPoint("BOTTOMRIGHT", charWrapper, "BOTTOMRIGHT", -2, 2)
		end
	end)
end

----------------------------------------------------------------------------------------
--	Hide default Blizzard micro menu parent elements on NewClassicUI
----------------------------------------------------------------------------------------
if T.NewClassicUI then
	local microContainer = _G.MicroButtonAndBagsBar or _G.MicroMenu
	if microContainer then
		microContainer:SetParent(T.HiddenFrame)
	end
	local bagsBar = _G.BagsBar
	if bagsBar then
		bagsBar:SetParent(T.HiddenFrame)
	end
end
