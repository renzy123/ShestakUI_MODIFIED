﻿local T, C, L = unpack(ShestakUI)
if C.chat.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Copy Chat (Enhanced, ElvUI-inspired: draggable, resizable, searchable)
----------------------------------------------------------------------------------------

local frame = nil
local editBox = nil
local searchBox = nil
local scrollArea = nil
local font = nil
local isf = nil

local sizes = {
	":14:14",
	":15:15",
	":16:16",
	":12:20",
	":14"
}

local canChangeMessage = function(arg1, id)
	if id and arg1 == "" then return id end
end

local function MessageIsProtected(message)
	return message and (message ~= gsub(message, "(:?|?)|K(.-)|k", canChangeMessage))
end

local function StripLine(text)
	text = text:gsub("|TInterface\\TargetingFrame\\UI%-RaidTargetingIcon_(%d+)[^|]+|t", "{rt%1}")
	text = text:gsub("|T13700(%d)[^|]+|t", "{rt%1}")
	text = text:gsub("|T[^|]+|t", "")
	text = text:gsub("|A[^|]+|a", "")
	text = text:gsub("|H(.-)|h(.-)|h", "%2")
	return text
end

local allLines = {} -- store all lines for search filtering

local function CopyChat_FilterLines(searchText)
	if not editBox then return end
	searchText = searchText and tostring(searchText):lower() or ""

	if searchText == "" then
		local text = table.concat(allLines, "\n")
		editBox:SetText(text)
		return
	end

	local filtered = {}
	for _, line in ipairs(allLines) do
		if line:lower():find(searchText, 1, true) then
			tinsert(filtered, line)
		end
	end
	local text = table.concat(filtered, "\n")
	editBox:SetText(text)
end

local function CreatCopyFrame()
	frame = CreateFrame("Frame", "CopyFrame", UIParent)
	frame:CreatePanel("Transparent", 700, 400, "CENTER", UIParent, "CENTER", 0, 100)
	frame:SetFrameStrata("DIALOG")
	tinsert(UISpecialFrames, "CopyFrame")
	frame:Hide()
	frame:EnableMouse(true)
	frame:SetMovable(true)
	frame:SetResizable(true)
	frame:SetClampedToScreen(true)
	if frame.SetMinResize then frame:SetMinResize(300, 150) end

	-- Title bar area for dragging (leave room for search box on the right)
	local titleBar = CreateFrame("Frame", nil, frame)
	titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 4, -4)
	titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -250, 0)
	titleBar:SetHeight(22)
	titleBar:EnableMouse(true)
	titleBar:SetScript("OnMouseDown", function()
		frame:StartMoving()
	end)
	titleBar:SetScript("OnMouseUp", function()
		frame:StopMovingOrSizing()
	end)

	-- Search box (do NOT use CreatePanel — it sets FrameStrata=BACKGROUND which blocks mouse clicks)
	searchBox = CreateFrame("EditBox", "CopySearchBox", frame)
	searchBox:SetSize(200, 22)
	searchBox:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -40, -6)
	searchBox:SetAutoFocus(false)
	searchBox:SetFont(C.media.normal_font, 12, "")
	searchBox:SetTextInsets(22, 5, 0, 0)
	searchBox:EnableMouse(true)
	-- Manual backdrop (same as CreatePanel "Default" but without BACKGROUND strata)
	Mixin(searchBox, BackdropTemplateMixin)
	searchBox:SetBackdrop({
		bgFile = C.media.blank, edgeFile = C.media.blank, edgeSize = T.mult or 1,
		insets = {left = -(T.mult or 1), right = -(T.mult or 1), top = -(T.mult or 1), bottom = -(T.mult or 1)}
	})
	searchBox:SetBackdropColor(unpack(C.media.backdrop_color))
	searchBox:SetBackdropBorderColor(unpack(C.media.border_color))
	searchBox:SetScript("OnEscapePressed", function() searchBox:ClearFocus() end)
	searchBox:SetScript("OnTextChanged", function(self)
		CopyChat_FilterLines(self:GetText())
	end)

	local searchIcon = searchBox:CreateTexture(nil, "OVERLAY")
	searchIcon:SetPoint("LEFT", searchBox, "LEFT", 4, 0)
	searchIcon:SetTexture("Interface\\Common\\UI-Searchbox-Icon")
	searchIcon:SetSize(14, 14)

	-- Placeholder text
	local placeholder = searchBox:CreateFontString(nil, "OVERLAY")
	placeholder:SetFont(C.media.normal_font, 12, "")
	placeholder:SetPoint("LEFT", searchBox, "LEFT", 22, 0)
	placeholder:SetText("|cFF888888"..SEARCH.."|r")
	placeholder:SetTextColor(0.5, 0.5, 0.5)
	searchBox:SetScript("OnEditFocusGained", function() placeholder:Hide() end)
	searchBox:SetScript("OnEditFocusLost", function()
		if searchBox:GetText() == "" then placeholder:Show() end
	end)

	-- EditBox for chat content
	editBox = CreateFrame("EditBox", "CopyBox", frame)
	editBox:SetMultiLine(true)
	editBox:SetMaxLetters(0)
	editBox:SetAutoFocus(false)
	editBox:SetFontObject(ChatFontNormal)
	editBox:SetWidth(680) -- CRITICAL: EditBox in ScrollFrame must have explicit width for text to render
	editBox:SetScript("OnEscapePressed", function() frame:Hide() end)

	editBox:SetScript("OnTextSet", function(self)
		local text = self:GetText()
		for _, size in pairs(sizes) do
			if string.find(text, size) and not string.find(text, size.."]") then
				self:SetText(string.gsub(text, size, ":12:12"))
			end
		end
	end)

	-- Scroll frame
	scrollArea = CreateFrame("ScrollFrame", "CopyScroll", frame, "ScrollFrameTemplate")
	scrollArea:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -30)
	scrollArea:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -27, 8)
	scrollArea:SetScrollChild(editBox)
	T.SkinScrollBar(CopyScroll.ScrollBar)

	-- Close button
	local close = CreateFrame("Button", "CopyCloseButton", frame, "UIPanelCloseButton")
	T.SkinCloseButton(close)

	-- Resize handle
	local resize = CreateFrame("Button", nil, frame)
	resize:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -4, 4)
	resize:SetSize(16, 16)
	resize:SetNormalTexture("Interface\ChatFrame\UI-ChatCorner")
	resize:SetScript("OnMouseDown", function()
		frame:StartSizing("BOTTOMRIGHT")
	end)
	resize:SetScript("OnMouseUp", function()
		frame:StopMovingOrSizing()
		-- Update editBox width after resize
		editBox:SetWidth(scrollArea:GetWidth() - 20)
	end)
	resize:SetScript("OnMouseUp", function()
		frame:StopMovingOrSizing()
	end)

	font = frame:CreateFontString(nil, nil, "GameFontNormal")
	font:Hide()

	isf = true
end

local scrollDown = function()
	CopyScroll:SetVerticalScroll(CopyScroll:GetVerticalScrollRange() or 0)
end

local function Copy(cf)
	if not isf then CreatCopyFrame() end
	wipe(allLines)

	-- Method 1: GetMessageInfo API (TBC 2.4+, works on 3.80.1 Cata)
	local numMessages = cf:GetNumMessages()
	if numMessages and numMessages > 0 then
		for i = 1, numMessages do
			local ok, msg = pcall(function() return cf:GetMessageInfo(i) end)
			if ok and msg and type(msg) == "string" and not MessageIsProtected(msg) then
				local cleanLine = StripLine(msg)
				if cleanLine ~= "" then
					tinsert(allLines, cleanLine)
				end
			end
		end
	end

	-- Method 2: FontStringContainer iteration (Cata+)
	if #allLines == 0 and cf.FontStringContainer then
		for i = 1, cf.FontStringContainer:GetNumChildren() do
			local child = select(i, cf.FontStringContainer:GetChildren())
			if child and child.GetText and child:GetText() and child:IsShown() then
				local text = StripLine(child:GetText())
				if text ~= "" then
					tinsert(allLines, text)
				end
			end
		end
		if #allLines == 0 then
			for _, region in ipairs({cf.FontStringContainer:GetRegions()}) do
				if region.GetText and region:GetText() and region:IsShown() then
					local text = StripLine(region:GetText())
					if text ~= "" then
						tinsert(allLines, text)
					end
				end
			end
		end
	end

	-- Method 3: Universal fallback — iterate ChatFrame FontStrings directly
	if #allLines == 0 then
		for _, region in ipairs({cf:GetRegions()}) do
			if region.IsObjectType and region:IsObjectType("FontString") and region:IsShown() and region:GetText() then
				local text = StripLine(region:GetText())
				if text ~= "" then
					tinsert(allLines, text)
				end
			end
		end
		if #allLines == 0 then
			for _, child in ipairs({cf:GetChildren()}) do
				for _, region in ipairs({child:GetRegions()}) do
					if region.IsObjectType and region:IsObjectType("FontString") and region:IsShown() and region:GetText() then
						local text = StripLine(region:GetText())
						if text ~= "" then
							tinsert(allLines, text)
						end
					end
				end
			end
		end
	end

	if frame:IsShown() then frame:Hide() return end

	-- Clear search
	if searchBox then
		searchBox:SetText("")
	end

	local text = table.concat(allLines, "\n")
	editBox:SetText(text)
	-- Ensure editBox width matches scrollArea after resize
	editBox:SetWidth(scrollArea:GetWidth() - 20)
	frame:Show()

	C_Timer.After(0, scrollDown)
end

-- Create copy buttons on each chat frame
for i = 1, NUM_CHAT_WINDOWS do
	local cf = _G[format("ChatFrame%d", i)]
	local button = CreateFrame("Button", format("ButtonCF%d", i), cf)
	button:SetPoint("TOPRIGHT", 0, -4)
	button:SetSize(20, 22)
	button:SetAlpha(0.35)

	local icon = button:CreateTexture(nil, "OVERLAY")
	icon:SetPoint("CENTER")
	icon:SetTexture("Interface\\BUTTONS\\UI-GuildButton-PublicNote-Up")
	icon:SetSize(14, 14)

	button:SetScript("OnMouseUp", function(_, btn)
		if btn == "RightButton" then
			ToggleFrame(ChatMenu)
		elseif btn == "MiddleButton" then
			RandomRoll(1, 100)
		else
			Copy(cf)
		end
	end)
	button:SetScript("OnEnter", function() button:SetAlpha(1) end)
	button:SetScript("OnLeave", function() button:SetAlpha(0.35) end)
end

SlashCmdList.COPY_CHAT = function()
	Copy(_G["ChatFrame1"])
end
