local T, C, L = unpack(ShestakUI)
if C.automation.decline_duel ~= true then return end

----------------------------------------------------------------------------------------
--	Auto decline duel
----------------------------------------------------------------------------------------
local disable = false
local frame = CreateFrame("Frame")
frame:RegisterEvent("DUEL_REQUESTED")
frame:RegisterEvent("PET_BATTLE_PVP_DUEL_REQUESTED")
frame:SetScript("OnEvent", function(_, event, name)
	if disable == true then return end
	if event == "DUEL_REQUESTED" then
		CancelDuel()
		RaidWarningUtil.AddMessage(L_INFO_DUEL..name, {r = 0.41, g = 0.8, b = 0.94}, 3)
		print(format("|cffffff00"..L_INFO_DUEL..name.."."))
		StaticPopup_Hide("DUEL_REQUESTED")
	elseif event == "PET_BATTLE_PVP_DUEL_REQUESTED" then
		C_PetBattles.CancelPVPDuel()
		RaidWarningUtil.AddMessage(L_INFO_PET_DUEL..name, {r = 0.41, g = 0.8, b = 0.94}, 3)
		print(format("|cffffff00"..L_INFO_PET_DUEL..name.."."))
		StaticPopup_Hide("PET_BATTLE_PVP_DUEL_REQUESTED")
	end
end)

SlashCmdList.DISABLEDECLINE = function()
	if not disable then
		disable = true
	else
		disable = false
	end
end

SLASH_DISABLEDECLINE1 = "/disduel"
SLASH_DISABLEDECLINE2 = "/вшывгуд"