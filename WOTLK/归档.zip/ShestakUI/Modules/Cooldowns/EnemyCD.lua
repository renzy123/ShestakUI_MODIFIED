local T, C, L = unpack(ShestakUI)
if C.enemycooldown.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Enemy cooldowns(alEnemyCD by Allez)
----------------------------------------------------------------------------------------
local show = {
	none = C.enemycooldown.show_always,
	pvp = C.enemycooldown.show_inpvp,
	arena = C.enemycooldown.show_inarena,
}
local direction = C.enemycooldown.direction
local icons = {}
local band = bit.band
local pos = C.position.enemy_cooldown
local limit = (C.actionbar.button_size * 12)/C.enemycooldown.size
local space = C.filger.cooldown_space
local GetTime = GetTime
local IsInInstance = IsInInstance
local instanceType

local EnemyCDAnchor = CreateFrame("Frame", "EnemyCDAnchor", UIParent)
if C.unitframe.enable ~= true then
	EnemyCDAnchor:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
else
	if C.unitframe.plugins_swing == true then
		EnemyCDAnchor:SetPoint(unpack(C.position.enemy_cooldown))
	else
		EnemyCDAnchor:SetPoint(pos[1], pos[2], pos[3], pos[4], pos[5] - 12)
	end
end
if direction == "UP" or direction == "DOWN" then
	EnemyCDAnchor:SetSize(C.enemycooldown.size, (C.enemycooldown.size * 5) + 12)
else
	EnemyCDAnchor:SetSize((C.enemycooldown.size * 5) + 12, C.enemycooldown.size)
end

local OnEnter = function(self)
	if IsShiftKeyDown() then
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetSpellByID(self.sID)
		GameTooltip:SetClampedToScreen(true)
		GameTooltip:AddLine(" ")
		GameTooltip:AddLine(DONE_BY.." "..self.name)
		GameTooltip:Show()
	end
end

local function sortByExpiration(a, b)
	return a.endTime < b.endTime
end

local UpdatePositions = function()
	for i = 1, #icons do
		icons[i]:ClearAllPoints()
		if i == 1 then
			icons[i]:SetPoint("BOTTOMLEFT", EnemyCDAnchor, "BOTTOMLEFT", 0, 0)
		elseif i < limit then
			if direction == "UP" then
				icons[i]:SetPoint("BOTTOM", icons[i-1], "TOP", 0, space)
			elseif direction == "DOWN" then
				icons[i]:SetPoint("TOP", icons[i-1], "BOTTOM", 0, -space)
			elseif direction == "LEFT" then
				icons[i]:SetPoint("RIGHT", icons[i-1], "LEFT", -space, 0)
			else
				icons[i]:SetPoint("LEFT", icons[i-1], "RIGHT", space, 0)
			end
		end
		if i < limit then
			icons[i]:SetAlpha(1)
		else
			icons[i]:SetAlpha(0)
		end
		icons[i].id = i
	end
end

-- 前向声明：StopTimer 闭包需要引用 ReleaseIcon，必须在 StopTimer 之前声明为 local，
-- 否则 StopTimer 闭包里的 ReleaseIcon 会指向全局变量（nil）而非后面 local 声明的那个。
local ReleaseIcon

local StopTimer = function(icon)
	T.TimerScheduler:Unregister(icon)
	icon:Hide()
	tremove(icons, icon.id)
	ReleaseIcon(icon)
	UpdatePositions()
end

-- Frame pool: pre-create icons and reuse them instead of creating in combat
local iconPool = {}
local poolSize = 0

local CreateIcon = function()
	local icon = CreateFrame("Frame", nil, UIParent)
	icon:SetSize(C.enemycooldown.size, C.enemycooldown.size)
	icon:SetTemplate("Default")
	icon.Cooldown = CreateFrame("Cooldown", nil, icon, "CooldownFrameTemplate")
	icon.Cooldown:SetPoint("TOPLEFT", 2, -2)
	icon.Cooldown:SetPoint("BOTTOMRIGHT", -2, 2)
	icon.Cooldown:SetReverse(true)
	icon.Texture = icon:CreateTexture(nil, "BORDER")
	icon.Texture:SetPoint("TOPLEFT", 2, -2)
	icon.Texture:SetPoint("BOTTOMRIGHT", -2, 2)
	return icon
end

local AcquireIcon = function()
	if poolSize > 0 then
		local icon = iconPool[poolSize]
		iconPool[poolSize] = nil
		poolSize = poolSize - 1
		return icon
	end
	return CreateIcon()
end

ReleaseIcon = function(icon)
	iconPool[poolSize + 1] = icon
	poolSize = poolSize + 1
end

local StartTimer = function(sGUID, sID, sName)
	-- 防御：sID 不在 EnemySpells 表中时直接返回，避免后续 GetTime() + nil 报错
	-- （slash 测试命令或数据变动时可能出现未收录的 spell ID）
	if not T.EnemySpells[sID] then return end
	local _, _, texture = GetSpellInfo(sID)
	local icon = AcquireIcon()
	icon.Texture:SetTexture(texture)
	icon.Texture:SetTexCoord(0.1, 0.9, 0.1, 0.9)
	icon.endTime = GetTime() + T.EnemySpells[sID]
	local _, class, _, _, _, name = GetPlayerInfoByGUID(sGUID)

	-- false check for pet
	if not class then
		class = select(2, UnitClass(sName))
		name = sName
	end

	local color = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[class]
	if color then
		name = format("|cff%02x%02x%02x%s|r", color.r * 255, color.g * 255, color.b * 255, name)
		if C.enemycooldown.class_color then
			icon:SetBackdropBorderColor(color.r, color.g, color.b)
		end
	end
	for _, v in pairs(icons) do
		if v.name == name and v.sID == sID then
			StopTimer(v)
		end
	end
	icon.name = name
	icon.sID = sID
	icon:Show()
	-- 用统一调度器替代 per-icon OnUpdate 做到期检测
	T.TimerScheduler:Register(icon, nil, icon.endTime, StopTimer)
	icon:SetScript("OnEnter", OnEnter)
	icon:SetScript("OnLeave", GameTooltip_Hide)
	if T.Classic and HasWandEquipped() then
		local wandID = GetInventoryItemID("player", 18)
		local wandSpeed = select(2, C_Container.GetItemCooldown(wandID)) or 0
		if wandSpeed < 1.5 then wandSpeed = 1.5 end
		if (T.enemy_spells[sID] or 0) > wandSpeed then
			return CooldownFrame_Set(icon.Cooldown, GetTime(), T.EnemySpells[sID], 1)
		end
	else
		return CooldownFrame_Set(icon.Cooldown, GetTime(), T.EnemySpells[sID], 1)
	end
	tinsert(icons, icon)
	table.sort(icons, sortByExpiration)
	UpdatePositions()
end

local function OnCLEU_EnemyCD()
	local _, eventType, _, sourceGUID, sourceName, sourceFlags, _, _, _, _, _, spellID = CombatLogGetCurrentEventInfo()
	if eventType ~= "SPELL_CAST_SUCCESS" or sourceName == T.name then return end
	if show[instanceType] then
		if band(sourceFlags, COMBATLOG_OBJECT_REACTION_HOSTILE) ~= 0 then
			if T.EnemySpells[spellID] then
				StartTimer(sourceGUID, spellID, sourceName)
			end
		end
	elseif instanceType == "party" and C.enemycooldown.show_inparty then
		if band(sourceFlags, COMBATLOG_OBJECT_AFFILIATION_PARTY) ~= 0 then
			if T.EnemySpells[spellID] then
				StartTimer(sourceGUID, spellID, sourceName)
			end
		end
	end
end

local addon = CreateFrame("Frame")
addon:SetScript("OnEvent", function(_, event)
	if event == "PLAYER_ENTERING_WORLD" then
		instanceType = select(2, IsInInstance())
	elseif event == "ZONE_CHANGED_NEW_AREA" then
		instanceType = select(2, IsInInstance())
		-- 换区域时立即清空所有 enemy cd icon（原 endTime=0 等 OnUpdate 触发，现在直接 StopTimer）
		while icons[1] do
			StopTimer(icons[1])
		end
	end
end)
addon:RegisterEvent("PLAYER_ENTERING_WORLD")
addon:RegisterEvent("ZONE_CHANGED_NEW_AREA")

T.CLEU_Register("SPELL_CAST_SUCCESS", OnCLEU_EnemyCD)

SlashCmdList.EnemyCD = function()
	if T.Classic then
		StartTimer(UnitGUID(T.name), 6552)
		StartTimer(UnitGUID(T.name), 19244)	-- Spell Lock (Felhunter), Wrath 版法术封锁 ID
		StartTimer(UnitGUID(T.name), 15487)
		StartTimer(UnitGUID(T.name), 1499)
	else
		StartTimer(UnitGUID(T.name), 47528)
		StartTimer(UnitGUID(T.name), 19647)
		StartTimer(UnitGUID(T.name), 47476)
		StartTimer(UnitGUID(T.name), 51514)
	end
end
SLASH_EnemyCD1 = "/enemycd"
SLASH_EnemyCD2 = "/утуьнсв"
