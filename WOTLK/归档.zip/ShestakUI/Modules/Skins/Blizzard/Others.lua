local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	Reskin Blizzard windows(by Tukz and Co)
----------------------------------------------------------------------------------------
local SkinBlizzUI = CreateFrame("Frame")
SkinBlizzUI:RegisterEvent("ADDON_LOADED")
SkinBlizzUI:SetScript("OnEvent", function(_, _, addon)
	if IsAddOnLoaded("Skinner") or IsAddOnLoaded("Aurora") then return end

	-- Stuff not in Blizzard load-on-demand
	if addon == "ShestakUI" then
		-- Skin checkButtons
		local checkButtons = {
			"LFDRoleCheckPopupRoleButtonTank",
			"LFDRoleCheckPopupRoleButtonDPS",
			"LFDRoleCheckPopupRoleButtonHealer"
		}

		for _, object in pairs(checkButtons) do
			local checkButton = _G[object] and _G[object].checkButton
			if checkButton then
				T.SkinCheckBox(_G[object].checkButton)
			end
		end

		-- Blizzard Frame reskin
		local bgskins = {
			"GameMenuFrame",
			"BNToastFrame",
			"ReadyCheckFrame",
			"ColorPickerFrame",
			"LFDRoleCheckPopup",
			"LFDReadyCheckPopup",
			"GuildInviteFrame",
			"RolePollPopup",
			"BaudErrorFrame",
			"OpacityFrame",
			"GeneralDockManagerOverflowButtonList",
			"QueueStatusFrame",
			"BasicScriptErrors"
		}

		GameMenuFrame:StripTextures()
		OpacityFrame:StripTextures()

		if T.Wrath or T.Cata then
			RolePollPopup:StripTextures()
		end

		if T.Wrath or T.Cata or T.Mainline then
			QueueStatusFrame:StripTextures()
			LFDRoleCheckPopup:StripTextures()
		end

		if T.Mainline then
			ColorPickerFrame.Border:Hide()
		end

		AutoCompleteBox.NineSlice:SetTemplate("Transparent")
		TicketStatusFrameButton.NineSlice:SetTemplate("Transparent")

		for i = 1, getn(bgskins) do
			local frame = _G[bgskins[i]]
			if frame then
				frame:SetTemplate("Transparent")
			end
		end

		local insetskins = {
			"BaudErrorFrameListScrollBox",
			"BaudErrorFrameDetailScrollBox"
		}

		for i = 1, getn(insetskins) do
			local frame = _G[insetskins[i]]
			if frame then
				frame:SetTemplate("Overlay")
			end
		end

		-- Reskin popups (direct wrap StaticPopup_Show + OnShow hook + children walk fallback)
		local function SkinStaticPopupElements(popup)
			if not popup then return end
			local name = popup:GetName()

			-- 框架本身
			popup:StripTextures()
			popup:CreateBackdrop("Transparent")
			if popup.backdrop then
				popup.backdrop:SetPoint("TOPLEFT", 2, -2)
				popup.backdrop:SetPoint("BOTTOMRIGHT", -2, 2)
			end

			-- 按钮：兼容 _G全局名 / popup.ButtonX / popup.buttonX
			for j = 1, 4 do
				local btn = _G[name.."Button"..j] or popup["Button"..j] or popup["button"..j]
				if btn and btn.SkinButton then btn:SkinButton() end
			end

			-- EditBox：兼容多种访问方式 + 子框架遍历兜底
			local editBox = _G[name.."EditBox"] or popup.EditBox or popup.editBox
			if not editBox then
				for _, child in next, {popup:GetChildren()} do
					if child.GetObjectType and child:GetObjectType() == "EditBox" then
						editBox = child
						break
					end
				end
			end
			if editBox then
				T.SkinEditBox(editBox)
				if editBox.backdrop then
					editBox.backdrop:SetPoint("TOPLEFT", -3, -6)
					editBox.backdrop:SetPoint("BOTTOMRIGHT", -3, 6)
				end
			end

			T.SkinEditBox(_G[name.."MoneyInputFrameGold"])
			T.SkinEditBox(_G[name.."MoneyInputFrameSilver"])
			T.SkinEditBox(_G[name.."MoneyInputFrameCopper"])

			local goldFrame = _G[name.."MoneyInputFrameGold"]
			if goldFrame and goldFrame.backdrop then
				goldFrame.backdrop:SetPoint("TOPLEFT", -3, 0)
			end
			local silverFrame = _G[name.."MoneyInputFrameSilver"]
			if silverFrame and silverFrame.backdrop then
				silverFrame.backdrop:SetPoint("TOPLEFT", -3, 0)
			end
			local copperFrame = _G[name.."MoneyInputFrameCopper"]
			if copperFrame and copperFrame.backdrop then
				copperFrame.backdrop:SetPoint("TOPLEFT", -3, 0)
			end

			-- 物品框架
			local itemFrame = _G[name.."ItemFrame"]
			local nameFrame = _G[name.."ItemFrameNameFrame"]
			if nameFrame then nameFrame:Kill() end
			if itemFrame then
				local nt = itemFrame.GetNormalTexture and itemFrame:GetNormalTexture()
				if nt then nt:Kill() end
				itemFrame:SetTemplate("Default")
				itemFrame:StyleButton()
				if itemFrame.IconBorder then itemFrame.IconBorder:SetAlpha(0) end
				local iconTex = _G[name.."ItemFrameIconTexture"]
				if iconTex then
					iconTex:SetTexCoord(0.1, 0.9, 0.1, 0.9)
					iconTex:ClearAllPoints()
					iconTex:SetPoint("TOPLEFT", 2, -2)
					iconTex:SetPoint("BOTTOMRIGHT", -2, 2)
				end
			end

		-- 关闭按钮
		-- 注意：不能替换 closeButton.SetNormalTexture/SetPushedTexture 方法（= T.dummy），
		-- 否则会让保护 frame 后续所有 SetNormalTexture 调用链被 taint，
		-- 进而引发 ADDON_ACTION_BLOCKED。改为一次性调用即可，Blizzard 不会主动重设关闭按钮纹理。
		local closeButton = _G[name.."CloseButton"] or popup.CloseButton
		if closeButton then
			closeButton:SetNormalTexture(0)
			closeButton:SetPushedTexture(0)
			T.SkinCloseButton(closeButton)
		end

			if T.Mainline then
				local border = popup.Border
				if border then border:StripTextures() end
			end
		end

		-- 方案1：直接包装 StaticPopup_Show
		-- 【已禁用】直接替换 StaticPopup_Show 会 taint 整个 popup 显示路径。
		-- Blizzard 后续任何调用 StaticPopup_Show()（包括 CAMP 登出确认弹窗）的执行栈都会被 taint，
		-- 导致 OnUpdate → onCancel → CancelLogout() 被 ADDON_ACTION_BLOCKED 归因于 ShestakUI。
		-- 改用下方的 OnShow HookScript（Blizzard 提供的安全 hook 机制）覆盖所有 popup 显示场景。
		-- local orig_StaticPopup_Show = StaticPopup_Show
		-- if orig_StaticPopup_Show then
		-- 	StaticPopup_Show = function(...)
		-- 		local popup = orig_StaticPopup_Show(...)
		-- 		if popup then
		-- 			SkinStaticPopupElements(popup)
		-- 		end
		-- 		return popup
		-- 	end
		-- end

		-- 方案2：OnShow hook 作为唯一皮肤入口（HookScript 是 Blizzard 安全 hook，不会 taint）
		for i = 1, 20 do
			local popup = _G["StaticPopup"..i]
			if not popup then break end
			popup:HookScript("OnShow", SkinStaticPopupElements)
			if popup:IsShown() then
				SkinStaticPopupElements(popup)
			end
		end
	

		-- Cinematic popup
		_G["CinematicFrameCloseDialog"]:SetScale(C.general.uiscale)
		_G["CinematicFrameCloseDialog"]:StripTextures()
		_G["CinematicFrameCloseDialog"]:SetTemplate("Transparent")
		_G["CinematicFrameCloseDialogConfirmButton"]:SkinButton()
		_G["CinematicFrameCloseDialogResumeButton"]:SkinButton()
		_G["CinematicFrameCloseDialogResumeButton"]:SetPoint("LEFT", _G["CinematicFrameCloseDialogConfirmButton"], "RIGHT", 15, 0)

		-- Movie popup /run MovieFrame_PlayMovie(MovieFrame, 18)
		if MovieFrame and MovieFrame.CloseDialog then
			MovieFrame.CloseDialog:SetScale(C.general.uiscale)
			MovieFrame.CloseDialog:StripTextures()
			MovieFrame.CloseDialog:SetTemplate("Transparent")
			if MovieFrame.CloseDialog.ConfirmButton then
				MovieFrame.CloseDialog.ConfirmButton:SkinButton()
			end
			if MovieFrame.CloseDialog.ResumeButton then
				MovieFrame.CloseDialog.ResumeButton:SkinButton()
				if MovieFrame.CloseDialog.ConfirmButton then
					MovieFrame.CloseDialog.ResumeButton:SetPoint("LEFT", MovieFrame.CloseDialog.ConfirmButton, "RIGHT", 15, 0)
				end
			end
		end

	-- PetBattle popup (only exists on clients with Pet Battles)
		local petBattleFrame = _G["PetBattleQueueReadyFrame"]
		if petBattleFrame then
			petBattleFrame:SetTemplate("Transparent")
			petBattleFrame.AcceptButton:SkinButton()
			petBattleFrame.DeclineButton:SkinButton()
		end

		-- Reskin Dropdown menu
		local dropdowns = {"DropDownList", "L_DropDownList", "Lib_DropDownList"}
		hooksecurefunc("UIDropDownMenu_InitializeHelper", function()
			for _, name in next, dropdowns do
				for i = 1, UIDROPDOWNMENU_MAXLEVELS do
					local backdrop = _G[name..i.."Backdrop"]
					if backdrop then
						backdrop:SetTemplate("Transparent")
						local menu = _G[name..i.."MenuBackdrop"].NineSlice or _G[name..i.."MenuBackdrop"]
						if menu then
							menu:SetTemplate("Transparent")
						end
						if backdrop.Bg then
							backdrop.Bg:SetAlpha(0)
						end
					end
				end
			end
		end)

		hooksecurefunc("ToggleDropDownMenu", function(level)
			if not level then
				level = 1
			end

			for i = 1, _G.UIDROPDOWNMENU_MAXBUTTONS do
				local button = _G["DropDownList"..level.."Button"..i]
				if not button then
					-- 如果按钮不存在，则跳过此次循环
					break
				end
				
				local check = _G["DropDownList"..level.."Button"..i.."Check"]
				local uncheck = _G["DropDownList"..level.."Button"..i.."UnCheck"]

				-- 安全地创建和设置背景
				if not button.backdrop then
					button:CreateBackdrop("Transparent")
					-- 创建后再次检查 backdrop 是否存在
					if button.backdrop then
						button.backdrop:SetBackdropColor(C.media.backdrop_color[1], C.media.backdrop_color[2], C.media.backdrop_color[3], 0.3)
					end
				end

				-- 安全地隐藏 backdrop
				if button.backdrop then
					button.backdrop:Hide()
				end

				-- 安全地处理复选框样式
				if not button.notCheckable and check then
					local texture = check:GetTexture()
					if texture and (T.Classic or texture == 375502) then
						uncheck:SetTexture()
						local _, co = check:GetTexCoord()
						if co == 0 then
							check:SetTexture([[Interface\Buttons\UI-CheckBox-Check]])
							check:SetVertexColor(1, 0.9, 0, 1)
							check:SetSize(18, 18)
							check:SetDesaturated(true)
							if button.backdrop then
								button.backdrop:SetInside(check, 4, 4)
							end
						else
							check:SetTexture(C.media.blank)
							check:SetVertexColor(1, 0.82, 0, 0.8)
							check:SetSize(6, 6)
							check:SetDesaturated(false)
							if button.backdrop then
								button.backdrop:SetOutside(check)
							end
						end

						if button.backdrop then
							button.backdrop:Show()
						end
						check:SetTexCoord(0, 1, 0, 1)
					else
						check:SetSize(16, 16)
					end
				else
					if check then
						check:SetSize(16, 16)
					end
				end
			end
		end)

		if RaiderIO_CustomDropDownListMenuBackdrop then
			RaiderIO_CustomDropDownListMenuBackdrop:StripTextures()
		end

		if MyFrameDropDownBackdrop then
			MyFrameDropDownBackdrop:SetTemplate("Transparent")
		end

		-- Reskin menu
		local ChatMenus = {
			"ChatMenu",
			"EmoteMenu",
			"LanguageMenu", 
			"VoiceMacroMenu"
		}

		for i = 1, getn(ChatMenus) do
			local menuFrame = _G[ChatMenus[i]]
			-- 安全检查：确保菜单对象存在
			if not menuFrame then
				break
			end
			-- 安全地添加脚本钩子
			menuFrame:HookScript("OnShow", function(self)
				if not self then
					return
				end
				local success, result = pcall(function()
					if self.NineSlice then
						-- 安全检查：确保 NineSlice 属性存在
						if self.NineSlice.SetTemplate then
							self.NineSlice:SetTemplate("Transparent")
						end
					else
						-- 安全检查：确保 SetTemplate 方法存在
						if self.SetTemplate then
							self:SetTemplate("Transparent")
						end
					end
					-- 安全处理 ChatMenu 的特殊定位
					if ChatMenus[i] == "ChatMenu" then
						-- 安全检查：确保 ChatFrame1 存在
						if ChatFrame1 and self.ClearAllPoints and self.SetPoint then
							self:ClearAllPoints()
							self:SetPoint("BOTTOMRIGHT", ChatFrame1, "BOTTOMRIGHT", 0, 30)
						end
					end
				end)
				-- 如果执行出错，静默处理，避免崩溃
				if not success then
					-- 可在此处添加调试输出，但生产环境建议静默
					-- print("Failed to set template for", ChatMenus[i], ":", result)
				end
			end)
		end

		-- Hide header textures and move text/buttons
		local BlizzardHeader = {
			"GameMenuFrame",
			"ColorPickerFrame"
		}

		for _, frame in pairs(BlizzardHeader) do
			local title = T.Classic and _G[frame.."Header"] or _G[frame] and _G[frame].Header
			if title then
				title:StripTextures()
				title:ClearAllPoints()
				title:SetPoint("TOP", frame, 0, 7)
			end
		end

		-- Reskin buttons
		-- NOTE: On 3.80.1 NewClassicUI, GameMenuFrame uses Retail AddButton/callback() pattern.
		-- SkinButton (SetNormalTexture, SetTemplate, HookScript etc.) taints the button objects,
		-- causing ADDON_ACTION_FORBIDDEN when Blizzard's protected code calls callback().
		-- We must skip GameMenuFrame buttons on NewClassicUI to avoid taint propagation.
		local GameMenuTaintButtons = {
			"GameMenuButtonOptions",
			"GameMenuButtonHelp",
			"GameMenuButtonStore",
			"GameMenuButtonUIOptions",
			"GameMenuButtonSettings",
			"GameMenuButtonEditMode",
			"GameMenuButtonKeybindings",
			"GameMenuButtonMacros",
			"GameMenuButtonRatings",
			"GameMenuButtonAddOns",
			"GameMenuButtonLogout",
			"GameMenuButtonQuit",
			"GameMenuButtonContinue",
			"GameMenuButtonMacOptions",
			"GameMenuButtonOptionHouse",
			"GameMenuButtonSettingsUI",
			"GameMenuButtonWhatsNew",
		}
		local BlizzardButtons = {
			"GameMenuButtonOptions",
			"GameMenuButtonHelp",
			"GameMenuButtonStore",
			"GameMenuButtonUIOptions",
			"GameMenuButtonSettings",
			"GameMenuButtonEditMode",
			"GameMenuButtonKeybindings",
			"GameMenuButtonMacros",
			"GameMenuButtonRatings",
			"GameMenuButtonAddOns",
			"GameMenuButtonLogout",
			"GameMenuButtonQuit",
			"GameMenuButtonContinue",
			"GameMenuButtonMacOptions",
			"GameMenuButtonOptionHouse",
			"GameMenuButtonSettingsUI",
			"GameMenuButtonWhatsNew",
			"ReadyCheckFrameYesButton",
			"ReadyCheckFrameNoButton",
			"ColorPickerOkayButton",
			"ColorPickerCancelButton",
			"GuildInviteFrameJoinButton",
			"GuildInviteFrameDeclineButton",
			"RolePollPopupAcceptButton",
			"LFDRoleCheckPopupDeclineButton",
			"LFDRoleCheckPopupAcceptButton",
			"LFDReadyCheckPopupAcceptButton",
			"RaidUtilityConvertButton",
			"RaidUtilityMainTankButton",
			"RaidUtilityMainAssistButton",
			"RaidUtilityRoleButton",
			"RaidUtilityReadyCheckButton",
			"RaidUtilityShowButton",
			"RaidUtilityCloseButton",
			"RaidUtilityDisbandButton",
			"RaidUtilityRaidControlButton",
			"BasicScriptErrorsButton"
		}

		if C.misc.raid_tools == true then
			tinsert(BlizzardButtons, "CompactRaidFrameManagerDisplayFrameLeaderOptionsRaidWorldMarkerButton")
		end

		-- Build taint-sensitive button set for NewClassicUI
		local taintSet = {}
		if T.NewClassicUI then
			for _, name in ipairs(GameMenuTaintButtons) do
				taintSet[name] = true
			end
		end

		for i = 1, getn(BlizzardButtons) do
			local btnName = BlizzardButtons[i]
			-- Skip GameMenuFrame buttons on NewClassicUI to prevent taint
			if T.NewClassicUI and taintSet[btnName] then
				-- skip: SkinButton taints these buttons, causing ADDON_ACTION_FORBIDDEN
			else
				local buttons = _G[btnName]
				if buttons then
					buttons:SkinButton()
				end
			end
		end

		for i = 1, getn(BlizzardButtons) do
			local buttons = _G[BlizzardButtons[i]]
			if buttons then
				buttons:SkinButton()
			end
		end
		if T.Mainline then
			LFDReadyCheckPopup.YesButton:SkinButton(true)
			LFDReadyCheckPopup.NoButton:SkinButton(true)
		end

		-- Button position or text
		_G["ColorPickerOkayButton"]:ClearAllPoints()
		_G["ColorPickerOkayButton"]:SetPoint("BOTTOMLEFT", _G["ColorPickerFrame"], "BOTTOMLEFT", 6, 6)
		_G["ColorPickerCancelButton"]:ClearAllPoints()
		_G["ColorPickerCancelButton"]:SetPoint("BOTTOMRIGHT", _G["ColorPickerFrame"], "BOTTOMRIGHT", -6, 6)
		_G["ReadyCheckFrameYesButton"]:SetParent(_G["ReadyCheckFrame"])
		_G["ReadyCheckFrameYesButton"]:ClearAllPoints()
		_G["ReadyCheckFrameNoButton"]:SetParent(_G["ReadyCheckFrame"])
		_G["ReadyCheckFrameNoButton"]:ClearAllPoints()
		_G["ReadyCheckFrameYesButton"]:SetPoint("RIGHT", _G["ReadyCheckFrame"], "CENTER", 0, -22)
		_G["ReadyCheckFrameNoButton"]:SetPoint("LEFT", _G["ReadyCheckFrameYesButton"], "RIGHT", 6, 0)
		_G["ReadyCheckFrameText"]:SetParent(_G["ReadyCheckFrame"])
		_G["ReadyCheckFrameText"]:ClearAllPoints()
		_G["ReadyCheckFrameText"]:SetPoint("TOP", 0, -12)

		-- Others
		if T.Mainline then
			for i = 1, 10 do
				select(i, GuildInviteFrame:GetRegions()):Hide()
			end
		end
		_G["GeneralDockManagerOverflowButtonList"]:SetFrameStrata("HIGH")
		_G["ReadyCheckListenerFrame"]:SetAlpha(0)
		_G["ReadyCheckFrame"]:HookScript("OnShow", function(self) if UnitIsUnit("player", self.initiator) then self:Hide() end end)

		-- StackSplit
		StackSplitFrame:SetFrameStrata("TOOLTIP")
		StackSplitFrame:StripTextures()
		StackSplitFrame:CreateBackdrop("Transparent")
		StackSplitFrame.backdrop:SetPoint("TOPLEFT", 5, -5)
		StackSplitFrame.backdrop:SetPoint("BOTTOMRIGHT", -5, 10)
		if T.Classic then
			StackSplitOkayButton:SkinButton()
			StackSplitCancelButton:SkinButton()
		else
			StackSplitFrame.OkayButton:SkinButton()
			StackSplitFrame.CancelButton:SkinButton()
		end

		if T.Classic then
			_G["StaticPopup1CloseButton"]:HookScript("OnShow", function(self)
				self:StripTextures(true)
				T.SkinCloseButton(self, nil, "-")
			end)
			T.SkinCloseButton(_G["ItemRefCloseButton"])
		end

		if C.skins.blizzard_frames == true then
			-- What's new frame
			if T.Mainline then
				SplashFrame:CreateBackdrop("Transparent")
				SplashFrame.BottomCloseButton:SkinButton()
				T.SkinCloseButton(SplashFrame.TopCloseButton)
			end

			-- NavBar Buttons (Used in EncounterJournal and HelpFrame)
			local function NavButtonXOffset(button, point, anchor, point2, _, yoffset, skip)
				if not skip then
					button:SetPoint(point, anchor, point2, 1, yoffset, true)
				end
			end

			local function SkinNavBarButtons(self)
				if self:GetParent():GetName() == "WorldMapFrame" then return end
				local total = #self.navList
				local navButton = self.navList[total]
				if navButton then
					if total == 2 then
						-- EJ.navBar.home.xoffset = 1 (this causes a taint, use the hook below instead)
						NavButtonXOffset(navButton, navButton:GetPoint())
						hooksecurefunc(navButton, "SetPoint", NavButtonXOffset)
					end

					if not navButton.isSkinned then
						navButton:SkinButton(true)
						if navButton.MenuArrowButton then
							navButton.MenuArrowButton:SetNormalTexture(0)
							navButton.MenuArrowButton:SetPushedTexture(0)
							navButton.MenuArrowButton:SetHighlightTexture(0)
						end

						navButton.xoffset = 1
						navButton.isSkinned = true
					end
				end
			end
			hooksecurefunc("NavBar_AddButton", SkinNavBarButtons)

			if T.client == "ruRU" then
				_G["DeclensionFrame"]:SetTemplate("Transparent")
				_G["DeclensionFrameCancelButton"]:SkinButton()
				_G["DeclensionFrameOkayButton"]:SkinButton()
				T.SkinNextPrevButton(_G["DeclensionFrameSetNext"])
				T.SkinNextPrevButton(_G["DeclensionFrameSetPrev"])
				for i = 1, 5 do
					_G["DeclensionFrameDeclension"..i.."Edit"]:StripTextures(true)
					_G["DeclensionFrameDeclension"..i.."Edit"]:SetTemplate("Overlay")
					_G["DeclensionFrameDeclension"..i.."Edit"]:SetTextInsets(3, 0, 0, 0)
				end
			end
			if C.skins.clique ~= true and IsAddOnLoaded("Clique") then
				CliqueSpellTab:GetRegions():SetSize(0.1, 0.1)
				CliqueSpellTab:GetNormalTexture():SetTexCoord(0.1, 0.9, 0.1, 0.9)
				CliqueSpellTab:GetNormalTexture():ClearAllPoints()
				CliqueSpellTab:GetNormalTexture():SetPoint("TOPLEFT", 2, -2)
				CliqueSpellTab:GetNormalTexture():SetPoint("BOTTOMRIGHT", -2, 2)
				CliqueSpellTab:CreateBackdrop("Default")
				CliqueSpellTab.backdrop:SetAllPoints()
				CliqueSpellTab:StyleButton()
			end

			local function SkinIconArray(baseName, numIcons)
				for i = 1, numIcons do
					local button = _G[baseName..i]
					local texture = _G[baseName..i.."Icon"]

					button:StripTextures()
					button:StyleButton(true)
					button:SetTemplate("Default")

					texture:ClearAllPoints()
					texture:SetPoint("TOPLEFT", 2, -2)
					texture:SetPoint("BOTTOMRIGHT", -2, 2)
					texture:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				end
			end

			-- This is used to create icons for the GuildBankPopupFrame, MacroPopupFrame, and GearManagerDialogPopup
			hooksecurefunc("BuildIconArray", function(_, baseName, _, rowSize, numRows)
				local numIcons = rowSize * numRows
				SkinIconArray(baseName, numIcons)
			end)

			if T.Mainline then
				hooksecurefunc(HelpTipTemplateMixin, "ApplyText", function(self)
					T.SkinHelpBox(self)
				end)
			end
		end
	end
end)
