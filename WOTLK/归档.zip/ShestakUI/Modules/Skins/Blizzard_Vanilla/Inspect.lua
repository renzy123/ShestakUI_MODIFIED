local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	InspectUI skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	-- 3.80.1 修复:ShestakUI 对 InspectFrame 的皮肤处理导致布局错位
	-- (InspectFrameTab1 重定位 + InspectModelFrame 限缩 + backdrop 尺寸假设失效),
	-- 直接跳过 LoadSkin,使用 Blizzard 原版观察框。tdInspect 独立处理装备图标显示,
	-- 不依赖 ShestakUI 皮肤。
	do return end

	InspectFrame:StripTextures(true)
	InspectFrame:CreateBackdrop("Transparent")
	InspectFrame.backdrop:SetPoint("TOPLEFT", 10, -12)
	InspectFrame.backdrop:SetPoint("BOTTOMRIGHT", -32, 76)

	T.SkinCloseButton(InspectFrameCloseButton, InspectFrame.backdrop)

	InspectNameText:ClearAllPoints()
    InspectNameText:SetPoint("TOP", InspectFrame.backdrop, "TOP", 0, -6)

	-- 3.80.1 修复:不重定位 InspectFrameTab1,保留 Blizzard 原版定位(原版 SetPoint 假设的 backdrop BOTTOMRIGHT 偏低会导致 tab 跑到窗口中下部,武器3槽反而在 tab 下方)
	-- InspectFrameTab1:ClearAllPoints()
	-- InspectFrameTab1:SetPoint("TOPLEFT", InspectFrame.backdrop, "BOTTOMLEFT", 2, -2)
	for i = 1, T.Vanilla and 2 or 3 do
		T.SkinTab(_G["InspectFrameTab"..i])
	end

	-- Character Frame
	InspectPaperDollFrame:StripTextures()

	InspectModelFrame:StripTextures()
	-- 3.80.1 修复:InspectModelFrame 默认尺寸过大,模型区占窗口80%导致比例失衡。
	-- 参照 CharacterModelFrame 的处理方式重新定位并限缩尺寸,让模型区缩到合适大小,
	-- 装备槽不再被挤到边缘,武器3槽和标签页占原本该占的位置。
	InspectModelFrame:ClearAllPoints()
	InspectModelFrame:SetPoint("TOPLEFT", 66, -74)
	InspectModelFrame:SetPoint("BOTTOMRIGHT", -66, 180)

	T.SkinRotateButton(InspectModelFrameRotateLeftButton)
	InspectModelFrameRotateLeftButton:SetPoint("TOPLEFT", 2, 2)

	T.SkinRotateButton(InspectModelFrameRotateRightButton)
	InspectModelFrameRotateRightButton:SetPoint("TOPLEFT", InspectModelFrameRotateLeftButton, "TOPRIGHT", 3, 0)

	local slots = {
		"HeadSlot",
		"NeckSlot",
		"ShoulderSlot",
		"BackSlot",
		"ChestSlot",
		"ShirtSlot",
		"TabardSlot",
		"WristSlot",
		"HandsSlot",
		"WaistSlot",
		"LegsSlot",
		"FeetSlot",
		"Finger0Slot",
		"Finger1Slot",
		"Trinket0Slot",
		"Trinket1Slot",
		"MainHandSlot",
		"SecondaryHandSlot",
		"RangedSlot"
	}

	for _, slot in pairs(slots) do
		local icon = _G["Inspect"..slot.."IconTexture"]
		local slot = _G["Inspect"..slot]

		slot:StripTextures()
		slot:StyleButton()

		icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
		icon:ClearAllPoints()
		icon:SetPoint("TOPLEFT", 2, -2)
		icon:SetPoint("BOTTOMRIGHT", -2, 2)

		slot:SetFrameLevel(slot:GetFrameLevel() + 2)
		slot:CreateBackdrop("Default")
		slot.backdrop:SetAllPoints()

		hooksecurefunc(slot.IconBorder, "SetVertexColor", function(self, r, g, b)
			self:SetTexture(0)
		end)
	end

	-- Honor Frame
	if InspectHonorFrame then
		InspectHonorFrame:StripTextures(true)

		InspectHonorFrameProgressBar:ClearAllPoints()
		InspectHonorFrameProgressBar:SetPoint("TOP", InspectFrame.backdrop, "TOP", 1, -65)

		InspectHonorFrameProgressBar:CreateBackdrop("Default")
		InspectHonorFrameProgressBar:SetHeight(24)
	end

	-- PVP Frame
	if InspectPVPFrame then
		InspectPVPFrame:StripTextures(true)
	end

	-- Talent Frame
	if not T.Cata and InspectTalentFrame then
		if not T.Wrath and not T.Cata then
			if InspectTalentFrameCancelButton then
				InspectTalentFrameCancelButton:Kill()
			end
		end
		if InspectTalentFrameCloseButton then
			InspectTalentFrameCloseButton:Kill()
			T.SkinCloseButton(InspectTalentFrameCloseButton, InspectFrame.backdrop)
		end

		InspectTalentFrame:StripTextures(true)

		for i = 1, 3 do
			local tab = _G["InspectTalentFrameTab"..i]
			if tab then
				local lastTab = _G["InspectTalentFrameTab"..i-1]
				tab:ClearAllPoints()
				if lastTab then
					tab:SetPoint("LEFT", lastTab, "RIGHT", 4, 0)
				else
					tab:SetPoint("TOPLEFT", 70, -48)
				end
				T.SkinTab(tab)
			end
		end

		InspectTalentFrameScrollFrame:StripTextures()
		InspectTalentFrameScrollFrame:CreateBackdrop("Default")
		InspectTalentFrameScrollFrame.backdrop:SetPoint("TOPLEFT", -1, 1)
		InspectTalentFrameScrollFrame.backdrop:SetPoint("BOTTOMRIGHT", 6, -1)

		T.SkinScrollBar(InspectTalentFrameScrollFrameScrollBar)
		InspectTalentFrameScrollFrameScrollBar:SetPoint("TOPLEFT", InspectTalentFrameScrollFrame, "TOPRIGHT", 10, -16)

		if not T.Wrath and not T.Cata then
			InspectTalentFrameSpentPoints:SetPoint("BOTTOMLEFT", InspectTalentFrame, "BOTTOMLEFT", 8, 84)
		end

		for i = 1, MAX_NUM_TALENTS do
			local talent = _G["InspectTalentFrameTalent"..i]
			local icon = _G["InspectTalentFrameTalent"..i.."IconTexture"]
			local rank = _G["InspectTalentFrameTalent"..i.."Rank"]

			if talent then
				talent:StripTextures()
				talent:SetTemplate("Default")
				talent:StyleButton()

				icon:SetInside()
				icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				icon:SetDrawLayer("ARTWORK")

				rank:SetFont(C.media.pixel_font, C.media.pixel_font_size, C.media.pixel_font_style)
			end
		end
	end
end

T.SkinFuncs["Blizzard_InspectUI"] = LoadSkin
