local T, C, L = unpack(ShestakUI)
if IsAddOnLoaded("OmniCC") or IsAddOnLoaded("ncCooldown") or IsAddOnLoaded("tullaCC") then return end

----------------------------------------------------------------------------------------
--	Cooldown count(tullaCC by Tuller)
----------------------------------------------------------------------------------------

local format = string.format
local floor = math.floor
local GetTime = GetTime
local UIParentScale = UIParent:GetEffectiveScale()

local scaleFrame = CreateFrame("Frame")
scaleFrame:RegisterEvent("UI_SCALE_CHANGED")
scaleFrame:SetScript("OnEvent", function()
	UIParentScale = UIParent:GetEffectiveScale()
end)

-- 3.80.1: Hide Blizzard's built-in cooldown countdown text globally to prevent overlap
-- with ShestakUI's custom cooldown timer text. The hybrid client's CooldownFrame
-- includes Retail-style countdown text that clashes with our own.
-- IMPORTANT: Do NOT use SetHideCountdownNumbers(true) — ShestakUI hooks that API
-- and adds the cooldown to hideNumbers, which would also suppress our own timer text.
-- Instead, directly hide the Blizzard countdown UI elements.
local Cooldown_MT = getmetatable(_G.ActionButton1Cooldown).__index
if T.NewClassicUI then
	hooksecurefunc(Cooldown_MT, "SetCooldown", function(self)
		-- Hide Blizzard's built-in countdown text elements directly
		-- without going through SetHideCountdownNumbers which ShestakUI hooks.
		-- The Blizzard countdown is typically in self.countdown (CooldownFrameTimeline)
		-- which contains FontString children for the text.
		if self.countdown then
			self.countdown:SetAlpha(0)
		end
		if self.blizzardCountdownHidden then return end
		for i = 1, self:GetNumChildren() do
			local child = select(i, self:GetChildren())
			if child and child ~= self.timer and child:IsObjectType("FontString") then
				child:SetAlpha(0)
			end
		end
		for i = 1, self:GetNumRegions() do
			local region = select(i, self:GetRegions())
			if region and region ~= (self.timer and self.timer.text) and region:IsObjectType("FontString") then
				region:SetAlpha(0)
			end
		end
		self.blizzardCountdownHidden = true
	end)
end

local function GetFormattedTime(s)
	local day, hour, minute = 86400, 3600, 60
	if s >= day then
		return format("%dd", floor(s / day + 0.5)), s % day
	elseif s >= hour then
		return format("%dh", floor(s / hour + 0.5)), s % hour
	elseif s >= minute then
		return format("%dm", floor(s / minute + 0.5)), s % minute
	end
	return floor(s + 0.5), s - floor(s)
end

-- 统一调度：所有 cooldown timer 共享单一 host OnUpdate，避免 N 个独立 frame dispatch
-- 参考事件总线模式：1 次 C→Lua 调用 + N 次 Lua 函数调用，替代 N 次 C→Lua 调用
local activeTimers = {}
local activeCount = 0
local cooldownHost = CreateFrame("Frame")
cooldownHost:Hide()

local function Timer_Activate(self)
	if not activeTimers[self] then
		activeTimers[self] = true
		activeCount = activeCount + 1
		if activeCount == 1 then
			cooldownHost:Show()
		end
	end
end

local function Timer_Deactivate(self)
	if activeTimers[self] then
		activeTimers[self] = nil
		activeCount = activeCount - 1
		if activeCount == 0 then
			cooldownHost:Hide()
		end
	end
end

local function Timer_Stop(self)
	self.enabled = nil
	self:Hide()
	Timer_Deactivate(self)
end

local function Timer_ForceUpdate(self)
	self.nextUpdate = 0
	self:Show()
	Timer_Activate(self)
end

local function Timer_OnSizeChanged(self, width)
	local fontScale = T.Round(width) / 40
	if fontScale == self.fontScale then
		return
	end

	self.fontScale = fontScale
	if fontScale < 0.5 then
		self:Hide()
	else
		self.text:SetFont(C.font.cooldown_timers_font, C.font.cooldown_timers_font_size, C.font.cooldown_timers_font_style)
		self.text:SetShadowOffset(C.font.cooldown_timers_font_shadow and 1 or 0, C.font.cooldown_timers_font_shadow and -1 or 0)
		if self.enabled then
			Timer_ForceUpdate(self)
		end
	end
end

local function Timer_OnUpdate(self, elapsed)
	if self.text:IsShown() then
		if self.nextUpdate > 0 then
			self.nextUpdate = self.nextUpdate - elapsed
		else
			if (self:GetEffectiveScale() / UIParentScale) < 0.5 then
				self.text:SetText("")
				self.nextUpdate = 1
			else
				local remain = self.duration - (GetTime() - self.start)
				if floor(remain + 0.5) > 0 then
					local time, nextUpdate = GetFormattedTime(remain)
					self.text:SetText(time)
					self.nextUpdate = nextUpdate
					if floor(remain + 0.5) > 5 then
						self.text:SetTextColor(1, 1, 1)
					else
						self.text:SetTextColor(1, 0.2, 0.2)
					end
				else
					Timer_Stop(self)
				end
			end
		end
	end
end

-- 统一 cooldown 调度 host：所有 timer 共享这一个 OnUpdate，避免 N 个独立 frame dispatch
cooldownHost:SetScript("OnUpdate", function(_, elapsed)
	for timer in pairs(activeTimers) do
		if timer.enabled then
			Timer_OnUpdate(timer, elapsed)
		end
	end
end)

local Timer_Create
if IsWetxius then
	 Timer_Create = function(self)
		local scaler = CreateFrame("Frame", nil, self)
		scaler:SetAllPoints(self)

		local timer = CreateFrame("Frame", nil, scaler)
		timer:Hide()
		timer:SetAllPoints(scaler)

		local text = timer:CreateFontString(nil, "OVERLAY")
		text:SetPoint("LEFT", -2, 0)
		text:SetPoint("RIGHT", 3, 0)

		text:SetJustifyH("CENTER")
		timer.text = text

		Timer_OnSizeChanged(timer, scaler:GetSize())
		scaler:SetScript("OnSizeChanged", function(_, ...) Timer_OnSizeChanged(timer, ...) end)

		self.timer = timer
		return timer
	end
else
	Timer_Create = function(self)
		local scaler = CreateFrame("Frame", nil, self)
		scaler:SetAllPoints(self)

		local timer = CreateFrame("Frame", nil, scaler)
		timer:Hide()
		timer:SetAllPoints(scaler)

		local text = timer:CreateFontString(nil, "OVERLAY")
		text:SetPoint("CENTER", 1, 0)

		text:SetJustifyH("CENTER")
		timer.text = text

		Timer_OnSizeChanged(timer, scaler:GetSize())
		scaler:SetScript("OnSizeChanged", function(_, ...) Timer_OnSizeChanged(timer, ...) end)

		self.timer = timer
		return timer
	end
end

local hideNumbers = {}

local function deactivateDisplay(cooldown)
	local timer = cooldown.timer
	if timer then
		Timer_Stop(timer)
	end
end

local function setHideCooldownNumbers(cooldown, hide)
	if hide then
		hideNumbers[cooldown] = true
		deactivateDisplay(cooldown)
	else
		hideNumbers[cooldown] = nil
	end
end

hooksecurefunc(Cooldown_MT, "SetCooldown", function(cooldown, start, duration, modRate)
	if cooldown.noCooldownCount or cooldown:IsForbidden() or hideNumbers[cooldown] then return end

	local show = (start and start > 0) and (duration and duration > 2) and (modRate == nil or modRate > 0)

	if show then
		local parent = cooldown:GetParent()
		if parent and parent.chargeCooldown == cooldown then return end

		local timer = cooldown.timer or Timer_Create(cooldown)
		timer.start = start
		timer.duration = duration
		timer.enabled = true
		timer.nextUpdate = 0
		if timer.fontScale and timer.fontScale >= 0.5 then
			timer:Show()
			Timer_Activate(timer)
		end
	else
		deactivateDisplay(cooldown)
	end
end)

hooksecurefunc(Cooldown_MT, "Clear", deactivateDisplay)

hooksecurefunc(Cooldown_MT, "SetHideCountdownNumbers", setHideCooldownNumbers)

hooksecurefunc("CooldownFrame_SetDisplayAsPercentage", function(cooldown)
	setHideCooldownNumbers(cooldown, true)
end)
