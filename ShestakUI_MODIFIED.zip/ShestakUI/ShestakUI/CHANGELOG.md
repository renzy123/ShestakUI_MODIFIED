# ShestakUI

## [11.1.7](https://github.com/Wetxius/ShestakUI/tree/11.1.7) (2026-06-17)
[Full Changelog](https://github.com/Wetxius/ShestakUI/compare/11.1.6...11.1.7) [Previous Releases](https://github.com/Wetxius/ShestakUI/releases)

- Updated version to 11.1.7.  
- Cleanup.  
- [Skins] Tweak position of QuestMapFrame.QuestsFrame.DetailsFrame.BackFrame.AccountCompletedNotice.  
- [Reminders] Added Hearty Well Fed.  
- [GUI] Added new option "Enable blizzard filters for debuffs" disabled by default.  
- Rework raid debuff filter. Now show all except of blacklisted.  
- [Tooltip] Added faction check for Harronir.  
- Replace outdated functions.  
- Updated oUF: hide arena frames.  
- [Nameplates] Fixed absorb and added over absorb bar.  
