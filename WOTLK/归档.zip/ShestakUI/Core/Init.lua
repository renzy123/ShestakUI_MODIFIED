----------------------------------------------------------------------------------------
--	Initiation of ShestakUI
----------------------------------------------------------------------------------------
-- Including system
local addon, engine = ...
engine[1] = {}	-- T, Functions
engine[2] = {}	-- C, Config
engine[3] = {}	-- L, Localization

ShestakUI = engine	-- Allow other addons to use Engine

--[[
	This should be at the top of every file inside of the ShestakUI AddOn:
	local T, C, L = unpack(ShestakUI)

	This is how another addon imports the ShestakUI engine:
	local T, C, L, _ = unpack(ShestakUI)
]]

-- 3.80.2 compat: GameFontHighlightSmall may not exist on Cata client
-- Create it early so Details! and other addons can reference it
if not GameFontHighlightSmall then
	local f = CreateFont("GameFontHighlightSmall")
	f:SetFont("Fonts\\FRIZQT__.TTF", 10, "")
	f:SetTextColor(1, 1, 1)
	f:SetShadowColor(0, 0, 0)
	f:SetShadowOffset(1, -1)
end