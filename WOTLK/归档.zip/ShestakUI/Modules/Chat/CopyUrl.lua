﻿local T, C, L = unpack(ShestakUI)
if C.chat.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Copy URL from chat (Enhanced with ElvUI patterns + email + IP detection)
----------------------------------------------------------------------------------------

local function PrintURL(url)
	return "|cFFFFFFFF[|Hurl:"..url.."|h"..url.."|h]|r "
end

local urlPatterns = {
	-- protocol://domain
	"(%a+)://(%S+%.%S+)",
	-- www.domain
	"www%.([_A-Za-z0-9-]+)%.(%S+)%s?",
	-- email@domain
	"([_A-Za-z0-9-%.]+)@([_A-Za-z0-9-]+)(%.+)([_A-Za-z0-9-%.]+)%s?",
	-- IP with port x.x.x.x:port
	"(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)(:%d+)%s?",
	-- IP address x.x.x.x
	"(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%s?",
}

local urlEvents = {
	"CHAT_MSG_SAY",
	"CHAT_MSG_YELL",
	"CHAT_MSG_WHISPER",
	"CHAT_MSG_WHISPER_INFORM",
	"CHAT_MSG_GUILD",
	"CHAT_MSG_OFFICER",
	"CHAT_MSG_PARTY",
	"CHAT_MSG_PARTY_LEADER",
	"CHAT_MSG_RAID",
	"CHAT_MSG_RAID_LEADER",
	"CHAT_MSG_RAID_WARNING",
	"CHAT_MSG_INSTANCE_CHAT",
	"CHAT_MSG_INSTANCE_CHAT_LEADER",
	"CHAT_MSG_BN_WHISPER",
	"CHAT_MSG_BN_WHISPER_INFORM",
	"CHAT_MSG_CHANNEL",
	"CHAT_MSG_SYSTEM",
	"CHAT_MSG_EMOTE",
}

for _, event in ipairs(urlEvents) do
	ChatFrame_AddMessageEventFilter(event, function(_, evt, msg, ...)
		-- protocol://domain
		local newMsg, found = gsub(msg, "(%a+)://(%S+%.%S+)", function(proto, domain)
			return PrintURL(proto.."://"..domain)
		end)
		if found > 0 then return false, newMsg, ... end

		-- www.domain
		newMsg, found = gsub(msg, "www%.([_A-Za-z0-9-]+)%.(%S+)%s?", function(d1, d2)
			return PrintURL("www."..d1.."."..d2)
		end)
		if found > 0 then return false, newMsg, ... end

		-- email
		newMsg, found = gsub(msg, "([_A-Za-z0-9-%.]+)@([_A-Za-z0-9-]+)(%.+)([_A-Za-z0-9-%.]+)%s?", function(user, dom, dot, tld)
			return PrintURL(user.."@"..dom..dot..tld)
		end)
		if found > 0 then return false, newMsg, ... end

		-- IP with port
		newMsg, found = gsub(msg, "(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)(:%d+)%s?", function(a, b, c, d, port)
			return PrintURL(a.."."..b.."."..c.."."..d..port)
		end)
		if found > 0 then return false, newMsg, ... end

		-- IP without port
		newMsg, found = gsub(msg, "(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)%s?", function(a, b, c, d)
			return PrintURL(a.."."..b.."."..c.."."..d)
		end)
		if found > 0 then return false, newMsg, ... end

		return false, msg, ...
	end)
end

-- Handle clicking URL links - paste URL into chat edit box
local SetHyperlink = _G.ItemRefTooltip.SetHyperlink
function _G.ItemRefTooltip:SetHyperlink(link, ...)
	if link and (strsub(link, 1, 3) == "url") then
		local editbox = ChatEdit_ChooseBoxForSend()
		ChatEdit_ActivateChat(editbox)
		editbox:Insert(string.sub(link, 5))
		editbox:HighlightText()
		return
	end

	SetHyperlink(self, link, ...)
end
