local T, C, L = unpack(ShestakUI)
if C.minimap.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Minimap border
----------------------------------------------------------------------------------------
local MinimapAnchor = CreateFrame("Frame", "MinimapAnchor", UIParent)
MinimapAnchor:CreatePanel("ClassColor", C.minimap.size, C.minimap.size, unpack(C.position.minimap))

-- Disable Minimap Cluster
MinimapCluster:EnableMouse(false)

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:SetScript("OnEvent", function(self, event)
	self:UnregisterEvent(event)
	-- Parent Minimap into our frame
	Minimap:SetParent(MinimapAnchor)
	Minimap:ClearAllPoints()
	Minimap:SetPoint("TOPLEFT", MinimapAnchor, "TOPLEFT", 2, -2)
	Minimap:SetPoint("BOTTOMRIGHT", MinimapAnchor, "BOTTOMRIGHT", -2, 2)
	Minimap:SetSize(MinimapAnchor:GetWidth(), MinimapAnchor:GetWidth())

	MinimapBackdrop:ClearAllPoints()
	MinimapBackdrop:SetPoint("TOPLEFT", MinimapAnchor, "TOPLEFT", 2, -2)
	MinimapBackdrop:SetPoint("BOTTOMRIGHT", MinimapAnchor, "BOTTOMRIGHT", -2, 2)
	MinimapBackdrop:SetSize(MinimapAnchor:GetWidth(), MinimapAnchor:GetWidth())

	-- Instance Difficulty icon
	MinimapCluster.InstanceDifficulty:SetParent(Minimap)
	MinimapCluster.InstanceDifficulty:ClearAllPoints()
	MinimapCluster.InstanceDifficulty:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", 1, 3)
	MinimapCluster.InstanceDifficulty.Default.Border:Hide()
	MinimapCluster.InstanceDifficulty.Default.Background:SetSize(28, 28)
	MinimapCluster.InstanceDifficulty.Default.Background:SetVertexColor(0.6, 0.3, 0)

	-- Guild Instance Difficulty icon
	MinimapCluster.InstanceDifficulty.Guild.Border:Hide()
	MinimapCluster.InstanceDifficulty.Guild.Background:SetSize(28, 28)
	MinimapCluster.InstanceDifficulty.Guild.Background:ClearAllPoints()
	MinimapCluster.InstanceDifficulty.Guild.Background:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", -1, 0)

	-- Challenge Mode icon
	MinimapCluster.InstanceDifficulty.ChallengeMode.Border:Hide()
	MinimapCluster.InstanceDifficulty.ChallengeMode.Background:SetSize(28, 28)
	MinimapCluster.InstanceDifficulty.ChallengeMode.Background:SetVertexColor(0.8, 0.8, 0)
	MinimapCluster.InstanceDifficulty.ChallengeMode.Background:ClearAllPoints()
	MinimapCluster.InstanceDifficulty.ChallengeMode.Background:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", -1, 0)

	-- Move QueueStatus icon
	QueueStatusFrame:SetClampedToScreen(true)
	QueueStatusFrame:SetFrameStrata("TOOLTIP")
	QueueStatusButton:ClearAllPoints()
	QueueStatusButton:SetPoint("TOP", Minimap, "TOP", 1, -1)
	QueueStatusButton:SetParent(Minimap)
	QueueStatusButton:SetScale(0.5)

	hooksecurefunc(QueueStatusButton, "SetPoint", function(self, _, anchor)
		if anchor ~= Minimap then
			self:ClearAllPoints()
			self:SetPoint("TOP", Minimap, "TOP", 1, -1)
		end
	end)

	hooksecurefunc(QueueStatusButton, "SetScale", function(self, scale)
		if scale ~= 0.5 then
			self:SetScale(0.5)
		end
	end)

	-- Invites icon
	local InviteTexture = GameTimeCalendarInvitesTexture
	InviteTexture:ClearAllPoints()
	InviteTexture:SetParent(Minimap)
	InviteTexture:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", -1, -4)
	GameTimeFrame:Hide()

	-- Create button to show invite tooltip and allow open calendar
	local button = CreateFrame("Button", nil, Minimap)
	button:SetAllPoints(InviteTexture)
	if not GameTimeCalendarInvitesTexture:IsShown() then
		button:Hide()
	end

	button:SetScript("OnEnter", function()
		if InCombatLockdown() then return end
		if InviteTexture:IsShown() then
			GameTooltip:SetOwner(button, "ANCHOR_LEFT")
			GameTooltip:AddLine(GAMETIME_TOOLTIP_CALENDAR_INVITES)
			GameTooltip:AddLine(" ")
			GameTooltip:AddLine(GAMETIME_TOOLTIP_TOGGLE_CALENDAR)
			GameTooltip:Show()
		end
	end)

	button:SetScript("OnLeave", function()
		GameTooltip:Hide()
	end)

	button:SetScript("OnClick", function()
		if InCombatLockdown() then return end
		if InviteTexture:IsShown() then
			ToggleCalendar()
		end
	end)

	hooksecurefunc(InviteTexture, "Show", function()
		button:Show()
	end)

	hooksecurefunc(InviteTexture, "Hide", function()
		button:Hide()
	end)

	-- Move Mail icon
	local MailFrame = MinimapCluster.IndicatorFrame.MailFrame
	hooksecurefunc(MailFrame, "SetPoint", function(self, _, anchor)
		if anchor ~= Minimap then
			self:ClearAllPoints()
			self:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", 4, -1)
		end
	end)
	MiniMapMailIcon:SetTexture("Interface\\AddOns\\ShestakUI\\Media\\Textures\\Mail.tga")
	MiniMapMailIcon:SetSize(16, 16)

	-- Move crafting order icon
	local Crafting = MinimapCluster.IndicatorFrame.CraftingOrderFrame
	hooksecurefunc(Crafting, "SetPoint", function(self, _, anchor)
		if anchor ~= Minimap then
			self:ClearAllPoints()
			self:SetPoint("BOTTOM", Minimap, "BOTTOM", 0, 4)
		end
	end)
end)

-- Adjusting for patch 9.0.1 Minimap.xml
Minimap:SetFrameStrata("LOW")
Minimap:SetFrameLevel(2)

-- Hide Border
MinimapCompassTexture:Hide()
MinimapCluster.BorderTop:StripTextures()

-- Hide Zoom Buttons
Minimap.ZoomIn:Kill()
Minimap.ZoomOut:Kill()

-- Hide Blob Ring
Minimap:SetArchBlobRingScalar(0)
Minimap:SetQuestBlobRingScalar(0)

-- Hide Zone Frame
MinimapCluster.ZoneTextButton:Hide()

AddonCompartmentFrame:Kill()

-- Garrison icon
if C.minimap.garrison_icon == true then
	ExpansionLandingPageMinimapButton:SetScale(0.6)
	ExpansionLandingPageMinimapButton:ClearAllPoints()
	ExpansionLandingPageMinimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -3, 1)
	hooksecurefunc(ExpansionLandingPageMinimapButton, "SetPoint", function(_, _, _, _, _, y)
		if y ~= 1 then
			ExpansionLandingPageMinimapButton:ClearAllPoints()
			ExpansionLandingPageMinimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -3, 1)
		end
	end)
else
	ExpansionLandingPageMinimapButton:SetScale(0.0001)
	ExpansionLandingPageMinimapButton:SetAlpha(0)
end

-- Feedback icon
if FeedbackUIButton then
	FeedbackUIButton:ClearAllPoints()
	FeedbackUIButton:SetPoint("BOTTOM", Minimap, "BOTTOM", 0, 0)
	FeedbackUIButton:SetScale(0.8)
end

-- Streaming icon
if StreamingIcon then
	StreamingIcon:ClearAllPoints()
	StreamingIcon:SetPoint("BOTTOM", Minimap, "BOTTOM", 0, -10)
	StreamingIcon:SetScale(0.8)
	StreamingIcon:SetFrameStrata("BACKGROUND")
end

-- GhostFrame
GhostFrame:StripTextures()
GhostFrame:SetTemplate("Overlay")
GhostFrame:StyleButton()
GhostFrame:ClearAllPoints()
GhostFrame:SetPoint(unpack(C.position.ghost))
GhostFrameContentsFrameIcon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
GhostFrameContentsFrameIcon:SetSize(32, 32)
GhostFrameContentsFrame:SetFrameLevel(GhostFrameContentsFrame:GetFrameLevel() + 2)
GhostFrameContentsFrame:CreateBackdrop("Overlay")
GhostFrameContentsFrame.backdrop:SetPoint("TOPLEFT", GhostFrameContentsFrameIcon, -2, 2)
GhostFrameContentsFrame.backdrop:SetPoint("BOTTOMRIGHT", GhostFrameContentsFrameIcon, 2, -2)

-- DurabilityFrame
hooksecurefunc(DurabilityFrame, "SetPoint", function(self, _, parent)
	if parent and parent ~= UIParent then
		self:SetClampedToScreen(false)
		self:ClearAllPoints()
		self:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", 0, LPSTAT_CONFIG.Durability.man and 200 or -90)
	end
end)

-- Enable mouse scrolling
Minimap:EnableMouseWheel(true)
Minimap:SetScript("OnMouseWheel", function(_, d)
	if d > 0 then
		_G.Minimap.ZoomIn:Click()
	elseif d < 0 then
		_G.Minimap.ZoomOut:Click()
	end
end)

-- Hide Game Time
MinimapAnchor:RegisterEvent("PLAYER_LOGIN")
MinimapAnchor:RegisterEvent("ADDON_LOADED")
MinimapAnchor:SetScript("OnEvent", function(_, _, addon)
	if addon == "Blizzard_TimeManager" then
		TimeManagerClockButton:Kill()
	elseif addon == "Blizzard_HybridMinimap" then
		HybridMinimap:SetFrameStrata("BACKGROUND")
		HybridMinimap:SetFrameLevel(100)
		HybridMinimap.MapCanvas:SetUseMaskTexture(false)
		HybridMinimap.CircleMask:SetTexture("Interface\\BUTTONS\\WHITE8X8")
		HybridMinimap.MapCanvas:SetUseMaskTexture(true)
		C_Timer.After(0.5, function()
			Minimap:SetFrameStrata("LOW")
			Minimap:SetFrameLevel(2)
		end)
	end
end)

----------------------------------------------------------------------------------------
--	Right click menu
----------------------------------------------------------------------------------------
local menuFrame = CreateFrame("Frame", "MinimapRightClickMenu", UIParent, "UIDropDownMenuTemplate")
local guildText = IsInGuild() and ACHIEVEMENTS_GUILD_TAB or LOOKINGFORGUILD
local journalText = T.client == "ruRU" and ENCOUNTER_JOURNAL or ADVENTURE_JOURNAL
local micromenu = {
	{text = CHARACTER_BUTTON, notCheckable = 1, func = function()
		ToggleCharacter("PaperDollFrame")
	end},
	{text = PROFESSIONS_BUTTON, notCheckable = 1, func = function()
		-- if InCombatLockdown() then
			-- print("|cffffff00"..ERR_NOT_IN_COMBAT.."|r") return
		-- end
		ToggleProfessionsBook()
	end},
	{text = TALENTS_BUTTON, notCheckable = 1, func = function()
		if T.level >= 10 then
			PlayerSpellsUtil.ToggleClassTalentOrSpecFrame()
		else
			if C.general.error_filter ~= "WHITELIST" then
				UIErrorsFrame:AddMessage(format(FEATURE_BECOMES_AVAILABLE_AT_LEVEL, 10), 1, 0.1, 0.1)
			else
				print("|cffffff00"..format(FEATURE_BECOMES_AVAILABLE_AT_LEVEL, 10).."|r")
			end
		end
	end},
	{text = ACHIEVEMENT_BUTTON, notCheckable = 1, func = function()
		ToggleAchievementFrame()
	end},
	{text = QUESTLOG_BUTTON, notCheckable = 1, func = function()
		ToggleQuestLog()
	end},
	{text = guildText, notCheckable = 1, func = function()
		ToggleGuildFrame()
	end},
	{text = SOCIAL_BUTTON, notCheckable = 1, func = function()
		ToggleFriendsFrame()
	end},
	{text = CHAT_CHANNELS, notCheckable = 1, func = function()
		ToggleChannelFrame()
	end},
	{text = PLAYER_V_PLAYER, notCheckable = 1, func = function()
		if T.level >= 10 then
			TogglePVPUI()
		else
			if C.general.error_filter ~= "WHITELIST" then
				UIErrorsFrame:AddMessage(format(FEATURE_BECOMES_AVAILABLE_AT_LEVEL, 10), 1, 0.1, 0.1)
			else
				print("|cffffff00"..format(FEATURE_BECOMES_AVAILABLE_AT_LEVEL, 10).."|r")
			end
		end
	end},
	{text = GROUP_FINDER, notCheckable = 1, func = function()
		if T.level >= 10 then
			PVEFrame_ToggleFrame("GroupFinderFrame", nil)
		else
			if C.general.error_filter ~= "WHITELIST" then
				UIErrorsFrame:AddMessage(format(FEATURE_BECOMES_AVAILABLE_AT_LEVEL, 10), 1, 0.1, 0.1)
			else
				print("|cffffff00"..format(FEATURE_BECOMES_AVAILABLE_AT_LEVEL, 10).."|r")
			end
		end
	end},
	{text = journalText, notCheckable = 1, func = function()
		if C_AdventureJournal.CanBeShown() then
			ToggleEncounterJournal()
		else
			if C.general.error_filter ~= "WHITELIST" then
				UIErrorsFrame:AddMessage(FEATURE_NOT_YET_AVAILABLE, 1, 0.1, 0.1)
			else
				print("|cffffff00"..FEATURE_NOT_YET_AVAILABLE.."|r")
			end
		end
	end},
	{text = COLLECTIONS, notCheckable = 1, func = function()
		-- if InCombatLockdown() then
			-- print("|cffffff00"..ERR_NOT_IN_COMBAT.."|r") return
		-- end
		ToggleCollectionsJournal()
	end},
	{text = HOUSING_MICRO_BUTTON, notCheckable = 1, func = function()
		if Kiosk.IsEnabled() then
			return
		end

		HousingFramesUtil.ToggleHousingDashboard()
	end},
	{text = HELP_BUTTON, notCheckable = 1, func = function()
		ToggleHelpFrame()
	end},
	{text = L_MINIMAP_CALENDAR, notCheckable = 1, func = function()
		ToggleCalendar()
	end},
	{text = BATTLEFIELD_MINIMAP, notCheckable = 1, func = function()
		ToggleBattlefieldMap()
	end},
}

if not IsTrialAccount() and C_StorePublic.IsEnabled() then
	tinsert(micromenu, {text = BLIZZARD_STORE, notCheckable = 1, func = function() StoreMicroButton:Click() end})
end

if T.level == GetMaxPlayerLevel() then
	tinsert(micromenu, {text = RATED_PVP_WEEKLY_VAULT, notCheckable = 1, func = function()
		if not WeeklyRewardsFrame then
			WeeklyRewards_LoadUI()
		end
		ToggleFrame(WeeklyRewardsFrame)
	end})
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("GARRISON_SHOW_LANDING_PAGE")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:SetScript("OnEvent", function()
	if ExpansionLandingPageMinimapButton.title then
		tinsert(micromenu, {text = ExpansionLandingPageMinimapButton.title, notCheckable = 1, func = function() ExpansionLandingPageMinimapButton:ToggleLandingPage() end})
		frame:UnregisterAllEvents()
	end
end)

local MinimapArea = CreateFrame("Frame", nil, Minimap)
MinimapArea:SetPassThroughButtons("LeftButton")
MinimapArea:SetPropagateMouseMotion(true)
MinimapArea:SetAllPoints()

MinimapArea:SetScript("OnMouseUp", function(_, button)
	local position = MinimapAnchor:GetPoint()
	if button == "RightButton" then
		if InCombatLockdown() then	-- 12.0.5 we cant open any frame in combat except of battlefield zone map
			_G.UIErrorsFrame:AddMessage(ERR_NOT_IN_COMBAT, 1.0, 0.2, 0.2, 1.0)
			print("|cffffff00"..ERR_NOT_IN_COMBAT.."|r") return
		end
		if position:match("LEFT") then
			EasyMenu(micromenu, menuFrame, "cursor", 0, 0, "MENU")
		else
			EasyMenu(micromenu, menuFrame, "cursor", -160, 0, "MENU")
		end
	elseif button == "MiddleButton" then
		MinimapCluster.Tracking.Button:OpenMenu()
		MinimapCluster.Tracking.Button.menu:ClearAllPoints()
		if position:match("LEFT") then
			MinimapCluster.Tracking.Button.menu:SetPoint("TOPLEFT", Minimap, "RIGHT", 4, 0)
		else
			MinimapCluster.Tracking.Button.menu:SetPoint("TOPRIGHT", Minimap, "LEFT", -4, 0)
		end
	end
end)

-- Set Square Map Mask
Minimap:SetMaskTexture(C.media.blank)
Minimap:SetArchBlobRingAlpha(0)
Minimap:SetQuestBlobRingAlpha(0)

-- For others mods with a minimap button, set minimap buttons position in square mode
function GetMinimapShape() return "SQUARE" end

----------------------------------------------------------------------------------------
--	Hide minimap in combat
----------------------------------------------------------------------------------------
if C.minimap.hide_combat == true then
	MinimapAnchor:RegisterEvent("PLAYER_REGEN_ENABLED")
	MinimapAnchor:RegisterEvent("PLAYER_REGEN_DISABLED")
	MinimapAnchor:HookScript("OnEvent", function(self, event)
		if event == "PLAYER_REGEN_ENABLED" then
			self:Show()
		elseif event == "PLAYER_REGEN_DISABLED" then
			if not T.FarmMode then
				self:Hide()
			end
		end
	end)
end

----------------------------------------------------------------------------------------
--	Tracking icon
----------------------------------------------------------------------------------------
local trackButton = MinimapCluster.Tracking.Button
trackButton:ClearAllPoints()
trackButton:SetPoint("BOTTOMLEFT", MinimapAnchor, "BOTTOMLEFT", 5, 6)
MinimapCluster.Tracking.Background:Hide()

if C.minimap.tracking_icon then
	trackButton:SetHighlightTexture(0)
	trackButton:SetSize(16, 16)

	MinimapCluster.Tracking:CreateBackdrop("ClassColor")
	MinimapCluster.Tracking.backdrop:SetPoint("TOPLEFT", trackButton, -2, 2)
	MinimapCluster.Tracking.backdrop:SetPoint("BOTTOMRIGHT", trackButton, 2, -2)
else
	trackButton:ClearAllPoints()
	trackButton:SetPoint("TOP", UIParent, "BOTTOM")
end

----------------------------------------------------------------------------------------
--	Move minimap on top
----------------------------------------------------------------------------------------
if C.minimap.on_top then
	MinimapAnchor:ClearAllPoints()
	MinimapAnchor:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -21, -21)
	if BuffsAnchor then
		local space = (ButtonCollectFrame and ButtonCollectFrame.col) or 1
		BuffsAnchor:ClearAllPoints()
		BuffsAnchor:SetPoint("TOPRIGHT", MinimapAnchor, "TOPLEFT", -25 * space, 0)
	end

	LPSTAT_CONFIG.Location.tip_frame = MinimapAnchor
	LPSTAT_CONFIG.Location.tip_anchor = "TOPRIGHT"
	LPSTAT_CONFIG.Location.tip_x = 0
	LPSTAT_CONFIG.Location.tip_y = 0

	local frame = CreateFrame("Frame")
	frame:RegisterEvent("PLAYER_ENTERING_WORLD")
	frame:SetScript("OnEvent", function()
		frame:UnregisterEvent("PLAYER_ENTERING_WORLD")
		local positionTable = T.CurrentProfile()
		if LP_Coords then
			LP_Coords:ClearAllPoints()
			LP_Coords:SetPoint("BOTTOMRIGHT", MinimapAnchor, "TOPRIGHT", 4, 5)
		end
		if TeleportMenu then
			TeleportMenu:ClearAllPoints()
			TeleportMenu:SetPoint("TOPLEFT", MinimapAnchor, "BOTTOMLEFT", 0, -13)
		end
		if RaidBuffsAnchor and not positionTable[RaidBuffsAnchor:GetName()] then
			RaidBuffsAnchor:ClearAllPoints()
			RaidBuffsAnchor:SetPoint("TOPLEFT", MinimapAnchor, "BOTTOMLEFT", 0, -3)
		end
		if not positionTable[VehicleAnchor:GetName()] then
			VehicleAnchor:ClearAllPoints()
			VehicleAnchor:SetPoint("TOP", Minimap, "BOTTOM", 0, -27)
		end
		if TooltipAnchor and not positionTable[TooltipAnchor:GetName()] then
			TooltipAnchor:ClearAllPoints()
			TooltipAnchor:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -21, 20)
		end

		GhostFrame:ClearAllPoints()
		GhostFrame:SetPoint("TOP", Minimap, "BOTTOM", 0, -5)

		if stArchaeologyFrame then
			stArchaeologyFrame:ClearAllPoints()
			stArchaeologyFrame:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", 2, -5)
		end

		if AutoButtonAnchor and not positionTable[AutoButtonAnchor:GetName()] then
			AutoButtonAnchor:ClearAllPoints()
			AutoButtonAnchor:SetPoint("TOPLEFT", Minimap, "BOTTOMLEFT", -2, -27)
		end

		if AutoButtonAnchor and not positionTable[AutoButtonAnchor:GetName()] then
			AutoButtonAnchor:ClearAllPoints()
			AutoButtonAnchor:SetPoint("TOPLEFT", Minimap, "BOTTOMLEFT", -2, -27)
		end

		if StuffingFrameBags and not positionTable[StuffingFrameBags:GetName()] then
			StuffingFrameBags:ClearAllPoints()
			StuffingFrameBags:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -21, 20)
		end

		if TTMenuBackground then
			TTMenuBackground:ClearAllPoints()
			TTMenuBackground:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", 2, -5)

			TTOpenMenuBackground:ClearAllPoints()
			TTOpenMenuBackground:SetPoint("TOP", Minimap, "BOTTOM", 0, -5)

			TTMenuAddOnBackground:ClearAllPoints()
			TTMenuAddOnBackground:SetPoint("TOP", TTMenuBackground, "TOP", 0, 0)
		end
	end)
end

----------------------------------------------------------------------------------------
--	Farm mode for minimap(by Elv22)
----------------------------------------------------------------------------------------
T.FarmMode = false
SlashCmdList.FARMMODE = function()
	if T.FarmMode == false then
		MinimapAnchor:SetSize(C.minimap.size * 1.65, C.minimap.size * 1.65)
		Minimap:SetSize(MinimapAnchor:GetWidth(), MinimapAnchor:GetWidth())
		T.FarmMode = true
	else
		MinimapAnchor:SetSize(C.minimap.size, C.minimap.size)
		Minimap:SetSize(MinimapAnchor:GetWidth(), MinimapAnchor:GetWidth())
		T.FarmMode = false
	end
end
SLASH_FARMMODE1 = "/farmmode"
SLASH_FARMMODE2 = "/афкььщву"
SLASH_FARMMODE3 = "/fm"
SLASH_FARMMODE4 = "/аь"

----------------------------------------------------------------------------------------
--	Farm mode mouseover button(by m2jest1c)
----------------------------------------------------------------------------------------
local farm = CreateFrame("Button", "FarmMode", UIParent)
farm:SetTemplate("ClassColor")
if C.actionbar.toggle_mode == true then
	farm:SetPoint("TOPLEFT", Minimap, "TOPRIGHT", 3, -18)
else
	farm:SetPoint("TOPLEFT", Minimap, "TOPRIGHT", 3, 2)
end
farm:SetSize(19, 19)
farm:SetAlpha(0)

farm.t = farm:CreateTexture(nil, "OVERLAY")
farm.t:SetTexture("Interface\\Icons\\inv_misc_map_01")
farm.t:SetTexCoord(0.1, 0.9, 0.1, 0.9)
farm.t:SetPoint("TOPLEFT", farm, 2, -2)
farm.t:SetPoint("BOTTOMRIGHT", farm, -2, 2)

farm:SetScript("OnClick", function()
	SlashCmdList.FARMMODE()
end)

farm:SetScript("OnEnter", function()
	farm:FadeIn()
	GameTooltip:SetOwner(farm, "ANCHOR_LEFT")
	GameTooltip:AddLine(L_MINIMAP_FARM, 0.40, 0.78, 1)
	GameTooltip:Show()
end)

farm:SetScript("OnLeave", function()
	farm:FadeOut()
	GameTooltip:Hide()
end)