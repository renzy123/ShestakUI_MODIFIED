local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	AddonList skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	local buttons = {
		"AddonListEnableAllButton",
		"AddonListDisableAllButton",
		"AddonListCancelButton",
		"AddonListOkayButton"
	}

	for _, button in pairs(buttons) do
		-- 3.80.1 时光服的 AddonList 可能没有 EnableAll/DisableAll 等按钮，需 nil 检查
		if _G[button] then _G[button]:SkinButton() end
	end

	if not AddonList then return end
	AddonList:StripTextures()
	AddonList:SetTemplate("Transparent")
	AddonList:SetHeight(AddonList:GetHeight() + 3)

	if AddonListInset then
		AddonListInset:StripTextures()
		AddonListInset:SetTemplate("Overlay")
		AddonListInset:SetPoint("BOTTOMRIGHT", -6, 29)
	end

	if T.Classic then
		for i = 1, MAX_ADDONS_DISPLAYED do
			-- 3.80.1 时光服实际 entry 数可能少于 MAX_ADDONS_DISPLAYED，需逐个 nil 检查
			local enabled = _G["AddonListEntry"..i.."Enabled"]
			local loadBtn = _G["AddonListEntry"..i.."Load"]
			if enabled then T.SkinCheckBox(enabled, nil, true) end
			if loadBtn then loadBtn:SkinButton() end
		end
	else
		local function forceSaturation(self, _, force)
			if force then return end
			self:SetVertexColor(0.6, 0.6, 0.6)
			self:SetDesaturated(true, true)
		end

		hooksecurefunc("AddonList_InitButton", function(child)
			if not child.styled then
				T.SkinCheckBox(child.Enabled)
				child.LoadAddonButton:SkinButton()
				hooksecurefunc(child.Enabled:GetCheckedTexture(), "SetDesaturated", forceSaturation)

				T.ReplaceIconString(child.Title)
				hooksecurefunc(child.Title, "SetText", T.ReplaceIconString)

				child.styled = true
			end
		end)
	end

	if T.Classic then
		if AddonListScrollFrame then AddonListScrollFrame:StripTextures() end
		if AddonListScrollFrameScrollBar then T.SkinScrollBar(AddonListScrollFrameScrollBar) end
	else
		if AddonList and AddonList.ScrollBar then T.SkinScrollBar(AddonList.ScrollBar) end
	end
	if AddonListCloseButton then T.SkinCloseButton(AddonListCloseButton) end
	if AddonCharacterDropDown then T.SkinDropDownBox(AddonCharacterDropDown) end
	if AddonListForceLoad then
		T.SkinCheckBox(AddonListForceLoad)
		AddonListForceLoad:SetSize(25, 25)
	end
end

tinsert(T.SkinFuncs["ShestakUI"], LoadSkin)
