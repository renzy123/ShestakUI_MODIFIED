local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	RaidInfo skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	-- 3.80.1 时光服可能裁剪 RaidInfo 子组件，整体加 nil 检查
	if not RaidInfoFrame then return end

	local StripAllTextures = {
		RaidInfoScrollFrame,
		RaidInfoFrame,
		RaidInfoInstanceLabel,
		RaidInfoIDLabel,
		RaidInfoFrame.Header
	}

	local KillTextures = {
		RaidInfoScrollFrameScrollBarBG,
		RaidInfoScrollFrameScrollBarTop,
		RaidInfoScrollFrameScrollBarBottom,
		RaidInfoScrollFrameScrollBarMiddle
	}

	local buttons = {
		RaidFrameConvertToRaidButton,
		RaidFrameRaidInfoButton,
		RaidInfoExtendButton,
		RaidInfoCancelButton
	}

	for _, object in pairs(StripAllTextures) do
		if object then object:StripTextures() end
	end

	if T.Mainline then
		for _, texture in pairs(KillTextures) do
			if texture then texture:Kill() end
		end
	end

	for i = 1, #buttons do
		local button = buttons[i]
		if button then
			button:SkinButton()
		end
	end

	RaidInfoFrame:CreateBackdrop("Transparent")
	RaidInfoFrame.backdrop:SetPoint("TOPLEFT", RaidInfoFrame, "TOPLEFT")
	RaidInfoFrame.backdrop:SetPoint("BOTTOMRIGHT", RaidInfoFrame, "BOTTOMRIGHT")
	if FriendsFrame then
		RaidInfoFrame:SetPoint("TOPLEFT", FriendsFrame, "TOPRIGHT", 3, 0)
	end
	if RaidInfoCloseButton then T.SkinCloseButton(RaidInfoCloseButton, RaidInfoFrame) end
	if RaidFrameAllAssistCheckButton then T.SkinCheckBox(RaidFrameAllAssistCheckButton) end
	if T.Classic then
		-- 3.80.1 时光服 RaidInfoScrollFrameScrollBar 可能不存在
		if RaidInfoScrollFrameScrollBar then T.SkinScrollBar(RaidInfoScrollFrameScrollBar) end
	else
		if RaidInfoFrame and RaidInfoFrame.ScrollBar then T.SkinScrollBar(RaidInfoFrame.ScrollBar) end
	end
end

tinsert(T.SkinFuncs["ShestakUI"], LoadSkin)
