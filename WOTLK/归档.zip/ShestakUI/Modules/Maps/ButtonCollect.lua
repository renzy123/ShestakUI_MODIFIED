local T, C, L = unpack(ShestakUI)
if C.minimap.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Minimap button collector (ported from NDUI's RecycleBin)
--	Collects addon minimap buttons into a collapsible bin panel.
--	Toggle button is parented to Minimap directly — does NOT depend on MinimapAnchor.
----------------------------------------------------------------------------------------

local blackList = {
	["GameTimeFrame"] = true,
	["MiniMapLFGFrame"] = true,
	["LFGMinimapFrame"] = true,
	["BattlefieldMinimap"] = true,
	["MinimapBackdrop"] = true,
	["TimeManagerClockButton"] = true,
	["FeedbackUIButton"] = true,
	["HelpOpenTicketButton"] = true,
	["MiniMapBattlefieldFrame"] = true,
	["QueueStatusMinimapButton"] = true,
	["QueueStatusButton"] = true,
	["GarrisonLandingPageMinimapButton"] = true,
	["MinimapZoneTextButton"] = true,
	["MiniMapTracking"] = true,
	["MiniMapTrackingFrame"] = true,
	["MiniMapTrackingButton"] = true,
	["MiniMapMailFrame"] = true,
	["MiniMapMailButton"] = true,
	["MiniMapInstanceDifficulty"] = true,
	["MiniMapRecordingButton"] = true,
	["MiniMapVoiceChatFrame"] = true,
	["MiniMapWorldMapButton"] = true,
	["MinimapToggleButton"] = true,
	["MinimapZoomIn"] = true,
	["MinimapZoomOut"] = true,
	-- Don't collect ourselves
	["ShestakBinToggleButton"] = true,
	["ShestakBinFrame"] = true,
}

local ignoredButtons = {
	["GatherMatePin"] = true,
	["HandyNotes.-Pin"] = true,
	["Guidelime"] = true,
	["QuestieFrame"] = true,
	["TTMinimapButton"] = true,
}

local function isButtonIgnored(name)
	for addonName in pairs(ignoredButtons) do
		if strmatch(name, addonName) then return true end
	end
	return false
end

local removedTextures = {
	[136430] = true,	-- Interface\Minimap\MiniMap-TrackingBorder
	[136467] = true,	-- Interface\Minimap\MinimapBorder
}

local maxPerRow = 8
local currentIndex, pendingTime, timeThreshold = 0, 5, 12
local buttons, numMinimapChildren = {}, 0

----------------------------------------------------------------------------------------
--	Create toggle button — same anchor as tracking icon for pixel-perfect alignment
--	Tracking icon: BOTTOMLEFT, MinimapAnchor, BOTTOMLEFT, -1, -5  (size 20x20)
--	Our button:    BOTTOMLEFT, MinimapAnchor, BOTTOMLEFT, 22, -5  (1px gap after tracking)
--	Bin panel expands to the LEFT of the toggle button
----------------------------------------------------------------------------------------
local bu = CreateFrame("Button", "ShestakBinToggleButton", UIParent)
bu:SetSize(20, 20)
bu:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, 0) -- placeholder, repositioned in PEW
bu:SetFrameLevel(999)
bu:Hide()

bu.Icon = bu:CreateTexture(nil, "ARTWORK")
-- Use Details class icon based on player class
local _, playerClass = UnitClass("player")
-- Texture coords for classes_small.tga (256x128 sprite sheet, 4 cols x 2 rows per half)
local classIconCoords = {
	WARRIOR     = {0, 0.125, 0, 0.125},
	MAGE        = {0.125, 0.248046875, 0, 0.125},
	ROGUE       = {0.248046875, 0.37109375, 0, 0.125},
	DRUID       = {0.37109375, 0.494140625, 0, 0.125},
	HUNTER      = {0, 0.125, 0.125, 0.25},
	PALADIN     = {0, 0.125, 0.25, 0.375},
	SHAMAN      = {0.125, 0.248046875, 0.125, 0.25},
	PRIEST      = {0.248046875, 0.37109375, 0.125, 0.25},
	WARLOCK     = {0.37109375, 0.494140625, 0.125, 0.25},
	DEATHKNIGHT = {0.125, 0.25, 0.25, 0.375},
}
if playerClass and classIconCoords[playerClass] and IsAddOnLoaded("Details") then
	bu.Icon:SetTexture([[Interface\AddOns\Details\images\classes_small]])
	bu.Icon:SetTexCoord(unpack(classIconCoords[playerClass]))
else
	bu.Icon:SetTexture([[Interface\Icons\INV_Misc_Bag_07]])
	bu.Icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
end
bu.Icon:SetSize(16, 16)
bu.Icon:SetPoint("CENTER", bu)

bu:CreateBackdrop("ClassColor")
bu.backdrop:SetPoint("TOPLEFT", bu.Icon, -2, 2)
bu.backdrop:SetPoint("BOTTOMRIGHT", bu.Icon, 2, -2)

local hl = bu:CreateTexture(nil, "HIGHLIGHT")
hl:SetColorTexture(1, 1, 1, 0.25)
hl:SetAllPoints(bu.Icon)

----------------------------------------------------------------------------------------
--	Create bin frame — holds collected buttons
----------------------------------------------------------------------------------------
local bin = CreateFrame("Frame", "ShestakBinFrame", UIParent)
bin:SetPoint("BOTTOMRIGHT", bu, "BOTTOMLEFT", -3, 0)
bin:SetSize(200, 40)
bin:SetTemplate("Transparent")
bin:Hide()

----------------------------------------------------------------------------------------
--	Auto-hide logic (click any collected button -> auto close)
----------------------------------------------------------------------------------------
local autoRecycle = true

local function hideBin()
	bin:Hide()
end

local function clickFunc(force)
	if force == 1 or autoRecycle then
		UIFrameFadeOut(bin, 0.5, 1, 0)
		C_Timer.After(0.5, hideBin)
	end
end

----------------------------------------------------------------------------------------
--	Skin a collected button (NDUI-style: strip circular borders, set size, add shadow)
----------------------------------------------------------------------------------------
local function ReskinMinimapButton(child, name)
	for j = 1, child:GetNumRegions() do
		local region = select(j, child:GetRegions())
		if region:IsObjectType("Texture") then
			local texture = region:GetTexture() or ""
			if removedTextures[texture] or strfind(texture, "Interface\\CharacterFrame") or strfind(texture, "Interface\\Minimap") then
				region:SetTexture(nil)
				region:Hide()
			end
			if not region.__ignored then
				region:ClearAllPoints()
				region:SetAllPoints()
			end
			region:SetTexCoord(0.1, 0.9, 0.1, 0.9)
		end
	end

	child:SetSize(20, 20)
	child:SetTemplate("ClassColor")
	tinsert(buttons, child)
end

----------------------------------------------------------------------------------------
--	Move collected buttons into bin, strip drag scripts, handle naughty addons
----------------------------------------------------------------------------------------
local function KillMinimapButtons()
	for _, child in pairs(buttons) do
		if not child.styled then
			child:SetParent(bin)
			if child:HasScript("OnDragStop") then child:SetScript("OnDragStop", nil) end
			if child:HasScript("OnDragStart") then child:SetScript("OnDragStart", nil) end
			if child:HasScript("OnClick") then child:HookScript("OnClick", clickFunc) end

			if child:IsObjectType("Button") then
				child:SetHighlightTexture(0)
				local hlTex = child:CreateTexture(nil, "HIGHLIGHT")
				hlTex:SetColorTexture(1, 1, 1, 0.25)
				hlTex:SetAllPoints()
			elseif child:IsObjectType("Frame") then
				child.highlight = child:CreateTexture(nil, "HIGHLIGHT")
				child.highlight:SetAllPoints()
				child.highlight:SetColorTexture(1, 1, 1, 0.25)
			end

			-- Naughty Addons
			local name = child:GetName()
			if name == "DBMMinimapButton" then
				child:SetScript("OnMouseDown", nil)
				child:SetScript("OnMouseUp", nil)
			elseif name == "BagSync_MinimapButton" then
				child:HookScript("OnMouseUp", clickFunc)
			elseif name == "WIM3MinimapButton" then
				child.SetParent = T.dummy
				child:SetFrameStrata("DIALOG")
				child.SetFrameStrata = T.dummy
			end

			child.styled = true
		end
	end
end

----------------------------------------------------------------------------------------
--	Sort collected buttons in bin (NDUI grid layout)
----------------------------------------------------------------------------------------
local shownButtons = {}

local function SortRubbish()
	if #buttons == 0 then return end

	wipe(shownButtons)
	for _, button in pairs(buttons) do
		if next(button) and button:IsShown() then
			tinsert(shownButtons, button)
		end
	end

	local numShown = #shownButtons
	if numShown == 0 then return end

	local btnSize, spacing = 20, 2
	local colWidth = btnSize + spacing
	local cols = math.min(numShown, maxPerRow)
	local rows = math.ceil(numShown / cols)
	local newWidth = cols * colWidth + spacing
	local newHeight = rows * colWidth + spacing
	bin:SetSize(newWidth, newHeight)

	for index, button in pairs(shownButtons) do
		button:ClearAllPoints()
		local col = mod(index - 1, cols)
		local row = floor((index - 1) / cols)
		if index == 1 then
			button:SetPoint("TOPLEFT", bin, spacing, -spacing)
		elseif col == 0 then
			-- First button in a new row: below the button 'cols' positions above
			button:SetPoint("TOP", shownButtons[index - cols], "BOTTOM", 0, -spacing)
		else
			button:SetPoint("LEFT", shownButtons[index - 1], "RIGHT", spacing, 0)
		end
	end
end

----------------------------------------------------------------------------------------
--	Scan Minimap children for new buttons (NDUI approach)
--	Uses isExamed flag to avoid re-processing
--	Re-schedules itself for late-loading addons
----------------------------------------------------------------------------------------
local function CollectRubbish()
	local numChildren = Minimap:GetNumChildren()
	if numChildren ~= numMinimapChildren then
		for i = 1, numChildren do
			local child = select(i, Minimap:GetChildren())
			local name = child and child.GetName and child:GetName()
			if name and not child.isExamed and not blackList[name] then
				if (child:IsObjectType("Button") or strmatch(strupper(name), "BUTTON")) and not isButtonIgnored(name) then
					ReskinMinimapButton(child, name)
				end
				child.isExamed = true
			end
		end
		numMinimapChildren = numChildren
	end

	KillMinimapButtons()

	-- Show/hide toggle based on whether we collected anything
	if #buttons > 0 then
		bu:Show()
	else
		bu:Hide()
	end

	currentIndex = currentIndex + 1
	if currentIndex < timeThreshold then
		C_Timer.After(pendingTime, CollectRubbish)
	end
end

----------------------------------------------------------------------------------------
--	Toggle button click: open/close bin
----------------------------------------------------------------------------------------
bu:SetScript("OnClick", function(_, btn)
	if bin:IsShown() then
		clickFunc(1)
	else
		SortRubbish()
		UIFrameFadeIn(bin, 0.5, 0, 1)
	end
end)

-- Mouseover mode: expand on enter, collapse on leave
if C.skins.minimap_buttons_mouseover then
	bu:HookScript("OnEnter", function()
		SortRubbish()
		UIFrameFadeIn(bin, 0.5, 0, 1)
	end)
	bu:HookScript("OnLeave", function()
		C_Timer.After(0.5, function()
			if not bin:IsMouseOver() and not bu:IsMouseOver() then
				clickFunc(1)
			end
		end)
	end)
	bin:SetScript("OnLeave", function(self)
		C_Timer.After(0.5, function()
			if not self:IsMouseOver() and not bu:IsMouseOver() then
				clickFunc(1)
			end
		end)
	end)
end

----------------------------------------------------------------------------------------
--	Kick off collection immediately (like NDUI — no need to wait for PEW)
--	Minimap exists at file parse time, so we can start scanning right away.
----------------------------------------------------------------------------------------
CollectRubbish()

----------------------------------------------------------------------------------------
--	Reposition toggle button ABOVE tracking icon after PEW
--	Anchor CENTER to CENTER for pixel-perfect horizontal alignment
--	Vertical: stacked with 1px gap above tracking icon
----------------------------------------------------------------------------------------
local posFrame = CreateFrame("Frame")
posFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
posFrame:SetScript("OnEvent", function(self)
	self:UnregisterEvent("PLAYER_ENTERING_WORLD")

	local trackingFrame = _G.MiniMapTracking or _G.MiniMapTrackingFrame
	if trackingFrame and trackingFrame:IsShown() then
		bu:ClearAllPoints()
		bu:SetPoint("BOTTOM", trackingFrame, "TOP", -3, 1)
	else
		local anchor = _G.MinimapAnchor
		if anchor then
			bu:ClearAllPoints()
			bu:SetPoint("BOTTOMLEFT", anchor, "BOTTOMLEFT", 0, -19)
		end
	end
end)
