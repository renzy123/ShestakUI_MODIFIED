local _, ns = ...
local oUF = ns.oUF

local function Update(self, event, unit)
	if(not unit or self.__unit ~= unit) then return end
	local element = self.CombatIndicator

	--[[ Callback: CombatIndicator:PreUpdate()
	Called before the element has been updated.

	* self - the CombatIndicator element
	--]]
	if(element.PreUpdate) then
		element:PreUpdate()
	end

	local inCombat = UnitAffectingCombat(unit)
	if(inCombat) then
		element:Show()
	else
		element:Hide()
	end

	--[[ Callback: CombatIndicator:PostUpdate(inCombat)
	Called after the element has been updated.

	* self     - the CombatIndicator element
	* inCombat - indicates if the unit is affecting combat (boolean)
	--]]
	if(element.PostUpdate) then
		return element:PostUpdate(inCombat)
	end
end

local function Path(self, ...)
	--[[ Override: CombatIndicator.Override(self, event)
	Used to completely override the internal update function.

	* self  - the parent object
	* event - the event triggering the update (string)
	--]]
	return (self.CombatIndicator.Override or Update) (self, ...)
end

local function ForceUpdate(element)
	return Path(element.__owner, 'ForceUpdate')
end

local function Enable(self, unit)
	local element = self.CombatIndicator
	if(element) then
		element.__owner = self
		element.ForceUpdate = ForceUpdate

		self:RegisterEvent('UNIT_FLAGS', Path)

		if(element:IsObjectType('Texture') and not element:GetTexture()) then
			element:SetAtlas('UI-HUD-UnitFrame-Player-CombatIcon')
		end

		return true
	end
end

local function Disable(self)
	local element = self.CombatIndicator
	if(element) then
		element:Hide()

		self:UnregisterEvent('UNIT_FLAGS', Path)
	end
end

oUF:AddElement('CombatIndicator', Path, Enable, Disable)