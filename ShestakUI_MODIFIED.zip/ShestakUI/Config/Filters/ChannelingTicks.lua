local T, C, L = unpack(ShestakUI)
if C.unitframe.enable ~= true or C.unitframe.castbar_ticks ~= true then return end

----------------------------------------------------------------------------------------
--	The best way to add or delete spell is to go at www.wowhead.com, search for a spell.
--	Example: Tranquility -> http://www.wowhead.com/spell=740
--	Take the number ID at the end of the URL, and add it to the list
----------------------------------------------------------------------------------------
local function SpellName(id)
	local name = GetSpellInfo(id)
	if name then
		return name
	else
		print("|cffff0000ShestakUI: ChannelingTicks spell ID ["..tostring(id).."] no longer exists!|r")
		return "Empty"
	end
end

T.CastBarTicks = {
	-- Druid
	[SpellName(740)] = 4,		-- Tranquility
	-- Evoker
	[SpellName(356995)] = 3,	-- Disintegrate
	-- Mage
	[SpellName(5143)] = 5,		-- Arcane Missiles
	[SpellName(12051)] = 6,		-- Evocation
	[SpellName(205021)] = 5,	-- Ray of Frost
	-- Monk
	[SpellName(115175)] = 8,	-- Soothing Mist
	[SpellName(117952)] = 4,	-- Crackling Jade Lightning
	-- Priest
	[SpellName(15407)] = 6,		-- Mind Flay
	[SpellName(47540)] = 3,		-- Penance
	[SpellName(64843)] = 4,		-- Divine Hymn
	-- Warlock
	[SpellName(755)] = 5,		-- Health Funnel
	[SpellName(198590)] = 5,	-- Drain Soul
	[SpellName(234153)] = 5,	-- Drain Life
	-- Racials
	[SpellName(291944)] = 6,	-- Regeneratin (Zandalari)
}

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_TALENT_UPDATE")
f:SetScript("OnEvent", function()
	if T.class == "PRIEST" then
		-- Penance
		local penanceTicks = C_SpellBook.IsSpellKnown(193134) and 4 or 3
		T.CastBarTicks[SpellName(47540)] = penanceTicks
	elseif T.class == "MAGE" then
		-- Arcane Missiles
		local newTicks = C_SpellBook.IsSpellKnown(236628) and 7 or 5
		T.CastBarTicks[SpellName(5143)] = newTicks
	else
		f:UnregisterAllEvents()
	end
end)