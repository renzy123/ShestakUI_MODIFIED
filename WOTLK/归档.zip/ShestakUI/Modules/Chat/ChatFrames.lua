﻿local T, C, L = unpack(ShestakUI)
if C.chat.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Style chat frame (Rewritten based on NDUI architecture for 3.80.1)
----------------------------------------------------------------------------------------

local _G = _G
local pairs, ipairs, format, strsub, strlower = pairs, ipairs, string.format, string.sub, string.lower

-- Helper: Permanently kill a texture on 3.80.1
-- Blizzard FCF system will re-show textures after Kill(), so we must hook Show/SetTexture/SetTexCoord
local function KillTexture(tex)
	if not tex then return end
	if tex.SetTexture then tex:SetTexture(0) end
	if tex.SetTexCoord then tex:SetTexCoord(0, 0, 0, 0) end
	if tex.Hide then tex:Hide() end
	if tex.Show then tex.Show = T.dummy end
	if tex.SetTexture then tex.SetTexture = T.dummy end
	if tex.SetTexCoord then tex.SetTexCoord = T.dummy end
end

-- Helper: PositionButtonFrame (ElvUI approach — move off-screen + SetClipsChildren)
-- Do NOT Hide, change size, or scale down — C-code layout depends on buttonFrame existing
-- Moving off-screen with SetClipsChildren prevents rendering while keeping layout valid
local function PositionButtonFrame(chat)
	if not chat.buttonFrame then return end
	chat.buttonFrame:ClearAllPoints()
	chat.buttonFrame:SetPoint("TOP", chat, "BOTTOM", 0, -90000)
	chat.buttonFrame:SetClipsChildren(true)
end

-- Helper: HideObject (NDUI approach — full kill with parent to HiddenFrame)
local function HideObject(frame)
	if not frame then return end
	if frame.UnregisterAllEvents then
		frame:UnregisterAllEvents()
		frame:SetParent(T.HiddenFrame or UIParent)
	else
		frame.Show = frame.Hide
	end
	frame:Hide()
end

-- Helper: Make FontStringContainer fill the content area (ChatBackground), NOT the tab area
-- ChatFrame's TOPLEFT includes tab bar space — we must skip it to align with the content box below
-- Anchor to ChatBackground (the "below" box) instead of ChatFrame (which includes the "above" tab box)
-- For ChatFrame2 (combat log), extra top offset for CombatLogQuickButtonFrame
local function FillFontStringContainer(frame)
	if not frame.FontStringContainer then return end
	if not ChatBackground then return end
	local topOffset = -1
	-- ChatFrame2 (combat log) has CombatLogQuickButtonFrame at the top of content area
	if frame == _G["ChatFrame2"] and CombatLogQuickButtonFrame_Custom then
		topOffset = -1 - CombatLogQuickButtonFrame_Custom:GetHeight()
	end
	frame.FontStringContainer:ClearAllPoints()
	frame.FontStringContainer:SetPoint("TOPLEFT", ChatBackground, "TOPLEFT", 1, topOffset)
	frame.FontStringContainer:SetPoint("BOTTOMRIGHT", ChatBackground, "BOTTOMRIGHT", -1, 1)
end

-- Function to rename channel and other stuff
local origs = {}
local function Strip(info, name)
	return string.format("|Hplayer:%s|h[%s]|h", info, name:gsub("%-[^|]+", ""))
end

local AddMessage = function(self, text, ...)
	if type(text) == "string" then
		text = text:gsub("|h%[(%d+)%. .-%]|h", "|h[%1]|h")
		text = text:gsub("|Hplayer:(.-)|h%[(.-)%]|h", Strip)
	end
	return origs[self](self, text, ...)
end

-- Global strings
_G.CHAT_INSTANCE_CHAT_GET = "|Hchannel:INSTANCE_CHAT|h["..L_CHAT_INSTANCE_CHAT.."]|h %s:\32"
_G.CHAT_INSTANCE_CHAT_LEADER_GET = "|Hchannel:INSTANCE_CHAT|h["..L_CHAT_INSTANCE_CHAT_LEADER.."]|h %s:\32"
_G.CHAT_BN_WHISPER_GET = L_CHAT_BN_WHISPER.." %s:\32"
_G.CHAT_GUILD_GET = "|Hchannel:GUILD|h["..L_CHAT_GUILD.."]|h %s:\32"
_G.CHAT_OFFICER_GET = "|Hchannel:OFFICER|h["..L_CHAT_OFFICER.."]|h %s:\32"
_G.CHAT_PARTY_GET = "|Hchannel:PARTY|h["..L_CHAT_PARTY.."]|h %s:\32"
_G.CHAT_PARTY_LEADER_GET = "|Hchannel:PARTY|h["..L_CHAT_PARTY_LEADER.."]|h %s:\32"
_G.CHAT_PARTY_GUIDE_GET = CHAT_PARTY_LEADER_GET
_G.CHAT_RAID_GET = "|Hchannel:RAID|h["..L_CHAT_RAID.."]|h %s:\32"
_G.CHAT_RAID_LEADER_GET = "|Hchannel:RAID|h["..L_CHAT_RAID_LEADER.."]|h %s:\32"
_G.CHAT_RAID_WARNING_GET = "["..L_CHAT_RAID_WARNING.."] %s:\32"
_G.CHAT_PET_BATTLE_COMBAT_LOG_GET = "|Hchannel:PET_BATTLE_COMBAT_LOG|h["..L_CHAT_PET_BATTLE.."]|h:\32"
_G.CHAT_PET_BATTLE_INFO_GET = "|Hchannel:PET_BATTLE_INFO|h["..L_CHAT_PET_BATTLE.."]|h:\32"
_G.CHAT_SAY_GET = "%s:\32"
_G.CHAT_WHISPER_GET = L_CHAT_WHISPER.." %s:\32"
_G.CHAT_YELL_GET = "%s:\32"
_G.CHAT_FLAG_AFK = "|cffE7E716"..L_CHAT_AFK.."|r "
_G.CHAT_FLAG_DND = "|cffFF0000"..L_CHAT_DND.."|r "
_G.CHAT_FLAG_GM = "|cff4154F5"..L_CHAT_GM.."|r "
_G.ERR_FRIEND_ONLINE_SS = "|Hplayer:%s|h[%s]|h "..L_CHAT_COME_ONLINE
_G.ERR_FRIEND_OFFLINE_S = "[%s] "..L_CHAT_GONE_OFFLINE

-- Hide chat bubble menu button
ChatFrameMenuButton:Kill()

-- Kill channel and voice buttons
if T.Classic then
	ChatFrameChannelButton:Kill()
else
	ChatFrameChannelButton:Kill()
	ChatFrameToggleVoiceDeafenButton:Kill()
	ChatFrameToggleVoiceMuteButton:Kill()
end

----------------------------------------------------------------------------------------
--	SkinChat: Core chat frame styling (NDUI-style)
----------------------------------------------------------------------------------------
local function SkinChat(frame)
	if not frame or frame.styled then return end

	local name = frame:GetName()

	-- Core frame settings (NDUI approach)
	frame:SetClampRectInsets(0, 0, 0, 0)
	frame:SetClampedToScreen(false)
	frame:SetFading(false)

	-- Kill ALL Blizzard textures completely (ElvUI approach: Kill Background, not just DisableDrawLayer)
	-- DisableDrawLayer is unreliable on 3.80.1 — FCF can re-enable layers
	-- 1. Kill ChatFrame.Background (native background texture)
	if frame.Background then
		frame.Background:SetTexture(nil)
		frame.Background:SetVertexColor(0, 0, 0, 0)
		frame.Background:Hide()
		if frame.Background.Show then frame.Background.Show = T.dummy end
		if frame.Background.SetTexture then frame.Background.SetTexture = T.dummy end
	end
	-- 2. Kill all named CHAT_FRAME_TEXTURES (border/background textures)
	if CHAT_FRAME_TEXTURES then
		for _, texName in ipairs(CHAT_FRAME_TEXTURES) do
			KillTexture(_G[name..texName])
		end
	end
	-- 3. Kill any remaining textures via region enumeration
	for _, region in ipairs({frame:GetRegions()}) do
		if region:IsObjectType("Texture") and region:IsShown() then
			KillTexture(region)
		end
	end
	-- 4. Kill named border/background textures (3.80.1 Cata specific)
	for _, suffix in ipairs({"Background", "TopLeftTexture", "TopRightTexture", "BottomLeftTexture", "BottomRightTexture", "LeftTexture", "RightTexture", "TopTexture", "BottomTexture"}) do
		KillTexture(_G[name..suffix])
	end

	-- Kill tab textures (3.80.1: must use KillTexture to prevent Blizzard re-showing)
	local tabTextureSuffixes = {
		"TabLeft", "TabMiddle", "TabRight",
		"TabSelectedLeft", "TabSelectedMiddle", "TabSelectedRight",
		"TabHighlightLeft", "TabHighlightMiddle", "TabHighlightRight"
	}
	for _, suffix in ipairs(tabTextureSuffixes) do
		KillTexture(_G[name..suffix])
	end
	KillTexture(_G[name.."TabGlow"])

	-- Kill TabFlash frame
	local tabFlash = _G[name.."TabFlash"]
	if tabFlash then
		tabFlash:Hide()
		tabFlash.Show = T.dummy
	end

	-- Tab height and text centering (NDUI/ElvUI-style minimal tabs)
	local tab = _G[name.."Tab"]
	if tab then
		tab:SetHeight(22)
		if tab.Text then
			tab.Text:ClearAllPoints()
			tab.Text:SetPoint("CENTER", tab, 0, -1)
			if C.font.chat_tabs_font_style and C.font.chat_tabs_font_style ~= "" then
				tab.Text:SetShadowColor(0, 0, 0, 0)
			end
			tab.Text:SetFont(C.font.chat_tabs_font, C.font.chat_tabs_font_size, C.font.chat_tabs_font_style)
		end
	end

	-- ButtonFrame: ElvUI approach (move off-screen + SetClipsChildren)
	-- Critical: Do NOT Hide or scale down — C-code layout depends on buttonFrame existing
	PositionButtonFrame(frame)

	-- ScrollToBottomButton: HideObject (full kill)
	HideObject(frame.ScrollToBottomButton)

	-- MinimizeButton
	if T.Wrath then
		local minimizeButton = _G[format("ChatFrame%sMinimizeButton", frame:GetID())]
		if minimizeButton then
			minimizeButton:Kill()
		end
	elseif T.Cata then
		local minimizeButton = _G[format("ChatFrame%sMinimizeButton", frame:GetID())]
		if minimizeButton then
			minimizeButton:Kill()
		end
	end

	-- Kill EditBox border textures (3.80.1: KillTexture prevents Blizzard re-showing)
	for _, suffix in ipairs({"EditBoxLeft", "EditBoxMid", "EditBoxRight", "EditBoxFocusLeft", "EditBoxFocusMid", "EditBoxFocusRight"}) do
		KillTexture(_G[name..suffix])
	end

	-- Walk EditBox regions and children to kill any remaining textures
	local editBoxFrame = _G[name.."EditBox"]
	if editBoxFrame then
		for _, region in ipairs({editBoxFrame:GetRegions()}) do
			if region:GetObjectType() == "Texture" then
				KillTexture(region)
			end
		end
		for _, child in ipairs({editBoxFrame:GetChildren()}) do
			for _, region in ipairs({child:GetRegions()}) do
				if region:GetObjectType() == "Texture" then
					KillTexture(region)
				end
			end
		end
	end

	-- EditBox settings
	_G[name.."EditBox"]:SetAltArrowKeyMode(false)
	_G[name.."EditBox"]:Hide()

	-- Hide editbox on focus lost
	_G[name.."EditBox"]:HookScript("OnEditFocusGained", function(self) self:Show() end)
	_G[name.."EditBox"]:HookScript("OnEditFocusLost", function(self)
		if self:GetText() == "" then self:Hide() end
	end)

	-- Hide editbox on tab click
	_G[name.."Tab"]:HookScript("OnClick", function()
		_G[name.."EditBox"]:Hide()
	end)

	-- Rename combat log tab
	if frame == _G["ChatFrame2"] then
		CombatLogQuickButtonFrame_Custom:StripTextures()
		CombatLogQuickButtonFrame_Custom:CreateBackdrop("Transparent")
		CombatLogQuickButtonFrame_Custom.backdrop:SetPoint("TOPLEFT", 1, -4)
		CombatLogQuickButtonFrame_Custom.backdrop:SetPoint("BOTTOMRIGHT", -22, 0)
		T.SkinCloseButton(CombatLogQuickButtonFrame_CustomAdditionalFilterButton, CombatLogQuickButtonFrame_Custom.backdrop, " ", true)
		CombatLogQuickButtonFrame_CustomAdditionalFilterButton:SetSize(12, 12)
		CombatLogQuickButtonFrame_CustomAdditionalFilterButton:SetHitRectInsets(0, 0, 0, 0)
		CombatLogQuickButtonFrame_CustomProgressBar:ClearAllPoints()
		CombatLogQuickButtonFrame_CustomProgressBar:SetPoint("TOPLEFT", CombatLogQuickButtonFrame_Custom.backdrop, 2, -2)
		CombatLogQuickButtonFrame_CustomProgressBar:SetPoint("BOTTOMRIGHT", CombatLogQuickButtonFrame_Custom.backdrop, -2, 2)
		CombatLogQuickButtonFrame_CustomProgressBar:SetStatusBarTexture(C.media.texture)
		CombatLogQuickButtonFrameButton1:SetPoint("BOTTOM", 0, 0)
	end

	-- AddMessage hook for non-combat frames
	if frame ~= _G["ChatFrame2"] then
		origs[frame] = frame.AddMessage
		frame.AddMessage = AddMessage
		local color = C.chat.custom_time_color and T.RGBToHex(unpack(C.chat.time_color)) or ""
		_G.TIMESTAMP_FORMAT_HHMM = color.."[%I:%M]|r "
		_G.TIMESTAMP_FORMAT_HHMMSS = color.."[%I:%M:%S]|r "
		_G.TIMESTAMP_FORMAT_HHMMSS_24HR = color.."[%H:%M:%S]|r "
		_G.TIMESTAMP_FORMAT_HHMMSS_AMPM = color.."[%I:%M:%S %p]|r "
		_G.TIMESTAMP_FORMAT_HHMM_24HR = color.."[%H:%M]|r "
		_G.TIMESTAMP_FORMAT_HHMM_AMPM = color.."[%I:%M %p]|r "
	end

	frame.styled = true
end

----------------------------------------------------------------------------------------
--	Setup all chat frames
----------------------------------------------------------------------------------------
local function SetupChat()
	for i = 1, NUM_CHAT_WINDOWS do
		SkinChat(_G[format("ChatFrame%s", i)])
	end

	-- Sticky channels
	local var = C.chat.sticky == true and 1 or 0
	ChatTypeInfo.SAY.sticky = var
	ChatTypeInfo.PARTY.sticky = var
	ChatTypeInfo.PARTY_LEADER.sticky = var
	ChatTypeInfo.GUILD.sticky = var
	ChatTypeInfo.OFFICER.sticky = var
	ChatTypeInfo.RAID.sticky = var
	ChatTypeInfo.RAID_WARNING.sticky = var
	ChatTypeInfo.INSTANCE_CHAT.sticky = var
	ChatTypeInfo.INSTANCE_CHAT_LEADER.sticky = var
	ChatTypeInfo.WHISPER.sticky = var
	ChatTypeInfo.BN_WHISPER.sticky = var
	ChatTypeInfo.CHANNEL.sticky = var
end

----------------------------------------------------------------------------------------
--	Setup font and position (called on PLAYER_ENTERING_WORLD)
----------------------------------------------------------------------------------------
local function SetupChatPosAndFont()
	for i = 1, NUM_CHAT_WINDOWS do
		local chat = _G[format("ChatFrame%s", i)]
		local id = chat:GetID()
		local _, fontSize = FCF_GetChatWindowInfo(id)

		if fontSize < 11 then
			FCF_SetChatWindowFontSize(nil, chat, 11)
		else
			FCF_SetChatWindowFontSize(nil, chat, fontSize)
		end

		chat:SetFont(C.font.chat_font, fontSize, C.font.chat_font_style)
		chat:SetShadowOffset(C.font.chat_font_shadow and 1 or 0, C.font.chat_font_shadow and -1 or 0)

		-- Combat log tab handling
		if i == 2 then
			if C.chat.combatlog ~= true then
				FCF_DockFrame(chat)
				ChatFrame2Tab:EnableMouse(false)
				ChatFrame2Tab.Text:Hide()
				ChatFrame2Tab:SetWidth(0.001)
				ChatFrame2Tab.SetWidth = T.dummy
				FCF_DockUpdate()
			end
		end
	end
end

----------------------------------------------------------------------------------------
--	Tab position hooks
----------------------------------------------------------------------------------------
for i = 3, NUM_CHAT_WINDOWS do
	local tab = _G[format("ChatFrame%sTab", i)]
	hooksecurefunc(tab, "SetPoint", function(self, point, anchor, attachTo, x, y)
		if anchor == GeneralDockManagerScrollFrameChild and y == -1 then
			self:ClearAllPoints()
			self:SetPoint(point, anchor, attachTo, x, -2)
		end
	end)
end

GeneralDockManagerOverflowButton:SetPoint("BOTTOMRIGHT", ChatFrame1, "TOPRIGHT", 0, 5)
hooksecurefunc(GeneralDockManagerScrollFrame, "SetPoint", function(self, point, anchor, attachTo, x, y)
	if anchor == GeneralDockManagerOverflowButton and x == 0 and y == 0 then
		self:SetPoint(point, anchor, attachTo, 0, -4)
	end
end)

----------------------------------------------------------------------------------------
--	Sync all docked ChatFrame sizes to ChatFrame1
--	3.80.1 FCF dock mechanism does NOT auto-sync sizes, must do it explicitly
--	Use SetSize to sync dimensions, but let FCF dock manage position (not SetAllPoints)
----------------------------------------------------------------------------------------
local isSyncing = false
local function SyncDockedFrames()
	if isSyncing then return end
	isSyncing = true
	local w, h = ChatFrame1:GetSize()
	for i = 2, NUM_CHAT_WINDOWS do
		local cf = _G[format("ChatFrame%s", i)]
		if cf then
			cf:SetSize(w, h)
			FillFontStringContainer(cf)
		end
	end
	isSyncing = false
end

----------------------------------------------------------------------------------------
--	Update chat size (NDUI approach — simple, direct, no OnUpdate polling)
----------------------------------------------------------------------------------------
local isScaling = false
local function UpdateChatSize()
	if isScaling then return end
	isScaling = true

	-- NDUI: Make FontStringContainer fill entire ChatFrame (eliminates bottom padding)
	FillFontStringContainer(ChatFrame1)

	-- Set ChatFrame1 size and position
	ChatFrame1:ClearAllPoints()
	ChatFrame1:SetSize(C.chat.width, C.chat.height)
	if C.chat.background == true then
		ChatFrame1:SetPoint(C.position.chat[1], C.position.chat[2], C.position.chat[3], C.position.chat[4], C.position.chat[5] + 4)
	else
		ChatFrame1:SetPoint(unpack(C.position.chat))
	end

	if ChatFrame1:IsMovable() then
		ChatFrame1:SetUserPlaced(true)
	end
	FCF_SavePositionAndDimensions(ChatFrame1)

	-- Sync all docked ChatFrame sizes to ChatFrame1 (3.80.1 FCF dock doesn't auto-sync)
	SyncDockedFrames()

	-- Re-apply ButtonFrame off-screen (FCF may have re-positioned it)
	for i = 1, NUM_CHAT_WINDOWS do
		local cf = _G[format("ChatFrame%s", i)]
		if cf then
			PositionButtonFrame(cf)
			HideObject(cf.ScrollToBottomButton)
		end
	end

	isScaling = false
end

----------------------------------------------------------------------------------------
--	Position edit boxes above ChatFrame1 (unified for all tabs)
----------------------------------------------------------------------------------------
local function UpdateEditBoxAnchor(eb)
	if not eb then return end
	eb:ClearAllPoints()
	-- ChatTabsPanel: BOTTOM=ChatFrame1.TOP+3, height=20, so TOP=ChatFrame1.TOP+23
	-- ChatEditBoxPanel: BOTTOM=chatAnchor.TOP+0.5 = ChatFrame1.TOP+23.5
	eb:SetPoint("BOTTOMLEFT", ChatFrame1, "TOPLEFT", -3, 24)
	eb:SetPoint("BOTTOMRIGHT", ChatFrame1, "TOPRIGHT", 3, 24)
	eb:SetHeight(28)
end

local function PositionAllEditBoxes()
	for j = 1, NUM_CHAT_WINDOWS do
		local eb = _G[format("ChatFrame%sEditBox", j)]
		if eb then
			UpdateEditBoxAnchor(eb)
		end
	end
end

----------------------------------------------------------------------------------------
--	Event handler
----------------------------------------------------------------------------------------
local UIChat = CreateFrame("Frame")
UIChat:RegisterEvent("ADDON_LOADED")
UIChat:RegisterEvent("PLAYER_ENTERING_WORLD")
UIChat:SetScript("OnEvent", function(self, event, addon)
	if event == "ADDON_LOADED" then
		if addon == "Blizzard_CombatLog" then
			self:UnregisterEvent("ADDON_LOADED")
			SetupChat()
		end
	elseif event == "PLAYER_ENTERING_WORLD" then
		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
		SetupChatPosAndFont()

		-- Delay: wait for FCF system to finish initialization
		C_Timer.After(1, function()
			-- Update chat size (NDUI approach)
			UpdateChatSize()

			-- Position all edit boxes
			PositionAllEditBoxes()

			-- Re-kill textures that FCF init may have re-shown
			for i = 1, NUM_CHAT_WINDOWS do
				local cfName = format("ChatFrame%s", i)
				-- Re-kill EditBox textures
				for _, suffix in ipairs({"EditBoxLeft", "EditBoxMid", "EditBoxRight", "EditBoxFocusLeft", "EditBoxFocusMid", "EditBoxFocusRight"}) do
					KillTexture(_G[cfName..suffix])
				end
				local editBox = _G[cfName.."EditBox"]
				if editBox then
					for _, region in ipairs({editBox:GetRegions()}) do
						if region:GetObjectType() == "Texture" then
							KillTexture(region)
						end
					end
				end
				-- Re-kill Tab textures
				for _, suffix in ipairs({"TabLeft", "TabMiddle", "TabRight", "TabSelectedLeft", "TabSelectedMiddle", "TabSelectedRight", "TabHighlightLeft", "TabHighlightMiddle", "TabHighlightRight"}) do
					KillTexture(_G[cfName..suffix])
				end
				-- Kill ChatFrame border/background textures (the shadow source)
				-- 3.80.1 Cata uses these named textures for the chat frame border
				for _, suffix in ipairs({"Background", "TopLeftTexture", "TopRightTexture", "BottomLeftTexture", "BottomRightTexture", "LeftTexture", "RightTexture", "TopTexture", "BottomTexture"}) do
					KillTexture(_G[cfName..suffix])
				end
			end

			-- Fix CombatLog sub-tab overlap
			if CombatLogQuickButtonFrame_Custom then
				CombatLogQuickButtonFrame_Custom:ClearAllPoints()
				CombatLogQuickButtonFrame_Custom:SetPoint("TOPLEFT", ChatFrame2, "TOPLEFT", 0, 0)
				CombatLogQuickButtonFrame_Custom:SetPoint("TOPRIGHT", ChatFrame2, "TOPRIGHT", 0, 0)
			end

			-- NDUI: Re-apply FontStringContainer fill for docked frames after FCF init
			SyncDockedFrames()

			-- Force ChatFrame1 size (FCF may have overridden it during init)
			C_Timer.After(2, function()
				if ChatFrame1:GetWidth() ~= C.chat.width or ChatFrame1:GetHeight() ~= C.chat.height then
					chatHookLocked = true
					ChatFrame1:SetSize(C.chat.width, C.chat.height)
					FCF_SavePositionAndDimensions(ChatFrame1)
					chatHookLocked = false
				end
				-- Re-kill border textures one more time (FCF may re-show them very late)
				for i = 1, NUM_CHAT_WINDOWS do
					local cfName = format("ChatFrame%s", i)
					for _, suffix in ipairs({"Background", "TopLeftTexture", "TopRightTexture", "BottomLeftTexture", "BottomRightTexture", "LeftTexture", "RightTexture", "TopTexture", "BottomTexture"}) do
						KillTexture(_G[cfName..suffix])
					end
				end
				SyncDockedFrames()
			end)

			-- Hook docked frames' SetSize to re-sync when FCF overrides dimensions
			for i = 2, NUM_CHAT_WINDOWS do
				local cf = _G[format("ChatFrame%s", i)]
				if cf then
					hooksecurefunc(cf, "SetSize", function()
						if not isSyncing then
							SyncDockedFrames()
						end
					end)
				end
			end

			-- Hook FCF_SavePositionAndDimensions to re-sync docked frames
			hooksecurefunc("FCF_SavePositionAndDimensions", function(chatFrame)
				if chatFrame then
					FillFontStringContainer(chatFrame)
					SyncDockedFrames()
				end
			end)

			-- Hook FCF_SetButtonSide to re-apply ButtonFrame off-screen position
			-- Blizzard code may call this to reposition button frames, which would undo our fix
			if FCF_SetButtonSide then
				hooksecurefunc("FCF_SetButtonSide", function(chatFrame)
					if chatFrame then
						PositionButtonFrame(chatFrame)
					end
				end)
			end

			-- Hook FCF_OpenTemporaryWindow to re-apply FontStringContainer fill on new temp frames
			-- (already handled below in SetupTempChat)
		end)
	end
end)

----------------------------------------------------------------------------------------
--	Setup temp chat (BN, WHISPER) when needed
----------------------------------------------------------------------------------------
local function SetupTempChat()
	local frame = FCF_GetCurrentChatFrame()
	if not frame then return end

	if not frame.styled then
		SkinChat(frame)
	end

	-- Position EditBox
	local eb = frame.editBox or _G[frame:GetName().."EditBox"]
	if eb then
		UpdateEditBoxAnchor(eb)
	end

	-- Hook edit box to show/hide ChatEditBoxPanel
	if eb and ChatEditBoxPanel then
		if not eb._chatInputPanelHooked then
			eb:HookScript("OnEditFocusGained", function() ChatEditBoxPanel:Show() end)
			eb:HookScript("OnEditFocusLost", function() ChatEditBoxPanel:Hide() end)
			eb._chatInputPanelHooked = true
		end
	end

	-- Sync size to ChatFrame1 (use SetSize, not SetAllPoints — FCF dock manages position)
	if frame ~= ChatFrame1 then
		frame:SetSize(ChatFrame1:GetSize())
	end
	FillFontStringContainer(frame)
end
hooksecurefunc("FCF_OpenTemporaryWindow", SetupTempChat)

----------------------------------------------------------------------------------------
--	Disable pet battle tab
----------------------------------------------------------------------------------------
local old = FCFManager_GetNumDedicatedFrames
function FCFManager_GetNumDedicatedFrames(...)
	return select(1, ...) ~= "PET_BATTLE_COMBAT_LOG" and old(...) or 1
end

----------------------------------------------------------------------------------------
--	Remove player's realm name
----------------------------------------------------------------------------------------
local function RemoveRealmName(_, _, msg, author, ...)
	local realm = string.gsub(T.realm, " ", "")
	if msg:find("-" .. realm) then
		return false, gsub(msg, "%-"..realm, ""), author, ...
	end
end
ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", RemoveRealmName)

----------------------------------------------------------------------------------------
--	Save slash command typo
----------------------------------------------------------------------------------------
local function TypoHistory_Posthook_AddMessage(chat, text)
	if text and strfind(text, HELP_TEXT_SIMPLE) then
		ChatEdit_AddHistory(chat.editBox)
	end
end

for i = 1, NUM_CHAT_WINDOWS do
	if i ~= 2 then
		hooksecurefunc(_G["ChatFrame"..i], "AddMessage", TypoHistory_Posthook_AddMessage)
	end
end

----------------------------------------------------------------------------------------
--	Loot icons
----------------------------------------------------------------------------------------
if C.chat.loot_icons == true then
	local function AddLootIcons(_, _, message, ...)
		local function Icon(link)
			local texture = GetItemIcon(link)
			return "\124T"..texture..":12:12:0:0:64:64:5:59:5:59\124t"..link
		end
		message = message:gsub("(\124c%x+\124Hitem:.-\124h\124r)", Icon)
		return false, message, ...
	end

	ChatFrame_AddMessageEventFilter("CHAT_MSG_LOOT", AddLootIcons)
end

----------------------------------------------------------------------------------------
--	Switch channels by Tab
----------------------------------------------------------------------------------------
local cycles = {
	{chatType = "SAY", use = function() return 1 end},
	{chatType = "PARTY", use = function() return not IsInRaid() and IsInGroup(LE_PARTY_CATEGORY_HOME) end},
	{chatType = "RAID", use = function() return IsInRaid(LE_PARTY_CATEGORY_HOME) end},
	{chatType = "INSTANCE_CHAT", use = function() return T.Mainline and IsPartyLFG() end},
	{chatType = "GUILD", use = function() return IsInGuild() end},
	{chatType = "SAY", use = function() return 1 end},
}

local function UpdateTabChannelSwitch(self)
	if strsub(tostring(self:GetText()), 1, 1) == "/" then return end
	local currChatType = self:GetAttribute("chatType")
	for i, curr in ipairs(cycles) do
		if curr.chatType == currChatType then
			local h, r, step = i + 1, #cycles, 1
			if IsShiftKeyDown() then h, r, step = i - 1, 1, -1 end
			for j = h, r, step do
				if cycles[j]:use(self, currChatType) then
					self:SetAttribute("chatType", cycles[j].chatType)
					ChatEdit_UpdateHeader(self)
					return
				end
			end
		end
	end
end
hooksecurefunc("ChatEdit_CustomTabPressed", UpdateTabChannelSwitch)

----------------------------------------------------------------------------------------
--	Role icons
----------------------------------------------------------------------------------------
if (T.Wrath or T.Cata or T.Mainline) and C.chat.role_icons == true then
	local chats = {
		CHAT_MSG_SAY = 1, CHAT_MSG_YELL = 1,
		CHAT_MSG_WHISPER = 1, CHAT_MSG_WHISPER_INFORM = 1,
		CHAT_MSG_PARTY = 1, CHAT_MSG_PARTY_LEADER = 1,
		CHAT_MSG_INSTANCE_CHAT = 1, CHAT_MSG_INSTANCE_CHAT_LEADER = 1,
		CHAT_MSG_RAID = 1, CHAT_MSG_RAID_LEADER = 1, CHAT_MSG_RAID_WARNING = 1,
	}

	local role_tex = {
		TANK = "\124T"..[[Interface\AddOns\ShestakUI\Media\Textures\Tank.tga]]..":12:12:0:0:64:64:5:59:5:59\124t",
		HEALER	= "\124T"..[[Interface\AddOns\ShestakUI\Media\Textures\Healer.tga]]..":12:12:0:0:64:64:5:59:5:59\124t",
		DAMAGER = "\124T"..[[Interface\AddOns\ShestakUI\Media\Textures\Damager.tga]]..":12:12:0:0:64:64:5:59:5:59\124t",
	}

	local GetColoredName_orig = _G.GetColoredName
	local function GetColoredName_hook(event, arg1, arg2, ...)
		local ret = GetColoredName_orig(event, arg1, arg2, ...)
		if chats[event] then
			local role = UnitGroupRolesAssigned(arg2)
			if role == "NONE" and arg2:match(" *- *"..GetRealmName().."$") then
				role = UnitGroupRolesAssigned(arg2:gsub(" *-[^-]+$",""))
			end
			if role and role ~= "NONE" then
				ret = role_tex[role]..""..ret
			end
		end
		return ret
	end
	_G.GetColoredName = GetColoredName_hook
end

----------------------------------------------------------------------------------------
--	Lock chat position (NDUI approach — simple hook, no OnUpdate polling)
----------------------------------------------------------------------------------------
local chatHookLocked = false

hooksecurefunc(ChatFrame1, "SetPoint", function(self, _, _, _, x)
	if chatHookLocked then return end
	if x ~= C.position.chat[4] then
		chatHookLocked = true
		self:ClearAllPoints()
		self:SetSize(C.chat.width, C.chat.height)
		if C.chat.background == true then
			self:SetPoint(C.position.chat[1], C.position.chat[2], C.position.chat[3], C.position.chat[4], C.position.chat[5] + 4)
		else
			self:SetPoint(unpack(C.position.chat))
		end
		FCF_SavePositionAndDimensions(self)
		chatHookLocked = false
	end
end)

-- Enforce ChatFrame1 size and sync docked frames when FCF overrides dimensions
hooksecurefunc(ChatFrame1, "SetSize", function(self, w, h)
	if chatHookLocked then return end
	-- Re-enforce correct size if FCF overrides it
	if w ~= C.chat.width or h ~= C.chat.height then
		chatHookLocked = true
		self:SetSize(C.chat.width, C.chat.height)
		chatHookLocked = false
	end
	FillFontStringContainer(ChatFrame1)
	SyncDockedFrames()
end)

----------------------------------------------------------------------------------------
--	Keep all EditBoxes anchored to ChatFrame1
----------------------------------------------------------------------------------------
hooksecurefunc("ChatEdit_DeactivateChat", function(editBox)
	if not editBox then return end
	local parentFrame = editBox:GetParent()
	if parentFrame and parentFrame ~= ChatFrame1 then
		UpdateEditBoxAnchor(editBox)
	end
end)

hooksecurefunc("ChatEdit_ActivateChat", function(editBox)
	if not editBox then return end
	UpdateEditBoxAnchor(editBox)
end)
