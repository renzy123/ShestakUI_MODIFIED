local T, C, L = unpack(ShestakUI)
if C.aura.cast_by ~= true then return end

----------------------------------------------------------------------------------------
--	Tells you who cast a buff or debuff in its tooltip(prButler by Renstrom)
----------------------------------------------------------------------------------------
local function addAuraSource(self, unit, index, filter, instanceID)
	local srcUnit
	if instanceID then
		local aura = C_UnitAuras.GetAuraDataByAuraInstanceID(unit, index)
		srcUnit = aura and aura.sourceUnit
	else
		local aura = C_UnitAuras.GetAuraDataByIndex(unit, index, filter)
		srcUnit = aura and aura.sourceUnit
	end
	if srcUnit and canaccessvalue(srcUnit) then
		local src = GetUnitName(srcUnit, true)
		if srcUnit == "pet" or srcUnit == "vehicle" then
			src = format("%s (|cff%02x%02x%02x%s|r)", src, T.color.r * 255, T.color.g * 255, T.color.b * 255, GetUnitName("player", true))
		else
			local partypet = srcUnit:match("^partypet(%d+)$")
			local raidpet = srcUnit:match("^raidpet(%d+)$")
			if partypet then
				src = format("%s (%s)", src, GetUnitName("party"..partypet, true))
			elseif raidpet then
				src = format("%s (%s)", src, GetUnitName("raid"..raidpet, true))
			end
		end
		if UnitIsPlayer(srcUnit) or UnitInPartyIsAI(srcUnit) then
			local color = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[select(2, UnitClass(srcUnit))]
			if color then
				src = format("|cff%02x%02x%02x%s|r", color.r * 255, color.g * 255, color.b * 255, src)
			end
		else
			local color = T.oUF_colors.reaction[UnitReaction(srcUnit, "player")]
			if color then
				src = format("|cff%02x%02x%02x%s|r", color.r * 255, color.g * 255, color.b * 255, src)
			end
		end
		self:AddLine(DONE_BY.." "..src)
		self:Show()
	end
end

local funcs = {
	"SetUnitAura",
	"SetUnitBuff",
	"SetUnitDebuff",
	"SetUnitBuffByAuraInstanceID",
	"SetUnitDebuffByAuraInstanceID",
	"SetUnitAuraByAuraInstanceID"
}

for i = 1, #funcs do
	local func = funcs[i]
	if i > 3 then -- InstanceID
		hooksecurefunc(GameTooltip, func, function(self, unit, index, filter)
			addAuraSource(self, unit, index, filter, true)
		end)
	else
		hooksecurefunc(GameTooltip, func, function(self, unit, index, filter)
			addAuraSource(self, unit, index, filter)
		end)
	end
end