local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	SpellBook skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	-- 3.80.1 时光服裁剪版技能书：整体加 nil 检查
	if not SpellBookFrame then return end

	SpellBookFrame:StripTextures()
	SpellBookFrame:CreateBackdrop("Transparent")
	SpellBookFrame.backdrop:SetPoint("TOPLEFT", 10, -12)
	SpellBookFrame.backdrop:SetPoint("BOTTOMRIGHT", -32, 76)

	T.SkinNextPrevButton(SpellBookPrevPageButton)
	T.SkinNextPrevButton(SpellBookNextPageButton)
	if SpellBookNextPageButton and SpellBookPrevPageButton then
		SpellBookNextPageButton:SetPoint("BOTTOMRIGHT", SpellBookFrame.backdrop, "BOTTOMRIGHT", -15, 10)
		SpellBookPrevPageButton:SetPoint("BOTTOMRIGHT", SpellBookNextPageButton, "BOTTOMLEFT", -6, 0)
	end

	T.SkinCloseButton(SpellBookCloseButton, SpellBookFrame.backdrop)

	if T.Wrath or T.Cata then
		-- 3.80.1 时光服的 WotLK 客户端里 ShowAllSpellRanksCheckBox 可能被简化裁剪
		if ShowAllSpellRanksCheckBox and _G.SpellButton1 then
			T.SkinCheckBox(ShowAllSpellRanksCheckBox)
			ShowAllSpellRanksCheckBox:SetPoint("TOPLEFT", _G.SpellButton1, "TOPLEFT", -7, 32)
		end
	end

	SpellBookTitleText:ClearAllPoints()
	SpellBookTitleText:SetPoint("TOP", SpellBookFrame.backdrop, "TOP", 0, -6)

	-- Skin SpellButtons
	local function SpellButtons(self, first)
		for i = 1, SPELLS_PER_PAGE do
			local button = _G["SpellButton"..i]
			local icon = _G["SpellButton"..i.."IconTexture"]
			if not button then break end

			if first then
				-- _G["SpellButton"..i.."SlotFrame"]:SetAlpha(0)
				button:StripTextures()

				if button.EmptySlot then button.EmptySlot:SetAlpha(0) end
				-- button.TextBackground:Hide()
				-- button.TextBackground2:Hide()
				-- button.UnlearnedFrame:SetAlpha(0)
				button:SetCheckedTexture(0)
				button:SetPushedTexture(0)
			end

			local highlight = _G["SpellButton"..i.."Highlight"]
			if highlight then
				highlight:SetColorTexture(1, 1, 1, 0.3)
				highlight:ClearAllPoints()
				if icon then highlight:SetAllPoints(icon) end
			end

			if icon then
				icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				icon:ClearAllPoints()
				icon:SetAllPoints()

				if not button.backdrop then
					button:SetFrameLevel(button:GetFrameLevel() + 1)
					button:CreateBackdrop("Default")
				end
			end

			-- 3.80.1 时光服 SpellButton 子组件命名与 Retail 对齐：
			-- SpellName/SubSpellName 仍用 _G["SpellButtonN.."] 全局命名，存在；
			-- AutoCastable 改名为 AutoCastOverlay（button 字段），_G["...AutoCastable"] 为 nil。
			local spellName = _G["SpellButton"..i.."SpellName"]
			if spellName then
				local r, g, b = spellName:GetTextColor()
				if r and r < 0.8 then
					spellName:SetTextColor(0.6, 0.6, 0.6)
				end
			end

			local subSpellName = _G["SpellButton"..i.."SubSpellName"]
			if subSpellName then
				subSpellName:SetTextColor(0.6, 0.6, 0.6)
			end

			-- AutoCastable 兼容：优先用 Retail 命名 button.AutoCastOverlay，fallback 到老命名全局
			local autoCastable = button.AutoCastOverlay
				or button.AutoCastable
				or _G["SpellButton"..i.."AutoCastable"]
				or _G["SpellButton"..i.."AutoCastOverlay"]
			if autoCastable then
				if autoCastable.SetTexture then autoCastable:SetTexture("Interface\\Buttons\\UI-AutoCastableOverlay") end
				if autoCastable.ClearAllPoints then autoCastable:ClearAllPoints() end
				if autoCastable.SetPoint then
					autoCastable:SetPoint("TOPLEFT", -12, 12)
					autoCastable:SetPoint("BOTTOMRIGHT", 14, -14)
				end
				if autoCastable.SetTexCoord then autoCastable:SetTexCoord(0.1, 0.9, 0.1, 0.9) end
			end
		end
	end
	SpellButtons(nil, true)
	-- 3.80.1 时光服里 SpellButton_UpdateButton 可能被改名/裁剪，hook 前检查函数存在
	if type(_G.SpellButton_UpdateButton) == "function" then
		hooksecurefunc("SpellButton_UpdateButton", SpellButtons)
	end

	if SpellBookPageText then SpellBookPageText:SetTextColor(0.6, 0.6, 0.6) end

	-- Skill Line Tabs
	for i = 1, MAX_SKILLLINE_TABS do
		local tab = _G["SpellBookSkillLineTab"..i]
		local flash = _G["SpellBookSkillLineTab"..i.."Flash"]
		if flash then flash:Kill() end
		if tab then
			tab:StripTextures()
			if tab.GetNormalTexture then
				local nt = tab:GetNormalTexture()
				if nt then
					nt:ClearAllPoints()
					nt:SetPoint("TOPLEFT", 2, -2)
					nt:SetPoint("BOTTOMRIGHT", -2, 2)
					nt:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				end
			end

			tab:CreateBackdrop("Default")
			if tab.backdrop then tab.backdrop:SetAllPoints() end
			if tab.StyleButton then tab:StyleButton(true) end

			local point, relatedTo, point2 = tab:GetPoint()
			if point then
				if i == 1 then
					tab:SetPoint(point, relatedTo, point2, -30, -64)
				else
					tab:SetPoint(point, relatedTo, point2, 0, -16)
				end
			end
		end
	end

	local function SkinSkillLine()
		for i = 1, MAX_SKILLLINE_TABS do
			local tab = _G["SpellBookSkillLineTab"..i]
			local _, _, _, _, isGuild = GetSpellTabInfo(i)
			if isGuild and tab and tab.GetNormalTexture then
				local nt = tab:GetNormalTexture()
				if nt then
					nt:ClearAllPoints()
					nt:SetPoint("TOPLEFT", 2, -2)
					nt:SetPoint("BOTTOMRIGHT", -2, 2)
					nt:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				end
			end
		end
	end
	-- 3.80.1 时光服里 SpellBookFrame_UpdateSkillLineTabs 可能被改名/裁剪，hook 前检查
	if type(_G.SpellBookFrame_UpdateSkillLineTabs) == "function" then
		hooksecurefunc("SpellBookFrame_UpdateSkillLineTabs", SkinSkillLine)
	end

	-- Bottom Tabs
	if SpellBookFrameTabButton1 and SpellBookFrame.backdrop then
		SpellBookFrameTabButton1:ClearAllPoints()
		SpellBookFrameTabButton1:SetPoint("TOPLEFT", SpellBookFrame.backdrop, "BOTTOMLEFT", 2, -2)
	end
	for i = 1, 3 do
		local tab = _G["SpellBookFrameTabButton"..i]
		local lastTab = _G["SpellBookFrameTabButton"..(i-1)]
		if lastTab then
			tab:ClearAllPoints()
			tab:SetPoint("LEFT", lastTab, "RIGHT", -16, 0)
		end
		tab:StripTextures()
		tab:SetNormalTexture(0)
		tab:SetHighlightTexture(0)
		tab:SetSize(tab:GetWidth() * 0.75, 32)
		T.SkinTab(tab)
	end
end

tinsert(T.SkinFuncs["ShestakUI"], LoadSkin)
