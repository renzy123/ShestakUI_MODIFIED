local T, C, L = unpack(ShestakUI)
if C.reminder.solo_buffs_enable ~= true then return end

----------------------------------------------------------------------------------------
--	Self buffs on player(by Tukz and Elv22)
----------------------------------------------------------------------------------------
local tab = T.ReminderSelfBuffs[T.class]
if not tab then return end
local playerBuff = {}
local isDeadlyBrew = T.SoD and C_Engraving.IsRuneEquipped(48141)

local function OnEvent(self, event)
	local group = tab[self.id]
	if not group.spells then return end
	-- 3.80.1 时光服 (WotLK) 没有真正的专精系统，T.GetSpecialization() 只是天赋页统计，
	-- 新号/没点天赋时返回 nil。原代码不论版本只要拿不到 spec 就整体 return，
	-- 导致 WotLK 没点天赋的角色完全看不到任何 buff 缺失提示。
	-- 修复：只在 Cata+ (有真正的专精系统) 或 Retail 才检查专精，WotLK 及以下不检查。
	if T.Mainline and not GetSpecialization() then return end
	if (T.Cata or T.Mainline) and T.Classic and not T.GetSpecialization() then return end
	if group.level and T.level < group.level then return end

	self:Hide()

	for i = 1, #group.spells do
		local name, icon = unpack(group.spells[i])
		local usable, nomana = IsUsableSpell(name)
		if usable or nomana or group.level then
			self.icon:SetTexture(icon)
			break
		else
			self.icon:SetTexture(0)
		end
	end

	if event == "PLAYER_LOGIN" then
		if not self.icon:GetTexture() then
			self:UnregisterAllEvents()
			pcall(self.RegisterEvent, self, "LEARNED_SPELL_IN_TAB")
		end
		return
	end

	if event == "LEARNED_SPELL_IN_TAB" and self.icon:GetTexture() then
		self:UnregisterAllEvents()
		self:RegisterUnitEvent("UNIT_AURA", "player", "")
		self:RegisterEvent("UNIT_ENTERED_VEHICLE")
		self:RegisterEvent("UNIT_EXITED_VEHICLE")

		if group.combat then
			self:RegisterEvent("PLAYER_REGEN_ENABLED")
			self:RegisterEvent("PLAYER_REGEN_DISABLED")
		end

		if group.instance or group.pvp then
			self:RegisterEvent("ZONE_CHANGED_NEW_AREA")
		end
	end

	if group.mainhand or group.offhand then
		self:RegisterUnitEvent("UNIT_INVENTORY_CHANGED", "player", "")
	end

	local role = group.role
	local spec = group.spec
	local reversecheck = group.reversecheck
	local canplaysound = false
	local rolepass = true
	local specpass = true
	local _, instanceType, difficultyID = GetInstanceInfo()

	if role and role ~= T.Role then
		rolepass = false
	end

	if spec and spec ~= T.Spec then
		specpass = false
	end

	-- Prevent user error
	if reversecheck ~= nil and (role == nil and spec == nil) then reversecheck = nil end

	-- Check event to play sound
	if (event == "ZONE_CHANGED_NEW_AREA" or event == "PLAYER_REGEN_DISABLED") and C.reminder.solo_buffs_sound == true then canplaysound = true end

	if ((group.combat and UnitAffectingCombat("player")) or (group.instance and difficultyID ~= 0 and (T.Mainline and not C_Garrison.IsOnGarrisonMap())) or (group.pvp and (instanceType == "arena" or instanceType == "pvp"))) and
	specpass == true and rolepass == true and not UnitInVehicle("player") then
		if group.mainhand then
			local hasMainHandEnchant = GetWeaponEnchantInfo()
			if not hasMainHandEnchant and not isDeadlyBrew then
				self:Show()
				if canplaysound == true then PlaySoundFile(C.media.warning_sound, "Master") end
			end
			return
		elseif group.offhand then
			local _, _, _, _, hasOffHandEnchant = GetWeaponEnchantInfo()
			-- WotLK 3.80.1 没有 C_PaperDollInfo.OffhandHasWeapon (Retail 8.0+ API)，
			-- 回退顺序：C_PaperDollInfo.OffhandHasWeapon (Retail) → 全局 OffhandHasWeapon() (WotLK) → GetInventoryItemID “player” 17 (终极 fallback)
			-- 否则 hasOffhand 恒为 nil，副手缺毒/缺附魔永不提示。
			local hasOffhand
			if C_PaperDollInfo and C_PaperDollInfo.OffhandHasWeapon then
				hasOffhand = C_PaperDollInfo.OffhandHasWeapon()
			elseif OffhandHasWeapon then
				hasOffhand = OffhandHasWeapon()
			else
				hasOffhand = GetInventoryItemID("player", 17) ~= nil
			end
			if not hasOffHandEnchant and hasOffhand and not isDeadlyBrew then
				self:Show()
				if canplaysound == true then PlaySoundFile(C.media.warning_sound, "Master") end
			end
			return
		end

		wipe(playerBuff)
		local i = 1
		while true do
			local name = UnitBuff("player", i)
			if not name then break end
			playerBuff[name] = true
			i = i + 1
		end
		if reversecheck then
			if group.negate_reversecheck and group.negate_reversecheck == T.Spec then self:Hide() return end
			for i = 1, #group.spells do
				local name = group.spells[i][1]
				if name and playerBuff[name] then
					self:Show()
					if canplaysound == true then PlaySoundFile(C.media.warning_sound, "Master") end
					return
				end
			end
		else
			for i = 1, #group.spells do
				local name = group.spells[i][1]
				if name and playerBuff[name] then
					self:Hide()
					return
				end
			end
			self:Show()
			if canplaysound == true then PlaySoundFile(C.media.warning_sound, "Master") end
		end
	end
end

-- 多组提示并排显示：第 1 个用用户配置的 anchor (C.position.self_buffs)，
-- 后续每个组在前一个 frame 左侧并排，间隔 5px。
-- 原实现所有 ReminderFrame 都用同一 anchor，多组同时显示时完全叠加，看不到法术石/诅咒等组。
local previousFrame

for i = 1, #tab do
	-- Skip shields group for Shaman's in Vanilla when not playing SoD
	if not T.Vanilla or T.SoD or (T.Vanilla and (T.class ~= "SHAMAN" or i ~= 1)) then
		local frame = CreateFrame("Frame", "ReminderFrame"..i, UIParent)
		if previousFrame then
			frame:CreatePanel("Default", C.reminder.solo_buffs_size, C.reminder.solo_buffs_size, "RIGHT", previousFrame, "LEFT", -5, 0)
		else
			frame:CreatePanel("Default", C.reminder.solo_buffs_size, C.reminder.solo_buffs_size, unpack(C.position.self_buffs))
		end
		frame:SetFrameLevel(6)
		frame.id = i

		frame.icon = frame:CreateTexture(nil, "OVERLAY")
		frame.icon:CropIcon()
		frame.icon:SetSize(C.reminder.solo_buffs_size, C.reminder.solo_buffs_size)

		frame:Hide()

		frame:RegisterUnitEvent("UNIT_AURA", "player", "")
		frame:RegisterEvent("PLAYER_LOGIN")
		frame:RegisterEvent("PLAYER_REGEN_ENABLED")
		frame:RegisterEvent("PLAYER_REGEN_DISABLED")
		frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
		frame:RegisterEvent("UNIT_ENTERED_VEHICLE")
		frame:RegisterEvent("UNIT_EXITED_VEHICLE")
		frame:SetScript("OnEvent", OnEvent)
		frame:SetScript("OnShow", function(self)
			if not self.icon:GetTexture() then
				self:Hide()
			end
		end)

		previousFrame = frame
	end
end