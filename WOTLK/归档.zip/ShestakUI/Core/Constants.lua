local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	ShestakUI variables
----------------------------------------------------------------------------------------
T.dummy = function() return end
T.name = UnitName("player")
T.race = select(2, UnitRace("player"))
T.class = select(2, UnitClass("player"))
T.level = UnitLevel("player")
T.client = GetLocale()
T.realm = GetRealmName()
T.color = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[T.class]
T.version = C_AddOns.GetAddOnMetadata("ShestakUI", "Version")
T.screenWidth, T.screenHeight = GetPhysicalScreenSize()
T.HiDPI = GetScreenHeight() / T.screenHeight < 0.75

----------------------------------------------------------------------------------------
--	WOW_PROJECT_ID compatibility for 3.80.1 时光服
--	On 3.80.1, WOW_PROJECT_ID and all WOW_PROJECT_*_CLASSIC globals are nil,
--	causing nil == nil = true which makes T.Mainline=true, T.Classic=false.
--	This also breaks LibHealComm, LibClassicCasterino, oUF etc. that check these globals.
--	We must set them BEFORE any comparisons.
----------------------------------------------------------------------------------------
if not _G.WOW_PROJECT_ID then
	local _, _, _, toc = GetBuildInfo()
	-- Define the standard enum values if they don't exist
	if not _G.WOW_PROJECT_MAINLINE then _G.WOW_PROJECT_MAINLINE = 1 end
	if not _G.WOW_PROJECT_CLASSIC then _G.WOW_PROJECT_CLASSIC = 2 end
	if not _G.WOW_PROJECT_BURNING_CRUSADE_CLASSIC then _G.WOW_PROJECT_BURNING_CRUSADE_CLASSIC = 5 end
	if not _G.WOW_PROJECT_WRATH_CLASSIC then _G.WOW_PROJECT_WRATH_CLASSIC = 11 end
	if not _G.WOW_PROJECT_CATACLYSM_CLASSIC then _G.WOW_PROJECT_CATACLYSM_CLASSIC = 14 end
	-- Detect project from interface version
	if toc >= 100000 then
		_G.WOW_PROJECT_ID = _G.WOW_PROJECT_MAINLINE
	elseif toc >= 40100 then
		_G.WOW_PROJECT_ID = _G.WOW_PROJECT_CATACLYSM_CLASSIC
	elseif toc >= 30400 then
		_G.WOW_PROJECT_ID = _G.WOW_PROJECT_WRATH_CLASSIC
	elseif toc >= 20500 then
		_G.WOW_PROJECT_ID = _G.WOW_PROJECT_BURNING_CRUSADE_CLASSIC
	elseif toc >= 10000 then
		_G.WOW_PROJECT_ID = _G.WOW_PROJECT_CLASSIC
	else
		_G.WOW_PROJECT_ID = _G.WOW_PROJECT_CLASSIC
	end
end

T.toc = select(4, GetBuildInfo())
T.newPatch = T.toc >= 100105
T.Mainline =_G.WOW_PROJECT_ID == _G.WOW_PROJECT_MAINLINE
T.Classic = _G.WOW_PROJECT_ID ~= _G.WOW_PROJECT_MAINLINE
T.Vanilla = _G.WOW_PROJECT_ID == _G.WOW_PROJECT_CLASSIC
T.Vanilla115 = T.Vanilla and T.toc >= 11500
T.TBC = _G.WOW_PROJECT_ID == _G.WOW_PROJECT_BURNING_CRUSADE_CLASSIC
T.Wrath = _G.WOW_PROJECT_ID == _G.WOW_PROJECT_WRATH_CLASSIC
T.Cata = _G.WOW_PROJECT_ID == _G.WOW_PROJECT_CATACLYSM_CLASSIC
T.Hardcore = C_GameRules and C_GameRules.IsHardcoreActive()
T.SoM = C_Seasons and C_Seasons.HasActiveSeason() and C_Seasons.GetActiveSeason() == Enum.SeasonID.SeasonOfMastery
T.SoD = C_Seasons and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == Enum.SeasonID.SeasonOfDiscovery or C_Seasons.GetActiveSeason() == Enum.SeasonID.Placeholder)

-- 3.80.1 时光服 uses Retail-style UI (PetActionBar object, EditMode, etc.) despite being T.Classic
-- This flag detects the hybrid UI architecture for proper API branching
T.NewClassicUI = T.Classic and (_G.PetActionBar ~= nil) and (type(_G.PetActionBar) == "table")

----------------------------------------------------------------------------------------
--	API Compatibility Layer for Classic (3.80.1 时光服)
--	Blizzard moved many global functions to C_AddOns namespace in newer clients.
--	If the old globals are nil, alias them from the C_AddOns namespace.
----------------------------------------------------------------------------------------
if not IsAddOnLoaded then
	IsAddOnLoaded = C_AddOns.IsAddOnLoaded or function() return false end
end
if not GetAddOnInfo then
	GetAddOnInfo = C_AddOns.GetAddOnInfo or function() return nil end
end
if not GetNumAddOns then
	GetNumAddOns = C_AddOns.GetNumAddOns or function() return 0 end
end
if not GetAddOnMemoryUsage then
	GetAddOnMemoryUsage = C_AddOns.GetAddOnMemoryUsage or function() return 0 end
end
if not UpdateAddOnMemoryUsage then
	UpdateAddOnMemoryUsage = C_AddOns.UpdateAddOnMemoryUsage or function() end
end
if not GetAddOnCPUUsage then
	GetAddOnCPUUsage = C_AddOns.GetAddOnCPUUsage or function() return 0 end
end
if not UpdateAddOnCPUUsage then
	UpdateAddOnCPUUsage = C_AddOns.UpdateAddOnCPUUsage or function() end
end
if not ResetCPUUsage then
	ResetCPUUsage = C_AddOns.ResetCPUUsage or function() end
end
if not GetAddOnEnableState then
	GetAddOnEnableState = C_AddOns.GetAddOnEnableState or function() return 0 end
end
if not EnableAddOn then
	EnableAddOn = C_AddOns.EnableAddOn or function() end
end
if not DisableAddOn then
	DisableAddOn = C_AddOns.DisableAddOn or function() end
end
if not LoadAddOn then
	LoadAddOn = C_AddOns.LoadAddOn or function() return false end
end
if not IsAddOnLoadOnDemand then
	IsAddOnLoadOnDemand = C_AddOns.IsAddOnLoadOnDemand or function() return false end
end

-- CastingBarFrame_SetUnit may not exist in some Classic clients
if not CastingBarFrame_SetUnit then
	CastingBarFrame_SetUnit = function(frame, unit)
		if frame and frame.SetUnit then
			frame:SetUnit(unit)
		end
	end
end

-- BETA
GetContainerItemInfo = GetContainerItemInfo or function(bagIndex, slotIndex)
	local info = C_Container.GetContainerItemInfo(bagIndex, slotIndex)
	if info then
		return info.iconFileID, info.stackCount, info.isLocked, info.quality, info.isReadable, info.hasLoot, info.hyperlink, info.isFiltered, info.hasNoValue, info.itemID, info.isBound
	end
end

-- C_GuildInfo compatibility for 3.80.1 时光服 (uses global GuildRoster() instead)
if not C_GuildInfo then
	C_GuildInfo = {}
end
if not C_GuildInfo.GuildRoster then
	C_GuildInfo.GuildRoster = GuildRoster or function() end
end
if not C_GuildInfo.GetGuildNewsInfo then
	C_GuildInfo.GetGuildNewsInfo = function() return nil end
end

-- CreateVector2D compatibility for 3.80.1 时光服
-- Retail uses CreateVector2D for C_Map.GetWorldPosFromMapPos, but it doesn't exist on 3.80.1
-- We provide a minimal Vector2D implementation with Subtract() for coordinate math
if not CreateVector2D then
	local Vector2D = {}
	Vector2D.__index = Vector2D
	function Vector2D:Subtract(other)
		self.x = self.x - other.x
		self.y = self.y - other.y
		return self
	end
	CreateVector2D = function(x, y)
		return setmetatable({x = x or 0, y = y or 0}, Vector2D)
	end
end

----------------------------------------------------------------------------------------
--	3.80.2 Compatibility Layer for missing C_ namespaces
--	3.80.2 is a Cata client but many Retail C_ namespaces are missing or incomplete.
--	We provide stubs/fallbacks so the addon code doesn't crash on nil access.
----------------------------------------------------------------------------------------

-- C_ChatInfo (added 9.0 Shadowlands, not on Cata)
if not C_ChatInfo then
	C_ChatInfo = {}
	function C_ChatInfo.SendAddonMessage(prefix, message, channel, target)
		SendAddonMessage(prefix, message, channel, target)
	end
	function C_ChatInfo.RegisterAddonMessagePrefix(prefix)
		RegisterAddonMessagePrefix(prefix)
	end
end

-- C_Container (added 10.0 Dragonflight, not on Cata)
-- Cata uses global functions like GetContainerNumSlots, GetContainerItemLink, etc.
if not C_Container then
	C_Container = {}
	C_Container.GetContainerNumSlots = GetContainerNumSlots
	C_Container.GetContainerNumFreeSlots = GetContainerNumFreeSlots
	C_Container.GetContainerItemInfo = function(bag, slot)
		local icon, count, locked, quality, readable, lootable, link, filtered, noValue, itemID, isBound = GetContainerItemInfo(bag, slot)
		if icon then
			return {
				iconFileID = icon, stackCount = count, isLocked = locked, quality = quality,
				isReadable = readable, hasLoot = lootable, hyperlink = link, isFiltered = filtered,
				hasNoValue = noValue, itemID = itemID, isBound = isBound
			}
		end
	end
	C_Container.GetContainerItemLink = GetContainerItemLink
	C_Container.GetContainerItemID = GetContainerItemID
	C_Container.GetContainerItemCooldown = GetContainerItemCooldown
	C_Container.GetItemCooldown = GetItemCooldown
	C_Container.UseContainerItem = UseContainerItem
	C_Container.PickupContainerItem = PickupContainerItem
	C_Container.ContainerIDToInventoryID = ContainerIDToInventoryID
	C_Container.SetInsertItemsLeftToRight = function() end
	C_Container.SetSortBagsRightToLeft = function() end
	C_Container.SortBags = function() end
	C_Container.SortBankBags = function() end
	C_Container.SortReagentBankBags = function() end
	C_Container.GetContainerItemQuestInfo = function() return nil end
	C_Container.GetContainerItemEquipmentSetInfo = function() return nil end
end

-- C_CurrencyInfo (added 9.0 Shadowlands, not on Cata)
if not C_CurrencyInfo then
	C_CurrencyInfo = {}
	C_CurrencyInfo.GetCurrencyListSize = GetNumCurrencyTypes or function() return 0 end
	C_CurrencyInfo.GetCurrencyListInfo = function(index)
		local name, isHeader, isExpanded, isUnused, isWatched, count, extraCurrencyType, icon, itemID = GetCurrencyListInfo(index)
		return {
			name = name, isHeader = isHeader, isHeaderExpanded = isExpanded,
			isTypeUnused = isUnused, isShowInBackpack = isWatched,
			quantity = count, extraCurrencyType = extraCurrencyType,
			iconFileID = icon, itemID = itemID
		}
	end
	C_CurrencyInfo.ExpandCurrencyList = function(index, expand)
		ExpandCurrencyList(index, expand)
	end
	C_CurrencyInfo.GetCurrencyListLink = function(index)
		local link = GetCurrencyListLink(index)
		return link
	end
	C_CurrencyInfo.GetCurrencyInfo = function(id)
		local name, count, extraCurrencyType, icon, itemID = GetCurrencyInfo(id)
		return {
			name = name, quantity = count, iconFileID = icon, itemID = itemID
		}
	end
end

-- C_AdventureJournal (Retail only, not on Cata)
if not C_AdventureJournal then
	C_AdventureJournal = {}
	function C_AdventureJournal.CanBeShown()
		return EncounterJournal and true or false
	end
end

-- C_TooltipInfo (Retail 10.0+, not on Cata)
if not C_TooltipInfo then
	C_TooltipInfo = {}
	function C_TooltipInfo.GetInventoryItem()
		return nil
	end
end

-- C_PlayerInfo (Retail, not on Cata)
if not C_PlayerInfo then
	C_PlayerInfo = {}
	function C_PlayerInfo.GetContentDifficultyQuestForPlayer()
		return 1
	end
end

-- C_QuestLog (exists on Cata but some methods may be missing)
if not C_QuestLog then
	C_QuestLog = {}
	C_QuestLog.GetNumQuestWatches = GetNumQuestWatches or function() return 0 end
	C_QuestLog.GetQuestIDForQuestWatchIndex = function(i)
		return GetQuestWatchInfo(i)
	end
	C_QuestLog.GetNumQuestLogEntries = GetNumQuestLogEntries
	C_QuestLog.GetQuestInfo = function(questID)
		return GetQuestLogTitle(GetQuestLogIndexByID(questID))
	end
	C_QuestLog.GetSelectedQuest = GetQuestLogSelectedQuest or GetQuestLogSelection or function() return 0 end
	C_QuestLog.GetLogIndexForQuestID = function() return nil end
	C_QuestLog.IsPushableQuest = function() return false end
	C_QuestLog.IsWorldQuest = function() return false end
	C_QuestLog.GetTitleForQuestID = function() return nil end
	C_QuestLog.GetNextWaypointText = function() return nil end
end
