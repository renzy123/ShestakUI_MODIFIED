local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	TimeManager skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	-- 3.80.1 时光服 TimeManager 结构与原版可能不同，整段防御性 nil 检查
	if not TimeManagerFrame then return end

	TimeManagerFrame:StripTextures()
	TimeManagerFrame:CreateBackdrop("Transparent")
	TimeManagerFrame.backdrop:SetPoint("TOPLEFT", -3, 0)
	TimeManagerFrame.backdrop:SetPoint("BOTTOMRIGHT", -3, 3)
	if TimeManagerFrameInset then TimeManagerFrameInset:StripTextures() end

	if TimeManagerFrameCloseButton then
		T.SkinCloseButton(TimeManagerFrameCloseButton, TimeManagerFrame.backdrop)
	end

	-- 3.80.1 时光服可能没有闹钟相关下拉框
	if TimeManagerAlarmHourDropDown then T.SkinDropDownBox(TimeManagerAlarmHourDropDown, 79) end
	if TimeManagerAlarmMinuteDropDown then T.SkinDropDownBox(TimeManagerAlarmMinuteDropDown, 79) end
	if TimeManagerAlarmAMPMDropDown then T.SkinDropDownBox(TimeManagerAlarmAMPMDropDown, 70) end

	if TimeManagerAlarmMessageEditBox then
		T.SkinEditBox(TimeManagerAlarmMessageEditBox, nil, TimeManagerAlarmMessageEditBox:GetHeight() - 5)
	end

	if TimeManagerAlarmEnabledButton then T.SkinCheckBox(TimeManagerAlarmEnabledButton) end
	if TimeManagerMilitaryTimeCheck then T.SkinCheckBox(TimeManagerMilitaryTimeCheck) end
	if TimeManagerLocalTimeCheck then T.SkinCheckBox(TimeManagerLocalTimeCheck) end

	if TimeManagerStopwatchFrame then
		TimeManagerStopwatchFrame:StripTextures()
		if TimeManagerStopwatchCheck then
			TimeManagerStopwatchCheck:StyleButton(true)
			TimeManagerStopwatchCheck:SetTemplate("Default")
			local nt = TimeManagerStopwatchCheck:GetNormalTexture()
			if nt then
				nt:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				nt:ClearAllPoints()
				nt:SetPoint("TOPLEFT", 2, -2)
				nt:SetPoint("BOTTOMRIGHT", -2, 2)
			end
		end
	end

	if StopwatchFrame then
		StopwatchFrame:StripTextures()
		StopwatchFrame:CreateBackdrop("Transparent")
		StopwatchFrame.backdrop:SetPoint("TOPLEFT", 2, -15)
		StopwatchFrame.backdrop:SetPoint("BOTTOMRIGHT", -2, 2)

		if StopwatchTabFrame then StopwatchTabFrame:StripTextures() end
		if StopwatchCloseButton then T.SkinCloseButton(StopwatchCloseButton) end
		if StopwatchPlayPauseButton then T.SkinNextPrevButton(StopwatchPlayPauseButton) end
		if StopwatchResetButton then T.SkinNextPrevButton(StopwatchResetButton) end
		if StopwatchPlayPauseButton and StopwatchResetButton then
			StopwatchPlayPauseButton:SetPoint("RIGHT", StopwatchResetButton, "LEFT", -4, 0)
		end
		if StopwatchResetButton then
			StopwatchResetButton:SetPoint("BOTTOMRIGHT", StopwatchFrame, "BOTTOMRIGHT", -7, 7)
		end
		if StopwatchCloseButton and StopwatchFrame.backdrop then
			StopwatchCloseButton:ClearAllPoints()
			StopwatchCloseButton:SetPoint("BOTTOMRIGHT", StopwatchFrame.backdrop, "TOPRIGHT", 0, 3)
		end
	end
end

T.SkinFuncs["Blizzard_TimeManager"] = LoadSkin
