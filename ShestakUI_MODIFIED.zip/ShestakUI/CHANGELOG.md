# ShestakUI

## [11.1.6](https://github.com/Wetxius/ShestakUI/tree/11.1.6) (2026-05-12)
[Full Changelog](https://github.com/Wetxius/ShestakUI/compare/11.1.5...11.1.6) [Previous Releases](https://github.com/Wetxius/ShestakUI/releases)

- Updated version to 11.1.6.  
- [UnitFrames] Rework over absorb to show value.  
- [Skins] Fixed ContainerFrameCombinedBags position.  
- Updateв oUF Tags.  
- [12.0.7] LiteStats use new RegisterEventCallback for MINIMAP\_PING.  
- [ChatFrames] Reposition tab text (fix whisper position).  
- [AutoAccept] Fixed UnitGUID secret error.  
- [RaidHeal] Apply icon\_multiplier for raid debuffs.  
- Revert "Use ShouldUnitIdentityBeSecret for some cases."  
- Added check for existing unitID.  
- Use ShouldUnitIdentityBeSecret for some cases.  
- [Tooltip] Check secret for realm.  
