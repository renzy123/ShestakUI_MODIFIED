local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	Player Choice skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	local frame = _G.PlayerChoiceFrame

	hooksecurefunc(frame, "SetupOptions", function(self)
		if not frame.IsSkinned then
			frame.BlackBackground:SetAlpha(0)
			frame.Background:SetAlpha(0)
			frame.NineSlice:SetAlpha(0)
			frame.BorderOverlay:SetAlpha(0)
			frame.Header.Texture:SetAlpha(0)

			frame:CreateBackdrop("Transparent")

			frame.Title:DisableDrawLayer("BACKGROUND")
			frame.Title.Text:SetTextColor(1, .8, 0)

			T.SkinCloseButton(frame.CloseButton)

			hooksecurefunc(frame.CloseButton, "SetPoint", function(self, point, anchor, attachTo, x)
				if x ~= -4 then
					self:SetPoint(point, anchor, attachTo, -4, -4)
				end
			end)

			frame.IsSkinned = true
		end

		if frame.CloseButton.Border then
			frame.CloseButton.Border:SetAlpha(0)
		end

		local IsAnima = frame.uiTextureKit and frame.uiTextureKit == "jailerstower"
		frame.backdrop:SetShown(not IsAnima)

		for option in self.optionPools:EnumerateActiveByTemplate(self.optionFrameTemplate) do
			local hasArtwork = option.ArtworkBorder and option.ArtworkBorder:IsShown()
			option:CreateBackdrop("Overlay")
			option.backdrop:SetPoint("TOPLEFT", -2, 20)
			option.backdrop:SetPoint("BOTTOMRIGHT", 2, -8)
			option.backdrop:SetShown(not IsAnima and hasArtwork)

			if option.Header and option.Header.Ribbon then option.Header.Ribbon:SetAlpha(0) end
			if option.Header and option.Header.Contents then option.Header.Contents.Text:SetTextColor(1, .8, 0) end
			option.OptionText:SetTextColor(1, 1, 1)

			if option.Background then option.Background:SetShown(not hasArtwork) end
			if IsAnima and option.Background then
				option.Background:Show()
			end

			if option.ArtworkBorder then
				option.ArtworkBorder:SetAlpha(0)
				if not option.ArtBackdrop then
					option.ArtBackdrop = CreateFrame("Frame", nil, option)
					option.ArtBackdrop:SetFrameLevel(option:GetFrameLevel())
					option.ArtBackdrop:SetPoint("TOPLEFT", option.Artwork, -2, 2)
					option.ArtBackdrop:SetPoint("BOTTOMRIGHT", option.Artwork, 2, -2)
					option.ArtBackdrop:SetTemplate("Default")
				end
				option.ArtBackdrop:SetShown(not IsAnima and hasArtwork)
				if PlayerChoiceFrame:IsLegacy() then -- Garrison
					option.ArtBackdrop:Hide()
				end
			end

			local buttonsContainer = option.OptionButtonsContainer
			if buttonsContainer and buttonsContainer.buttonFramePool then
				for buttonFrame in buttonsContainer.buttonFramePool:EnumerateActive() do
					if not buttonFrame.isSkinned then
						if IsAnima then
							buttonFrame.Button:StripTextures(true)
						end
						-- if i == 1 or (hasArtwork and i == 2) then
							buttonFrame.Button:SkinButton()
						-- end
						buttonFrame.isSkinned = true
					end
				end
			end

			local rewardframe = option.Rewards
			if rewardframe then
				for reward in rewardframe.rewardsPool:EnumerateActive() do
					if not reward.backdrop and reward.Icon then
						reward.Icon:SkinIcon()
					end
					if reward.Name then reward.Name:SetTextColor(1, 1, 1) end
					if reward.IconBorder then reward.IconBorder:SetTexture("") end
					local item = reward.itemButton
					if item and not item.isSkinned then
						item.NormalTexture:SetAlpha(0)
						item.icon:SkinIcon()
						T.SkinIconBorder(item.IconBorder, item.backdrop, nil, true)
						item.isSkinned = true
					end
					local r, g, b
					if reward.IconBorder and reward.IconBorder:IsShown() then
						r, g, b = reward.IconBorder:GetVertexColor()
						if (r > 0.64 and r < 0.67) or (r > 0.99 and g > 0.99 and b > 0.99) then
							r, g, b = unpack(C.media.border_color)
						end
					else
						r, g, b = unpack(C.media.border_color)
					end
					if reward.backdrop then reward.backdrop:SetBackdropBorderColor(r, g, b) end
				end
			end

			local widgetFrames = option.WidgetContainer.widgetFrames
			if widgetFrames then
				for _, widgetFrame in next, widgetFrames do
					if widgetFrame.widgetType == _G.Enum.UIWidgetVisualizationType.TextWithState then
						widgetFrame.Text:SetTextColor(1, 1, 1)
					elseif widgetFrame.widgetType == _G.Enum.UIWidgetVisualizationType.SpellDisplay then
						local element = widgetFrame.Spell
						local _, g = element.Text:GetTextColor()
						if g < 0.2 then
							element.Text:SetTextColor(1, 1, 1)
						end
						element.Border:Hide()
						element.IconMask:Hide()
						if not element.backdrop then
							element.Icon:SkinIcon()
						end
						if element.Icon:GetWidth() < 25 then
							element.Icon:SetSize(20, 20)
						end
					elseif widgetFrame.widgetType == _G.Enum.UIWidgetVisualizationType.ItemDisplay then
						local element = widgetFrame.Item
						if not element.backdrop then
							element.NameFrame:SetAlpha(0)
							element.Icon:SkinIcon()
							if element.IconBorder then
								T.SkinIconBorder(element.IconBorder, element.backdrop, nil, true)
							end
						end
						if element.Icon:GetWidth() < 25 then
							element.Icon:SetSize(20, 20)
						end
						element.IconMask:Hide()
						if element.IconOverlay then element.IconOverlay:Hide() end
					end
				end
			end
		end
	end)
end

T.SkinFuncs["Blizzard_PlayerChoice"] = LoadSkin