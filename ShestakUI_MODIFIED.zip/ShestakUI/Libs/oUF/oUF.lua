local parent, ns = ...
local global = C_AddOns.GetAddOnMetadata(parent, 'X-oUF')
local _VERSION = '@project-version@'
if(_VERSION:find('project%-version')) then
	_VERSION = 'devel'
end

local oUF = ns.oUF
local Private = oUF.Private

local argcheck = Private.argcheck
local print = Private.print --luacheck: no unused
local unitExists = Private.unitExists
local nierror = Private.nierror

local styles, style = {}
local callback, objects, headers = {}, {}, {}

local elements = {}
local activeElements = {}
local pausedElements = {}

local function updateActiveUnit(self, event)
	-- Calculate units to work with
	local realUnit, modUnit = SecureButton_GetUnit(self), SecureButton_GetModifiedUnit(self)

	-- _GetUnit() doesn't rewrite playerpet -> pet like _GetModifiedUnit does.
	if(realUnit == 'playerpet') then
		realUnit = 'pet'
	elseif(realUnit == 'playertarget') then
		realUnit = 'target'
	end

	if(modUnit == 'pet' and realUnit ~= 'pet') then
		modUnit = 'vehicle'
	end

	if(not unitExists(modUnit)) then return end

	-- Change the active unit and run a full update.
	if(Private.UpdateUnits(self, modUnit, realUnit)) then
		self:UpdateAllElements(event or 'RefreshUnit')

		return true
	end
end

local function evalUnitAndUpdate(self, event)
	if(not updateActiveUnit(self, event)) then
		return self:UpdateAllElements(event)
	end
end

local function iterateChildren(...)
	for i = 1, select('#', ...) do
		local obj = select(i, ...)

		if(type(obj) == 'table' and obj.isChild) then
			updateActiveUnit(obj, 'iterateChildren')
		end
	end
end

local function onAttributeChanged(self, name, value)
	if(name == 'unit' and value) then
		if(self.hasChildren) then
			iterateChildren(self:GetChildren())
		end

		if(not self:GetAttribute('oUF-onlyProcessChildren')) then
			updateActiveUnit(self, 'OnAttributeChanged')
		end
	end
end

local frame_metatable = {
	__index = CreateFrame('Button')
}
Private.frame_metatable = frame_metatable

local objectElementUpdateFuncs = {}
function Private.insertObjectElementUpdateFunc(object, func)
	table.insert(objectElementUpdateFuncs[object], func)
end

for k, v in next, {
	--[[ frame:EnableElement(name[, unit])
	Used to activate an element on the given unit frame.

	If the element was previously paused on the given unit frame it will also be resumed.

	* self - unit frame for which the element should be enabled
	* name - name of the element to be enabled (string)
	* unit - unit to be passed to the element's Enable function. Defaults to the frame's unit (string?)
	--]]
	EnableElement = function(self, name, unit)
		argcheck(name, 2, 'string')
		argcheck(unit, 3, 'string', 'nil')

		local element = elements[name]
		if(not element or self:IsElementEnabled(name)) then return end

		if(element.enable(self, unit or self.__unit)) then
			activeElements[self][name] = true

			if(pausedElements[self]) then
				pausedElements[self][name] = nil
			end

			if(element.update) then
				table.insert(objectElementUpdateFuncs[self], element.update)
			end
		end
	end,

	--[[ frame:DisableElement(name[, unit])
	Used to deactivate an element on the given unit frame.

	* self - unit frame for which the element should be disabled
	* name - name of the element to be disabled (string)
	* unit - unit to be passed to the element's Disable function. Defaults to the frame's unit (string?)
	--]]
	DisableElement = function(self, name, unit)
		argcheck(name, 2, 'string')
		argcheck(unit, 3, 'string', 'nil')

		if(not self:IsElementEnabled(name)) then return end

		activeElements[self][name] = nil

		if(self:IsElementPaused(name)) then
			-- no need to run deactivation as that's already been done from pausing, just
			-- remove the pause state instead
			pausedElements[self][name] = nil

			return true
		end

		local update = elements[name].update
		if(update) then
			for index, func in next, objectElementUpdateFuncs[self] do
				if(func == update) then
					table.remove(objectElementUpdateFuncs[self], index)
					break
				end
			end
		end

		return elements[name].disable(self, unit or self.__unit)
	end,

	--[[ frame:IsElementEnabled(name)
	Used to check if an element is enabled on the given frame.

	* self - unit frame
	* name - name of the element (string)
	--]]
	IsElementEnabled = function(self, name)
		argcheck(name, 2, 'string')

		if(not elements[name]) then return end

		local active = activeElements[self]
		return active and active[name]
	end,

	--[[ frame:PauseElement(name[, unit])
	Used to pause the execution of an element on the given unit frame.

	Nameplates automatically resume paused elements.

	* self - unit frame for which the element should be paused
	* name - name of the element to be paused (string)
	* unit - unit to be passed to the element's Disable function. Defaults to the frame's unit (string?)
	--]]
	PauseElement = function(self, name, unit)
		argcheck(name, 2, 'string')
		argcheck(unit, 3, 'string', 'nil')

		if(self:IsElementPaused(name) or not self:IsElementEnabled(name)) then return end

		if(not pausedElements[self]) then
			pausedElements[self] = {}
		end

		pausedElements[self][name] = true

		-- deactivate as if we're disabling
		local update = elements[name].update
		if(update) then
			for index, func in next, objectElementUpdateFuncs[self] do
				if(func == update) then
					table.remove(objectElementUpdateFuncs[self], index)
					break
				end
			end
		end

		return elements[name].disable(self, unit or self.__unit)
	end,

	--[[ frame:ResumeElement(name[, unit])
	Used to resume a paused element on the given unit frame, if the element is not disabled.

	* self - unit frame for which the element should be resumed
	* name - name of the element to be resumed (self)
	* unit - unit to be passed to the element's Enable function. Defaults to the frame's unit (string?)
	--]]
	ResumeElement = function(self, name, unit)
		argcheck(name, 2, 'string')
		argcheck(unit, 3, 'string', 'nil')

		if(not self:IsElementPaused(name) or not self:IsElementEnabled(name)) then return end

		local element = elements[name]
		if(element.enable(self, unit or self.__unit)) then
			pausedElements[self][name] = nil

			if(element.update) then
				table.insert(objectElementUpdateFuncs[self], element.update)
			end
		end
	end,

	--[[ frame:IsElementPaused(name)
	Used to check if an element is paused on a given frame.

	* self - unit frame
	* name - name of the element (string)
	--]]
	IsElementPaused = function(self, name)
		argcheck(name, 2, 'string')

		if(not elements[name]) then return end

		local paused = pausedElements[self]
		return paused and paused[name]
	end,

	--[[ frame:Enable(asState)
	Used to toggle the visibility of a unit frame based on the existence of its unit. This is a reference to
	`RegisterUnitWatch`.

	* self    - unit frame
	* asState - if true, the frame's "state-unitexists" attribute will be set to a boolean value denoting whether the
	            unit exists; if false, the frame will be shown if its unit exists, and hidden if it does not (boolean)
	--]]
	Enable = RegisterUnitWatch,
	--[[ frame:Disable()
	Used to UnregisterUnitWatch for the given frame and hide it.

	* self - unit frame
	--]]
	Disable = function(self)
		UnregisterUnitWatch(self)
		self:Hide()
	end,
	--[[ frame:IsEnabled()
	Used to check if a unit frame is registered with the unit existence monitor. This is a reference to
	`UnitWatchRegistered`.

	* self - unit frame
	--]]
	IsEnabled = UnitWatchRegistered,
	--[[ frame:UpdateAllElements(event)
	Used to update all enabled elements on the given frame, unless they're paused.

	* self  - unit frame
	* event - event name to pass to the elements' update functions (string)
	--]]
	UpdateAllElements = function(self, event)
		local unit = self.__unit
		if(not unitExists(unit)) then return end

		assert(type(event) == 'string', "Invalid argument 'event' in UpdateAllElements.")

		if(self.PreUpdate) then
			--[[ Callback: frame:PreUpdate(event)
			Fired before the frame is updated.

			* self  - the unit frame
			* event - the event triggering the update (string)
			--]]
			self:PreUpdate(event)
		end

		for _, func in next, objectElementUpdateFuncs[self] do
			func(self, event, unit)
		end

		if(self.PostUpdate) then
			--[[ Callback: frame:PostUpdate(event)
			Fired after the frame is updated.

			* self  - the unit frame
			* event - the event triggering the update (string)
			--]]
			self:PostUpdate(event)
		end
	end,

	--[[ frame:PauseAllElements()
	Pauses all elements on the given unit frame.

	* self - unit frame for which the elements should be paused
	--]]
	PauseAllElements = function(self)
		for element in next, activeElements[self] do
			self:PauseElement(element)
		end
	end,

	--[[ frame:ResumeAllElements()
	Resumes all paused elements on the given unit frame.

	* self - unit frame for which the elements should be resumed
	--]]
	ResumeAllElements = function(self)
		if(not pausedElements[self]) then return end

		for element in next, pausedElements[self] do
			self:ResumeElement(element)
		end
	end,
} do
	frame_metatable.__index[k] = v
end

local function onShow(self)
	evalUnitAndUpdate(self, 'OnShow')
end

local function updatePet(self, event, unit)
	local petUnit
	if(unit == 'target') then
		return
	elseif(unit == 'player') then
		petUnit = 'pet'
	else
		-- Convert raid26 -> raidpet26
		petUnit = unit:gsub('^(%a+)(%d+)', '%1pet%2')
	end

	if(self.__unit ~= petUnit) then return end

	evalUnitAndUpdate(self, event)
end

local function updateRaid(self, event)
	local unitGUID = UnitGUID(self.__unit)
	if(unitGUID ~= nil and not issecretvalue(unitGUID) and unitGUID ~= self.unitGUID) then
		self.unitGUID = unitGUID

		self:UpdateAllElements(event)
	end
end

local function initObject(unit, style, styleFunc, header, ...)
	local num = select('#', ...)
	for i = 1, num do
		local object = select(i, ...)
		local objectUnit = object:GetAttribute('oUF-guessUnit') or unit
		local suffix = object:GetAttribute('unitsuffix')

		-- Handle the case where someone has modified the unitsuffix attribute in
		-- oUF-initialConfigFunction.
		if(suffix and not objectUnit:match(suffix)) then
			objectUnit = objectUnit .. suffix
		end

		objectElementUpdateFuncs[object] = {}
		object.style = style
		object = setmetatable(object, frame_metatable)

		-- Expose the frame through oUF.objects.
		table.insert(objects, object)

		-- We have to force update the frames when PEW fires.
		-- It's also important to evaluate units before running an update
		-- because sometimes events that are required for unit updates end up
		-- not firing because of loading screens. For instance, there's a slight
		-- delay between UNIT_EXITING_VEHICLE and UNIT_EXITED_VEHICLE during
		-- which a user can go through a loading screen after which the player
		-- frame will be stuck with the 'vehicle' unit.
		object:RegisterEvent('PLAYER_ENTERING_WORLD', evalUnitAndUpdate, true)

		if(not objectUnit:match('%w+target') and not object.isNamePlate) then
			object:RegisterEvent('UNIT_ENTERED_VEHICLE', evalUnitAndUpdate)
			object:RegisterEvent('UNIT_EXITED_VEHICLE', evalUnitAndUpdate)

			-- We don't need to register UNIT_PET for the player unit. We register it
			-- mainly because UNIT_EXITED_VEHICLE and UNIT_ENTERED_VEHICLE don't always
			-- have pet information when they fire for party and raid units.
			if(objectUnit ~= 'player') then
				object:RegisterEvent('UNIT_PET', updatePet)
			end
		end

		if(not header) then
			-- No header means it's a frame created through :Spawn().
			object:SetAttribute('*type1', 'target')
			object:SetAttribute('*type2', 'togglemenu')
			object:SetAttribute('toggleForVehicle', true)

			if(objectUnit:match('%w+target')) then
				oUF:HandleEventlessUnit(object)
			else
				oUF:HandleUnit(object)
			end
		else
			-- update the frame when its prev unit is replaced with a new one
			-- updateRaid relies on UnitGUID to detect the unit change
			object:RegisterEvent('GROUP_ROSTER_UPDATE', updateRaid, true)

			if(num > 1) then
				if(object:GetParent() == header) then
					object.hasChildren = true
				else
					object.isChild = true
				end
			end

			if(suffix == 'target') then
				oUF:HandleEventlessUnit(object)
			end
		end

		Private.UpdateUnits(object, objectUnit)

		styleFunc(object, objectUnit, not header)

		object:HookScript('OnAttributeChanged', onAttributeChanged)

		-- NAME_PLATE_UNIT_ADDED fires after the frame is shown, so there's no
		-- need to call UAE multiple times
		if(not object.isNamePlate) then
			object:SetScript('OnShow', onShow)
		end

		activeElements[object] = {}
		for element in next, elements do
			object:EnableElement(element, objectUnit)
		end

		for _, func in next, callback do
			func(object)
		end

		-- Make Clique kinda happy
		if(not object.isNamePlate) then
			_G.ClickCastFrames = _G.ClickCastFrames or {}
			_G.ClickCastFrames[object] = true
		end
	end
end

local function walkObject(object, unit)
	local parent = object:GetParent()
	local style = parent.style or style
	local styleFunc = styles[style]

	local header = parent:GetAttribute('oUF-headerType') and parent

	-- Check if we should leave the main frame blank.
	if(object:GetAttribute('oUF-onlyProcessChildren')) then
		object.hasChildren = true
		object:HookScript('OnAttributeChanged', onAttributeChanged)
		return initObject(unit, style, styleFunc, header, object:GetChildren())
	end

	return initObject(unit, style, styleFunc, header, object, object:GetChildren())
end

--[[ oUF:RegisterInitCallback(func)
Used to add a function to a table to be executed upon unit frame/header initialization.

* self - the global oUF object
* func - function to be added
--]]
function oUF:RegisterInitCallback(func)
	table.insert(callback, func)
end

--[[ oUF:RegisterMetaFunction(name, func)
Used to make a (table of) function(s) available to all unit frames.

* self - the global oUF object
* name - unique name of the function (string)
* func - function or a table of functions (function or table)
--]]
function oUF:RegisterMetaFunction(name, func)
	argcheck(name, 2, 'string')
	argcheck(func, 3, 'function', 'table')

	if(frame_metatable.__index[name]) then
		return
	end

	frame_metatable.__index[name] = func
end

--[[ oUF:RegisterStyle(name, func)
Used to register a style with oUF. This will also set the active style if it hasn't been set yet.

* self - the global oUF object
* name - name of the style
* func - function(s) defining the style (function or table)
--]]
function oUF:RegisterStyle(name, func)
	argcheck(name, 2, 'string')
	argcheck(func, 3, 'function', 'table')

	if(styles[name]) then return nierror(string.format('Style [%s] already registered.', name)) end
	if(not style) then style = name end

	styles[name] = func
end

--[[ oUF:SetActiveStyle(name)
Used to set the active style.

* self - the global oUF object
* name - name of the style (string)
--]]
function oUF:SetActiveStyle(name)
	argcheck(name, 2, 'string')
	if(not styles[name]) then return nierror(string.format('Style [%s] does not exist.', name)) end

	style = name
end

--[[ oUF:GetActiveStyle()
Used to get the active style.

* self - the global oUF object
--]]
function oUF:GetActiveStyle()
	return style
end

do
	local function iter(_, n)
		-- don't expose the style functions.
		return (next(styles, n))
	end

	--[[ oUF:IterateStyles()
	Returns an iterator over all registered styles.

	* self - the global oUF object
	--]]
	function oUF.IterateStyles()
		return iter, nil, nil
	end
end

local getCondition
do
	local conditions = {
		raid40 = '[@raid26,exists] show;',
		raid25 = '[@raid11,exists] show;',
		raid10 = '[@raid6,exists] show;',
		raid = '[group:raid] show;',
		party = '[group:party,nogroup:raid] show;',
		solo = '[@player,exists,nogroup:party] show;',
	}

	function getCondition(...)
		local cond = ''

		for i = 1, select('#', ...) do
			local short = select(i, ...)

			local condition = conditions[short]
			if(condition) then
				cond = cond .. condition
			end
		end

		return cond .. 'hide'
	end
end

local function generateName(unit, ...)
	local name = 'oUF_' .. style:gsub('^oUF_?', ''):gsub('[^%a%d_]+', '')

	local raid, party, groupFilter, unitsuffix
	for i = 1, select('#', ...), 2 do
		local att, val = select(i, ...)
		if(att == 'oUF-initialConfigFunction') then
			unitsuffix = val:match('unitsuffix[%p%s]+(%a+)')
		elseif(att == 'showRaid') then
			raid = val ~= false and val ~= nil
		elseif(att == 'showParty') then
			party = val ~= false and val ~= nil
		elseif(att == 'groupFilter') then
			groupFilter = val
		end
	end

	local append
	if(raid) then
		if(groupFilter) then
			if(type(groupFilter) == 'number' and groupFilter > 0) then
				append = 'Raid' .. groupFilter
			elseif(groupFilter:match('MAINTANK')) then
				append = 'MainTank'
			elseif(groupFilter:match('MAINASSIST')) then
				append = 'MainAssist'
			else
				local _, count = groupFilter:gsub(',', '')
				if(count == 0) then
					append = 'Raid' .. groupFilter
				else
					append = 'Raid'
				end
			end
		else
			append = 'Raid'
		end
	elseif(party) then
		append = 'Party'
	elseif(unit) then
		append = unit:gsub('^%l', string.upper)
	end

	if(append) then
		name = name .. append .. (unitsuffix or '')
	end

	-- Change oUF_LilyRaidRaid into oUF_LilyRaid
	name = name:gsub('(%u%l+)([%u%l]*)%1', '%1')
	-- Change oUF_LilyTargettarget into oUF_LilyTargetTarget
	name = name:gsub('t(arget)', 'T%1')
	name = name:gsub('p(et)', 'P%1')
	name = name:gsub('f(ocus)', 'F%1')

	local base = name
	local i = 2
	while(_G[name]) do
		name = base .. i
		i = i + 1
	end

	return name
end

do
	local function styleProxy(self, frame)
		return walkObject(_G[frame])
	end

	-- There has to be an easier way to do this.
	local initialConfigFunction = [[
		local header = self:GetParent()
		local frames = table.new()
		table.insert(frames, self)
		self:GetChildList(frames)
		for i = 1, #frames do
			local frame = frames[i]
			local unit
			-- There's no need to do anything on frames with onlyProcessChildren
			if(not frame:GetAttribute('oUF-onlyProcessChildren')) then
				RegisterUnitWatch(frame)

				-- Attempt to guess what the header is set to spawn.
				local groupFilter = header:GetAttribute('groupFilter')

				if(type(groupFilter) == 'string' and groupFilter:match('MAIN[AT]')) then
					local role = groupFilter:match('MAIN([AT])')
					if(role == 'T') then
						unit = 'maintank'
					else
						unit = 'mainassist'
					end
				elseif(header:GetAttribute('showRaid')) then
					unit = 'raid'
				elseif(header:GetAttribute('showParty')) then
					unit = 'party'
				end

				local headerType = header:GetAttribute('oUF-headerType')
				local suffix = frame:GetAttribute('unitsuffix')
				if(unit and suffix) then
					if(headerType == 'pet' and suffix == 'target') then
						unit = unit .. headerType .. suffix
					else
						unit = unit .. suffix
					end
				elseif(unit and headerType == 'pet') then
					unit = unit .. headerType
				end

				frame:SetAttribute('*type1', 'target')
				frame:SetAttribute('*type2', 'togglemenu')
				frame:SetAttribute('oUF-guessUnit', unit)
			end

			local body = header:GetAttribute('oUF-initialConfigFunction')
			if(body) then
				frame:Run(body, unit)
			end
		end

		header:CallMethod('styleFunction', self:GetName())

		local clique = header:GetFrameRef('clickcast_header')
		if(clique) then
			clique:SetAttribute('clickcast_button', self)
			clique:RunAttribute('clickcast_register')
		end
	]]

	local headerMixin = {}
	--[[ header:SetVisibility(visibility)
	Sets the macro conditional(s) controlling when to display the header (string).
	--]]
	function headerMixin:SetVisibility(visibility)
		argcheck(visibility, 2, 'string', 'nil')

		local type, list = string.split(' ', visibility, 2)
		if(list and type == 'custom') then
			RegisterAttributeDriver(self, 'state-visibility', list)
			self.visibility = list
		else
			local condition = getCondition(string.split(',', visibility))
			RegisterAttributeDriver(self, 'state-visibility', condition)
			self.visibility = condition
		end
	end

	--[[ oUF:SpawnHeader(overrideName, template, ...)
	Used to create a group header and apply the currently active style to it.

	* self         - the global oUF object
	* overrideName - unique global name to be used for the header. Defaults to an auto-generated name based on the name
	                 of the active style and other arguments passed to `:SpawnHeader` (string?)
	* template     - name of a template to be used for creating the header. Defaults to `'SecureGroupHeaderTemplate'`
	                 (string?)
	* ...          - further argument pairs. Consult [Group Headers](https://warcraft.wiki.gg/wiki/SecureGroupHeaderTemplate)
	                 for possible values. If preferred, the attributes can be an associative table.

	In addition to the standard group headers, oUF implements some of its own attributes. These can be supplied by the
	layout, but are optional. PingableUnitFrameTemplate is inherited for Ping support.

	* oUF-initialConfigFunction - can contain code that will be securely run at the end of the initial secure
	                              configuration (string?)
	* oUF-onlyProcessChildren   - can be used to force headers to only process children (boolean?)
	--]]
	function oUF:SpawnHeader(overrideName, template, ...)
		if(not style) then return nierror('Unable to create frame. No styles have been registered.') end

		template = (template or 'SecureGroupHeaderTemplate')

		local isPetHeader = template:match('PetHeader')
		local name = overrideName or generateName(nil, ...)
		local header = Mixin(CreateFrame('Frame', name, UIParent, template), headerMixin)
		header:SetRolesets('unitFrames')

		header:SetAttribute('template', 'SecureUnitButtonTemplate, SecureHandlerStateTemplate, SecureHandlerEnterLeaveTemplate, PingableUnitFrameTemplate')

		if(...) then
			if(type(...) == 'table') then
				for att, val in next, (...) do
					header:SetAttribute(att, val)
				end
			else
				for i = 1, select('#', ...), 2 do
					local att, val = select(i, ...)
					if(not att) then break end
					header:SetAttribute(att, val)
				end
			end
		end

		header.style = style
		header.styleFunction = styleProxy

		-- Expose the header through oUF.headers.
		table.insert(headers, header)

		-- We set it here so layouts can't directly override it.
		header:SetAttribute('initialConfigFunction', initialConfigFunction)
		header:SetAttribute('_initialAttributeNames', '_onenter,_onleave,refreshUnitChange,_onstate-vehicleui')
		header:SetAttribute('_initialAttribute-_onenter', [[
			local snippet = self:GetAttribute('clickcast_onenter')
			if(snippet) then
				self:Run(snippet)
			end
		]])
		header:SetAttribute('_initialAttribute-_onleave', [[
			local snippet = self:GetAttribute('clickcast_onleave')
			if(snippet) then
				self:Run(snippet)
			end
		]])
		header:SetAttribute('_initialAttribute-refreshUnitChange', [[
			local unit = self:GetAttribute('unit')
			if(unit) then
				RegisterStateDriver(self, 'vehicleui', '[@' .. unit .. ',unithasvehicleui]vehicle; novehicle')
			else
				UnregisterStateDriver(self, 'vehicleui')
			end
		]])
		header:SetAttribute('_initialAttribute-_onstate-vehicleui', [[
			local unit = self:GetAttribute('unit')
			if(newstate == 'vehicle' and unit and UnitPlayerOrPetInRaid(unit) and not UnitTargetsVehicleInRaidUI(unit)) then
				self:SetAttribute('toggleForVehicle', false)
			else
				self:SetAttribute('toggleForVehicle', true)
			end
		]])
		header:SetAttribute('oUF-headerType', isPetHeader and 'pet' or 'group')

		if(_G.Clique) then
			SecureHandlerSetFrameRef(header, 'clickcast_header', _G.Clique.header)
		end

		if(header:GetAttribute('showParty')) then
			self:DisableBlizzard('party')
		end

		return header
	end
end

--[[ oUF:Spawn(unit, overrideName)
Used to create a single unit frame and apply the currently active style to it.

* self         - the global oUF object
* unit         - the frame's unit (string)
* overrideName - unique global name to use for the unit frame. Defaults to an auto-generated name based on the unit
                 (string?)

oUF implements some of its own attributes. These can be supplied by the layout, but are optional.
PingableUnitFrameTemplate is inherited for Ping support.

* oUF-enableArenaPrep - can be used to toggle arena prep support. Defaults to true (boolean)
--]]
function oUF:Spawn(unit, overrideName)
	argcheck(unit, 2, 'string')
	if(not style) then return nierror('Unable to create frame. No styles have been registered.') end

	unit = unit:lower()

	local name = overrideName or generateName(unit)
	local object = CreateFrame('Button', name, UIParent, 'SecureUnitButtonTemplate, PingableUnitFrameTemplate')
	Private.UpdateUnits(object, unit)

	if(unit:match('arena%d?')) then
		object:SetRolesets('arenaFrames')
	else
		object:SetRolesets('unitFrames')
	end

	self:DisableBlizzard(unit)
	walkObject(object, unit)

	object:SetAttribute('unit', unit)
	RegisterUnitWatch(object)

	return object
end

do
	local hitInset = 10000 -- some large number that will ensure we have full coverage
	local function updateDriver(driver)
		if(IsLoggedIn()) then
			C_NamePlate.SetNamePlateSize(driver.plateWidth or 200, driver.plateHeight or 30)

			local enemyInset = driver.enemyNonInteractible and hitInset or -hitInset
			C_NamePlateManager.SetNamePlateHitTestInsets(Enum.NamePlateType.Enemy, enemyInset, enemyInset, enemyInset, enemyInset)

			local friendlyInset = driver.friendlyNonInteractible and hitInset or -hitInset
			C_NamePlateManager.SetNamePlateHitTestInsets(Enum.NamePlateType.Friendly, friendlyInset, friendlyInset, friendlyInset, friendlyInset)

			if(driver.cvars) then
				for name, value in next, driver.cvars do
					if(type(value) == 'table') then
						for bitmaskIndex, bitmaskValue in next, value do
							C_CVar.SetCVarBitfield(name, bitmaskIndex, bitmaskValue)
						end
					else
						C_CVar.SetCVar(name, value)
					end
				end
			end
		end
	end

	local nameplateDriverMixin = {}
	--[[ nameplates:SetTargetCallback(callback)
	Sets a callback function to be triggered whenever a nameplate has been targeted.
	The payload for the callback is `(nameplate, event, unit)`.
	--]]
	function nameplateDriverMixin:SetTargetCallback(callback)
		argcheck(callback, 2, 'function', 'nil')
		self.targetCallback = callback
	end

	--[[ nameplates:SetAddedCallback(callback)
	Sets a callback function to be triggered whenever a nameplate has been added.
	The payload for the callback is `(nameplate, event, unit)`.
	--]]
	function nameplateDriverMixin:SetAddedCallback(callback)
		argcheck(callback, 2, 'function', 'nil')
		self.addedCallback = callback
	end

	--[[ nameplates:SetRemovedCallback(callback)
	Sets a callback function to be triggered whenever a nameplate has been removed.
	The payload for the callback is `(nameplate, event, unit)`.
	--]]
	function nameplateDriverMixin:SetRemovedCallback(callback)
		argcheck(callback, 2, 'function', 'nil')
		self.removedCallback = callback
	end

	--[[ nameplates:SetSize(width[, height])
	Sets the width and size for all nameplates.
	If only width is provided it will also be used for the height.
	The default width is `200`, and the default height is `30`.
	--]]
	function nameplateDriverMixin:SetSize(width, height)
		argcheck(width, 2, 'number')
		argcheck(height, 3, 'number', 'nil')

		self.plateWidth = width
		self.plateHeight = height or width

		updateDriver(self)
	end

	--[[ nameplates:SetEnemyInteractible(state)
	Sets the interactible state for enemy nameplates.
	They are interactible by default.
	--]]
	function nameplateDriverMixin:SetEnemyInteractible(state)
		self.enemyNonInteractible = not state

		updateDriver(self)
	end

	--[[ nameplates:SetFriendlyInteractible(state)
	Sets the interactible state for friendly nameplates.
	They are interactible by default.
	--]]
	function nameplateDriverMixin:SetFriendlyInteractible(state)
		self.friendlyNonInteractible = not state

		updateDriver(self)
	end

	--[[ nameplates:SetCVars(variables)
	Sets console variables from key/value table.
	--]]
	--[[ nameplates:SetCVars(name, value[, ...])
	Sets console variables from key/value parameters.
	--]]
	function nameplateDriverMixin:SetCVars(...)
		if(type(...) == 'table') then
			self.cvars = ...
		else
			self.cvars = {}
			for index = 1, select('#', ...), 2 do
				local name, value = select(index, ...)
				if(not name) then break end
				self.cvars[name] = value
			end
		end

		updateDriver(self)
	end

	local function driverEventHandler(self, event, unit)
		if(event == 'PLAYER_LOGIN') then
			updateDriver(self)
		elseif(event == 'PLAYER_TARGET_CHANGED') then
			local nameplate = C_NamePlate.GetNamePlateForUnit('target')
			if(not nameplate or not nameplate.unitFrame) then return end
			if(UnitNameplateShowsWidgetsOnly('target') or UnitIsGameObject('target')) then return end

			if(self.targetCallback) then
				self.targetCallback(nameplate.unitFrame, event, 'target')
			end

			-- UAE is called after the callback to reduce the number of
			-- ForceUpdate calls layouts have to do after changing things
			nameplate.unitFrame:UpdateAllElements(event)
		elseif(event == 'NAME_PLATE_UNIT_ADDED') then
			local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
			if(not nameplate) then return end

			-- we need to disable blizzard's handling on every spawn because they keep
			-- initializing stuff on nameplates
			oUF:DisableBlizzard(unit)

			if(not nameplate.unitFrame) then
				nameplate.style = self.style

				nameplate.unitFrame = CreateFrame('Button', self.prefix .. nameplate:GetName(), nameplate, 'PingableUnitFrameTemplate')
				nameplate.unitFrame:EnableMouse(false)
				nameplate.unitFrame:SetAllPoints()
				nameplate.unitFrame.isNamePlate = true

				Private.UpdateUnits(nameplate.unitFrame, unit)

				walkObject(nameplate.unitFrame, unit)

				-- re-parent other elements directly to the nameplate frame, as there doesn't seem
				-- to be any downsides to be parented there than to the unit frame within,
				-- and this is the easier solution (no need to actively reparent and show/hide
				-- the stock unit frame object)
				nameplate.UnitFrame.WidgetContainer:SetParent(nameplate)
				nameplate.UnitFrame.WidgetContainer:SetPoint('TOP', nameplate, 'BOTTOM')
				nameplate.UnitFrame.SoftTargetFrame:SetParent(nameplate)
			end

			if(UnitNameplateShowsWidgetsOnly(unit) or UnitIsGameObject(unit)) then
				-- pause all active elements and hide the unit frame
				nameplate.unitFrame:PauseAllElements()
				nameplate.unitFrame:Hide()
			else
				-- we need to keep updating the attributes in order to keep correct info,
				-- as this can change during nameplate re-use
				nameplate.unitFrame:SetAttribute('unit', unit)
				Private.UpdateUnits(nameplate.unitFrame, unit)

				nameplate:ClearAllHitTestPoints() -- to prevent lingering hit test points
				nameplate:SetAllHitTestPoints(nameplate.unitFrame)

				if(self.addedCallback) then
					self.addedCallback(nameplate.unitFrame, event, unit)
				end

				-- UAE is called after the callback to reduce the number of
				-- ForceUpdate calls layouts have to do after changing things
				nameplate.unitFrame:UpdateAllElements(event)
			end
		elseif(event == 'NAME_PLATE_UNIT_REMOVED') then
			local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
			if(not nameplate or not nameplate.unitFrame) then return end

			nameplate.unitFrame:SetAttribute('unit', nil)

			-- resume any paused elements and show the unit frame
			nameplate.unitFrame:ResumeAllElements()
			nameplate.unitFrame:Show()

			if(self.removedCallback) then
				self.removedCallback(nameplate.unitFrame, event, unit)
			end
		end
	end

	--[[ oUF:SpawnNamePlates(prefix)
	Used to create nameplates and apply the currently active style to them.

	* self      - the global oUF object
	* prefix    - prefix for the global name of the nameplate. Defaults to an auto-generated prefix (string?)

	PingableUnitFrameTemplate is inherited for Ping support.
	--]]
	function oUF:SpawnNamePlates(namePrefix)
		if(not style) then return nierror('Unable to create frame. No styles have been registered.') end

		local driverName = (global or parent) .. '_NamePlateDriver'
		if(_G[driverName]) then return nierror('oUF nameplate driver has already been initialized.') end

		local nameplateDriver = Mixin(CreateFrame('Frame', driverName), nameplateDriverMixin)
		nameplateDriver:SetScript('OnEvent', driverEventHandler)

		nameplateDriver.style = style
		nameplateDriver.prefix = namePrefix or generateName()

		nameplateDriver:RegisterEvent('NAME_PLATE_UNIT_ADDED')
		nameplateDriver:RegisterEvent('NAME_PLATE_UNIT_REMOVED')
		nameplateDriver:RegisterEvent('PLAYER_TARGET_CHANGED')

		-- we'd prefer to straight up disable blizzard's nameplate driver, but nameplates contain
		-- widgets and soft target icons we can't recreate due to protections, and it handles the
		-- forbidden nameplates, so we can't disable any events without friendly nameplates in
		-- dungeons breaking

		if(IsLoggedIn()) then
			updateDriver(nameplateDriver)
		else
			nameplateDriver:RegisterEvent('PLAYER_LOGIN')
		end

		return nameplateDriver
	end
end

--[[ oUF:AddElement(name, update, enable, disable)
Used to register an element with oUF.

* self    - the global oUF object
* name    - unique name of the element (string)
* update  - used to update the element (function)
* enable  - used to enable the element for a given unit frame and unit (function)
* disable - used to disable the element for a given unit frame (function)
--]]
function oUF:AddElement(name, update, enable, disable)
	argcheck(name, 2, 'string')
	argcheck(update, 3, 'function', 'nil')
	argcheck(enable, 4, 'function')
	argcheck(disable, 5, 'function')

	if(elements[name]) then return nierror(string.format('Element [%s] is already registered.', name)) end
	elements[name] = {
		update = update,
		enable = enable,
		disable = disable,
	}
end

--[[ oUF:AddMetaElement(name, create, update, enable, disable)
Used to register a meta element with oUF.

* self    - the global oUF object
* name    - unique name of the element (string)
* create  - used to create the element. Will be registered as a meta function (function)
* update  - used to update the element (function)
* enable  - used to enable the element for a given unit frame and unit (function)
* disable - used to disable the element for a given unit frame (function)
--]]
function oUF:AddMetaElement(name, create, update, enable, disable)
	argcheck(name, 2, 'string')
	argcheck(create, 3, 'function')
	argcheck(update, 4, 'function', 'nil')
	argcheck(enable, 5, 'function')
	argcheck(disable, 6, 'function')

	if(elements[name]) then return nierror(string.format('Element [%s] is already registered.', name)) end
	elements[name] = {
		update = update,
		enable = enable,
		disable = disable,
	}
	self:RegisterMetaFunction('Create' .. name, create)
end

oUF.version = _VERSION
--[[ oUF.objects
Array containing all unit frames created by `oUF:Spawn`.
--]]
oUF.objects = objects
--[[ oUF.headers
Array containing all group headers created by `oUF:SpawnHeader`.
--]]
oUF.headers = headers

if(global) then
	if(parent ~= 'oUF' and global == 'oUF') then
		nierror(string.format('%s is doing it wrong and setting its global to "oUF".', parent))
	elseif(_G[global]) then
		nierror(string.format('%s is setting its global to an existing name "%s".', parent, global))
	else
		_G[global] = oUF
	end
end
