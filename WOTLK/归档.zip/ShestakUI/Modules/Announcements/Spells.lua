local T, C, L = unpack(ShestakUI)
if C.announcements.spells ~= true then return end

local GetSpellInfo = GetSpellInfo
local cachedDifficultyID = 0

----------------------------------------------------------------------------------------
--	Announce some spells
----------------------------------------------------------------------------------------
local function OnCLEU_Spells()
	local _, combatEvent, _, sourceGUID, sourceName, _, _, _, destName, _, _, spellID = CombatLogGetCurrentEventInfo()
	if cachedDifficultyID == 0 or combatEvent ~= "SPELL_CAST_SUCCESS" then return end

	if sourceName then sourceName = sourceName:gsub("%-[^|]+", "") end
	if destName then destName = destName:gsub("%-[^|]+", "") end

	-- Match by spell ID, or fall back to name-based matching for different spell ranks
	local spellMatched = T.AnnounceSpells[spellID]
	if not spellMatched and T.AnnounceSpellsByName then
		local spellName = GetSpellInfo(spellID)
		if spellName and T.AnnounceSpellsByName[spellName] then
			spellMatched = true
		end
	end

	if C.announcements.spells_from_all == true and not (sourceGUID == UnitGUID("player") and sourceName == T.name) then
		if not sourceName then return end

		if spellMatched then
			if destName == nil then
				SendChatMessage(string.format(L_ANNOUNCE_FP_USE, sourceName, GetSpellLink(spellID)), T.CheckChat())
			else
				SendChatMessage(string.format(L_ANNOUNCE_FP_USE, sourceName, GetSpellLink(spellID).." -> "..destName), T.CheckChat())
			end
		end
	else
		if not (sourceGUID == UnitGUID("player") and sourceName == T.name) then return end

		if spellMatched then
			if destName == nil then
				SendChatMessage(string.format(L_ANNOUNCE_FP_USE, sourceName, GetSpellLink(spellID)), T.CheckChat())
			else
				SendChatMessage(GetSpellLink(spellID).." -> "..destName, T.CheckChat())
			end
		end
	end
end

local spellFrame = CreateFrame("Frame")
spellFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
spellFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
spellFrame:SetScript("OnEvent", function(_, event)
	if event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
		_, _, cachedDifficultyID = GetInstanceInfo()
	end
end)

T.CLEU_Register("SPELL_CAST_SUCCESS", OnCLEU_Spells)