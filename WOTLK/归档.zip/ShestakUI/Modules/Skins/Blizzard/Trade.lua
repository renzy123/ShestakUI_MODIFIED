local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	Trade skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	-- 3.80.1 时光服裁剪版 Trade：整体加 nil 检查，避免子组件缺失导致 skin 崩溃
	if not TradeFrame then return end

	TradeFrame:StripTextures(true)
	if TradeFrameInset then TradeFrameInset:StripTextures() end
	if TradePlayerItemsInset then TradePlayerItemsInset:StripTextures() end
	if TradeRecipientItemsInset then TradeRecipientItemsInset:StripTextures() end
	if TradePlayerEnchantInset then TradePlayerEnchantInset:StripTextures() end
	if TradeRecipientEnchantInset then TradeRecipientEnchantInset:StripTextures() end
	if TradePlayerInputMoneyInset then TradePlayerInputMoneyInset:StripTextures() end
	if TradeRecipientMoneyInset then TradeRecipientMoneyInset:StripTextures() end
	if TradeRecipientMoneyBg then TradeRecipientMoneyBg:StripTextures() end
	if TradeFramePortrait then TradeFramePortrait:SetAlpha(0) end

	if T.Mainline then
		TradeFrame.RecipientOverlay.portrait:SetAlpha(0)
		TradeFrame.RecipientOverlay.portraitFrame:SetAlpha(0)
	end

	TradeFrame:CreateBackdrop("Transparent")
	TradeFrame.backdrop:SetPoint("TOPLEFT", 0, 0)
	TradeFrame.backdrop:SetPoint("BOTTOMRIGHT", 0, 0)
	if TradeFrameTradeButton then TradeFrameTradeButton:SkinButton(true) end
	if TradeFrameCancelButton then TradeFrameCancelButton:SkinButton(true) end
	if TradeFrameCloseButton then T.SkinCloseButton(TradeFrameCloseButton, TradeFrame.backdrop) end

	-- 3.80.1 时光服里 TradePlayerInputMoneyFrameGold/Silver/Copper 是 MoneyInputFrame 子框，
	-- 其 GetRegions() 行为与普通 EditBox 不同；SkinEditBox 内部已用 pcall 保护。
	-- 这里再加 nil 守卫，避免 frame 不存在时直接崩。
	if TradePlayerInputMoneyFrameGold then T.SkinEditBox(TradePlayerInputMoneyFrameGold) end
	if TradePlayerInputMoneyFrameSilver then T.SkinEditBox(TradePlayerInputMoneyFrameSilver) end
	if TradePlayerInputMoneyFrameCopper then T.SkinEditBox(TradePlayerInputMoneyFrameCopper) end

	for i = 1, MAX_TRADE_ITEMS do
		local player = _G["TradePlayerItem"..i]
		local recipient = _G["TradeRecipientItem"..i]
		local player_button = _G["TradePlayerItem"..i.."ItemButton"]
		local recipient_button = _G["TradeRecipientItem"..i.."ItemButton"]
		local player_button_icon = _G["TradePlayerItem"..i.."ItemButtonIconTexture"]
		local recipient_button_icon = _G["TradeRecipientItem"..i.."ItemButtonIconTexture"]
		local player_button_count = _G["TradePlayerItem"..i.."ItemButtonCount"]
		local recipient_button_count = _G["TradeRecipientItem"..i.."ItemButtonCount"]

		if player_button and recipient_button then
			if player then player:StripTextures() end
			if recipient then recipient:StripTextures() end
			player_button:StripTextures()
			recipient_button:StripTextures()

			if player_button.IconBorder then player_button.IconBorder:SetAlpha(0) end
			if recipient_button.IconBorder then recipient_button.IconBorder:SetAlpha(0) end

			if player_button_icon then
				player_button_icon:ClearAllPoints()
				player_button_icon:SetPoint("TOPLEFT", player_button, "TOPLEFT", 2, -2)
				player_button_icon:SetPoint("BOTTOMRIGHT", player_button, "BOTTOMRIGHT", -2, 2)
				player_button_icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				player_button_icon:SetDrawLayer("OVERLAY")
			end

			if player_button_count then player_button_count:SetDrawLayer("OVERLAY") end

			player_button:SetTemplate("Overlay")
			player_button:StyleButton()

			local playerNameFrame = _G["TradePlayerItem"..i.."NameFrame"]
			if playerNameFrame then
				player_button.bg = CreateFrame("Frame", nil, player_button)
				player_button.bg:SetTemplate("Overlay")
				player_button.bg:SetPoint("TOPLEFT", player_button, "TOPRIGHT", 4, 0)
				player_button.bg:SetPoint("BOTTOMRIGHT", playerNameFrame, "BOTTOMRIGHT", 0, 14)
				player_button.bg:SetFrameLevel(player_button:GetFrameLevel() - 4)
			end

			if recipient_button_icon then
				recipient_button_icon:ClearAllPoints()
				recipient_button_icon:SetPoint("TOPLEFT", recipient_button, "TOPLEFT", 2, -2)
				recipient_button_icon:SetPoint("BOTTOMRIGHT", recipient_button, "BOTTOMRIGHT", -2, 2)
				recipient_button_icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
				recipient_button_icon:SetDrawLayer("OVERLAY")
			end

			if recipient_button_count then recipient_button_count:SetDrawLayer("OVERLAY") end

			recipient_button:SetTemplate("Overlay")
			recipient_button:StyleButton()

			local recipientNameFrame = _G["TradeRecipientItem"..i.."NameFrame"]
			if recipientNameFrame then
				recipient_button.bg = CreateFrame("Frame", nil, recipient_button)
				recipient_button.bg:SetTemplate("Overlay")
				recipient_button.bg:SetPoint("TOPLEFT", recipient_button, "TOPRIGHT", 4, 0)
				recipient_button.bg:SetPoint("BOTTOMRIGHT", recipientNameFrame, "BOTTOMRIGHT", 0, 14)
				recipient_button.bg:SetFrameLevel(recipient_button:GetFrameLevel() - 4)
			end
		end
	end

	-- 3.80.1 时光服 Highlight 系列 frame 可能被裁剪，逐个 nil 检查
	if TradeHighlightPlayerTop then TradeHighlightPlayerTop:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightPlayerBottom then TradeHighlightPlayerBottom:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightPlayerMiddle then TradeHighlightPlayerMiddle:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightPlayer then
		TradeHighlightPlayer:SetFrameStrata("HIGH")
		TradeHighlightPlayer:SetPoint("TOPLEFT", TradeFrame, "TOPLEFT", 11, -86)
	end

	if TradeHighlightPlayerEnchantTop then TradeHighlightPlayerEnchantTop:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightPlayerEnchantBottom then TradeHighlightPlayerEnchantBottom:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightPlayerEnchantMiddle then TradeHighlightPlayerEnchantMiddle:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightPlayerEnchant then TradeHighlightPlayerEnchant:SetFrameStrata("HIGH") end

	if TradeHighlightRecipientTop then TradeHighlightRecipientTop:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightRecipientBottom then TradeHighlightRecipientBottom:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightRecipientMiddle then TradeHighlightRecipientMiddle:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightRecipient then
		TradeHighlightRecipient:SetFrameStrata("HIGH")
		TradeHighlightRecipient:SetPoint("TOPLEFT", TradeFrame, "TOPLEFT", 179, -86)
	end

	if TradeHighlightRecipientEnchantTop then TradeHighlightRecipientEnchantTop:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightRecipientEnchantBottom then TradeHighlightRecipientEnchantBottom:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightRecipientEnchantMiddle then TradeHighlightRecipientEnchantMiddle:SetColorTexture(0, 1, 0, 0.2) end
	if TradeHighlightRecipientEnchant then TradeHighlightRecipientEnchant:SetFrameStrata("HIGH") end
end

tinsert(T.SkinFuncs["ShestakUI"], LoadSkin)
