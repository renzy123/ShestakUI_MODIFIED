local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	CLEUDispatcher.lua（Reforged 版本）
--	原独立的 CLEU dispatcher 已被 Core\Events.lua 统一事件总线接管。
--	T.CLEU_Register(subEvent, func)
--	T.CLEU_RegisterFull(func)
--	T.CLEU_Unregister(subEvent, func)
--	T.CLEU_UnregisterFull(func)
--	全部由 Core\Events.lua 提供，行为与原版兼容，且：
--	  1) CLEU 在 host frame 上只注册一次（不再有独立 dispatcher frame）
--	  2) CombatLogGetCurrentEventInfo() 在 host OnEvent 内只调用一次，参数下发给所有订阅者
--	  3) 同一 subEvent 下相同 func 自动去重（基于 set）
--	本文件保留作占位，便于后续如果需要 dispatcher 特殊语义可在此扩展。
--	被替换为独立注册的模块（CombatText / DiminishingCD）将通过 T.CLEU_RegisterFull 或
--	T.CLEU_Register 迁移到统一总线，详见各自文件的注释。
----------------------------------------------------------------------------------------
