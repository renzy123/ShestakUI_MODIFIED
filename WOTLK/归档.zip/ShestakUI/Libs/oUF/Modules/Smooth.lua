local T, C, L = unpack(ShestakUI)
if C.unitframe.enable ~= true or C.unitframe.plugins_smooth_bar ~= true then return end

----------------------------------------------------------------------------------------
--	Based on oUF_Smooth(by Xuerian)
--	ShestakUI_Reforged: 惰性启动 + 无任务停帧，避免常驻 OnUpdate 每帧空跑
----------------------------------------------------------------------------------------
local _, ns = ...
local oUF = ns.oUF

local smoothing = {}
local f, min, max = CreateFrame("Frame"), math.min, math.max
local smoothRate = 60
local smoothElapsed = 0

local onSmoothUpdate  -- 前向声明，供 Smooth 函数引用

local function Smooth(self, value)
	if value ~= self:GetValue() or value == 0 then
		smoothing[self] = value
		-- 有 smoothing 任务时才启动 OnUpdate（惰性启动）
		f:SetScript("OnUpdate", onSmoothUpdate)
	else
		smoothing[self] = nil
	end
end

local function SmoothBar(_, bar)
	bar.SetValue_ = bar.SetValue
	bar.SetValue = Smooth
end

local function hook(frame)
	frame.SmoothBar = SmoothBar
	if frame.Health and frame.Health.Smooth then
		frame:SmoothBar(frame.Health)
	end
	if frame.Power and frame.Power.Smooth then
		frame:SmoothBar(frame.Power)
	end
end

for _, frame in ipairs(oUF.objects) do hook(frame) end
oUF:RegisterInitCallback(hook)

onSmoothUpdate = function(_, elapsed)
	smoothElapsed = smoothElapsed + (elapsed or 0)
	if smoothElapsed > 0.5 then
		smoothRate = GetFramerate()
		if smoothRate < 1 then smoothRate = 1 end
		smoothElapsed = 0
	end
	local limit = 30 / smoothRate
	for bar, value in pairs(smoothing) do
		local cur = bar:GetValue()
		local new = cur + min((value - cur) / 3, max(value - cur, limit))
		if new ~= new then
			-- Mad hax to prevent QNAN.
			new = value
		end
		bar:SetValue_(new)
		if cur == value or abs(new - value) < 2 then
			bar:SetValue_(value)
			smoothing[bar] = nil
		end
	end
	-- 无 smoothing 条时彻底停帧，避免常驻 OnUpdate 每帧空跑
	if not next(smoothing) then
		f:SetScript("OnUpdate", nil)
	end
end
