local T, C, L = unpack(ShestakUI)
if C.minimap.enable ~= true then return end

----------------------------------------------------------------------------------------
--	Farm mode for minimap(by Elv22)
----------------------------------------------------------------------------------------
T.FarmMode = false
SlashCmdList.FARMMODE = function()
	if InCombatLockdown() then print("|cffffff00"..ERR_NOT_IN_COMBAT.."|r") return end
	if T.FarmMode == false then
		MinimapAnchor:SetSize(C.minimap.size * 1.65, C.minimap.size * 1.65)
		Minimap:SetSize(MinimapAnchor:GetWidth(), MinimapAnchor:GetWidth())
		T.FarmMode = true
	else
		MinimapAnchor:SetSize(C.minimap.size, C.minimap.size)
		Minimap:SetSize(MinimapAnchor:GetWidth(), MinimapAnchor:GetWidth())
		T.FarmMode = false
	end
end
SLASH_FARMMODE1 = "/farmmode"
SLASH_FARMMODE2 = "/афкььщву"
SLASH_FARMMODE3 = "/fm"
SLASH_FARMMODE4 = "/аь"

----------------------------------------------------------------------------------------
--	Farm mode mouseover button(by m2jest1c)
----------------------------------------------------------------------------------------
local farm = CreateFrame("Button", "FarmMode", UIParent)
farm:SetTemplate("ClassColor")
if C.actionbar.toggle_mode == true then
	farm:SetPoint("TOPLEFT", Minimap, "TOPRIGHT", 3, -18)
else
	farm:SetPoint("TOPLEFT", Minimap, "TOPRIGHT", 3, 2)
end
farm:SetSize(19, 19)
farm:SetAlpha(0)

farm.t = farm:CreateTexture(nil, "OVERLAY")
farm.t:SetTexture("Interface\\Icons\\inv_misc_map_01")
farm.t:SetTexCoord(0.1, 0.9, 0.1, 0.9)
farm.t:SetPoint("TOPLEFT", farm, 2, -2)
farm.t:SetPoint("BOTTOMRIGHT", farm, -2, 2)

farm:SetScript("OnClick", function()
	SlashCmdList.FARMMODE()
end)

farm:SetScript("OnEnter", function()
	farm:FadeIn()
	GameTooltip:SetOwner(farm, "ANCHOR_LEFT")
	GameTooltip:AddLine(L_MINIMAP_FARM, 0.40, 0.78, 1)
	GameTooltip:Show()
end)

farm:SetScript("OnLeave", function()
	farm:FadeOut()
	GameTooltip:Hide()
end)