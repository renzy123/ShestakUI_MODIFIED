local T, C, L = unpack(ShestakUI)
if C.unitframe.enable ~= true or C.unitframe.show_arena ~= true then return end

----------------------------------------------------------------------------------------
--	Based on oUF_Trinkets(by Allez, editor Tukz)
----------------------------------------------------------------------------------------
local _, ns = ...
local oUF = ns.oUF or oUF
assert(oUF, 'oUF not loaded')

local GetTrinketIcon = function(unit)
	if UnitFactionGroup(unit) == "Horde" then
		return "Interface\\Icons\\INV_Jewelry_TrinketPVP_02"
	else
		return "Interface\\Icons\\INV_Jewelry_TrinketPVP_01"
	end
end

local Update = function(self, event, ...)
	local _, instanceType = IsInInstance()

	if instanceType ~= 'arena' then
		if(oUF:IsMainline()) then
			self.Trinket.Icon:SetTexture("Interface\\Icons\\Ability_pvp_gladiatormedallion")
		end
		self.Trinket:Hide()

		return
	else
		self.Trinket:Show()
	end

	if(self.Trinket.PreUpdate) then self.Trinket:PreUpdate(event, ...) end

	if event == "ARENA_COOLDOWNS_UPDATE" then
		local unit = ...

		if self.unit == unit then
			-- 3.80.2: C_PvP methods may not exist
			if C_PvP and C_PvP.RequestCrowdControlSpell then
				C_PvP.RequestCrowdControlSpell(unit)
			end

			local spellID, startTime, duration
			if C_PvP and C_PvP.GetArenaCrowdControlInfo then
				spellID, startTime, duration = C_PvP.GetArenaCrowdControlInfo(unit)
			end

			if spellID and startTime ~= 0 and duration ~= 0 then
				CooldownFrame_Set(self.Trinket.cooldownFrame, startTime / 1000, duration / 1000, 1)
			end
		end
	elseif event == "ARENA_CROWD_CONTROL_SPELL_UPDATE" then
		local unit, spellID = ...

		if self.unit == unit then
			local _, _, spellTexture = GetSpellInfo(spellID)

			self.Trinket.Icon:SetTexture(spellTexture)
		end
	elseif event == "PLAYER_ENTERING_WORLD" then
		CooldownFrame_Set(self.Trinket.cooldownFrame, 1, 1, 1)
	end

	if(self.Trinket.PostUpdate) then self.Trinket:PostUpdate(event, ...) end
end

local Enable = function(self)
	if self.Trinket then
		self:RegisterEvent("ARENA_COOLDOWNS_UPDATE", Update, true)
		self:RegisterEvent("ARENA_CROWD_CONTROL_SPELL_UPDATE", Update, true)
		self:RegisterEvent("PLAYER_ENTERING_WORLD", Update, true)

		if not self.Trinket.cooldownFrame then
			self.Trinket.cooldownFrame = CreateFrame("Cooldown", nil, self.Trinket, "CooldownFrameTemplate")
			self.Trinket.cooldownFrame:SetPoint("TOPLEFT", self.Trinket, 2, -2)
			self.Trinket.cooldownFrame:SetPoint("BOTTOMRIGHT", self.Trinket, -2, 2)
		end

		if not self.Trinket.Icon then
			self.Trinket.Icon = self.Trinket:CreateTexture(nil, "BORDER")
			self.Trinket.Icon:SetPoint("TOPLEFT", self.Trinket, 2, -2)
			self.Trinket.Icon:SetPoint("BOTTOMRIGHT", self.Trinket, -2, 2)
			self.Trinket.Icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
			self.Trinket.Icon:SetTexture(oUF:IsClassic() and GetTrinketIcon("player") or  "Interface\\Icons\\Ability_pvp_gladiatormedallion")
		end

		return true
	end
end

local Disable = function(self)
	if self.Trinket then
		self:UnregisterEvent("ARENA_COOLDOWNS_UPDATE", Update)
		self:UnregisterEvent("ARENA_CROWD_CONTROL_SPELL_UPDATE", Update)
		self:UnregisterEvent("PLAYER_ENTERING_WORLD", Update)
		self.Trinket:Hide()
	end
end

oUF:AddElement('Trinket', Update, Enable, Disable)