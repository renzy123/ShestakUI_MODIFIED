-------------------------------------------------------------------------------
--  EllesmereUI_ShestakSkin - Core/Options.lua
--  ShestakUI 极简像素风独立设置面板 (GUI 窗口与系统设置注册)
-------------------------------------------------------------------------------
local ADDON_NAME, ns = ...
local SK = ns.SK

-- 设置面板主框体引用
local optionsFrame = nil

-- 创建轻量级像素复选框组件
local function CreatePixelCheckbox(parent, labelText, tooltipText, onClick)
    local cb = CreateFrame("CheckButton", nil, parent)
    cb:SetSize(18, 18)

    -- 明确深色底板与 1px 黑色像素边框
    local bg = cb:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetAllPoints(cb)
    bg:SetColorTexture(0.12, 0.12, 0.12, 1)
    SK:CreatePixelBorder(cb)

    -- 勾选状态纹理 (亮青色高对比方块)
    local check = cb:CreateTexture(nil, "ARTWORK")
    check:SetColorTexture(0, 0.85, 1, 1)
    check:SetPoint("TOPLEFT", cb, "TOPLEFT", 3, -3)
    check:SetPoint("BOTTOMRIGHT", cb, "BOTTOMRIGHT", -3, 3)
    cb:SetCheckedTexture(check)

    -- 高亮悬停状态纹理
    local highlight = cb:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetColorTexture(1, 1, 1, 0.2)
    highlight:SetAllPoints(cb)

    -- 文本标签
    local text = cb:CreateFontString(nil, "OVERLAY")
    text:SetFont(SK.Font, 12, "OUTLINE")
    text:SetPoint("LEFT", cb, "RIGHT", 8, 0)
    text:SetText(labelText)
    cb.Text = text

    -- 提示信息
    if tooltipText then
        cb:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(labelText, 1, 1, 1)
            GameTooltip:AddLine(tooltipText, 0.8, 0.8, 0.8, true)
            GameTooltip:Show()
        end)
        cb:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
    end

    cb:SetScript("OnClick", function(self)
        local isChecked = self:GetChecked()
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
        if onClick then
            onClick(isChecked)
        end
    end)

    return cb
end

-- 创建轻量级像素滑块组件
local function CreatePixelSlider(parent, labelText, minVal, maxVal, step, getValue, onChange)
    local container = CreateFrame("Frame", nil, parent)
    container:SetSize(240, 36)

    local title = container:CreateFontString(nil, "OVERLAY")
    title:SetFont(SK.Font, 12, "OUTLINE")
    title:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 0)
    title:SetText(labelText)

    local valText = container:CreateFontString(nil, "OVERLAY")
    valText:SetFont(SK.Font, 12, "OUTLINE")
    valText:SetPoint("TOPRIGHT", container, "TOPRIGHT", 0, 0)
    valText:SetTextColor(0, 1, 1, 1)

    local slider = CreateFrame("Slider", nil, container)
    slider:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    slider:SetPoint("TOPRIGHT", valText, "BOTTOMRIGHT", 0, -6)
    slider:SetHeight(10)
    slider:SetOrientation("HORIZONTAL")
    slider:SetMinMaxValues(minVal, maxVal)
    slider:SetValueStep(step)
    slider:SetObeyStepOnDrag(true)

    -- 滑槽背景与 1px 像素边框
    local sBg = slider:CreateTexture(nil, "BACKGROUND", nil, -7)
    sBg:SetAllPoints(slider)
    sBg:SetColorTexture(0.12, 0.12, 0.12, 1)
    SK:CreatePixelBorder(slider)

    -- 拇指滑块 (亮青色小块)
    local thumb = slider:CreateTexture(nil, "OVERLAY")
    thumb:SetColorTexture(0, 0.85, 1, 1)
    thumb:SetSize(10, 14)
    slider:SetThumbTexture(thumb)

    local function FormatVal(val)
        if step < 1 then
            return string.format("%.2f", val)
        else
            return string.format("%d", math.floor(val + 0.5))
        end
    end

    local cur = getValue() or minVal
    slider:SetValue(cur)
    valText:SetText(FormatVal(cur))

    slider:SetScript("OnValueChanged", function(self, val)
        valText:SetText(FormatVal(val))
        if onChange then
            onChange(val)
        end
    end)

    container.slider = slider
    container.valText = valText
    return container
end

-- 创建通用极简像素按钮
local function CreatePixelButton(parent, label, width, height, onClick)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width or 100, height or 24)

    local bg = btn:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetAllPoints(btn)
    bg:SetColorTexture(0.18, 0.18, 0.18, 1)

    SK:CreatePixelBorder(btn)

    local txt = btn:CreateFontString(nil, "OVERLAY")
    txt:SetFont(SK.Font, 12, "OUTLINE")
    txt:SetPoint("CENTER", btn, "CENTER", 0, 0)
    txt:SetText(label)
    btn.Text = txt

    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints(btn)
    hl:SetColorTexture(1, 1, 1, 0.2)

    btn:SetScript("OnEnter", function()
        bg:SetColorTexture(0.28, 0.28, 0.28, 1)
        txt:SetTextColor(0, 1, 1, 1)
    end)
    btn:SetScript("OnLeave", function()
        bg:SetColorTexture(0.18, 0.18, 0.18, 1)
        txt:SetTextColor(1, 1, 1, 1)
    end)
    btn:SetScript("OnClick", function()
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
        if onClick then onClick() end
    end)

    return btn
end

-- 构建独立设置主面板
local function BuildOptionsPanel()
    if optionsFrame then return optionsFrame end

    local f = CreateFrame("Frame", "EllesmereUI_ShestakSkinOptionsFrame", UIParent)
    f:SetSize(620, 520)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(100)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)

    -- 经典纯黑半透明高对比度实心底板 (保证 100% 呈现黑色面板)
    local mainBg = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    mainBg:SetAllPoints(f)
    mainBg:SetColorTexture(0.06, 0.06, 0.06, 0.95)

    -- 挂载 1px 黑色像素边框
    SK:CreatePixelBorder(f)

    -- 顶部标题栏
    local header = CreateFrame("Frame", nil, f)
    header:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
    header:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    header:SetHeight(28)

    local hBg = header:CreateTexture(nil, "BACKGROUND", nil, -5)
    hBg:SetAllPoints(header)
    hBg:SetColorTexture(0.12, 0.12, 0.12, 1)

    local hBorder = header:CreateTexture(nil, "OVERLAY", nil, 7)
    hBorder:SetColorTexture(SK.BorderColor[1], SK.BorderColor[2], SK.BorderColor[3], 1)
    hBorder:SetPoint("BOTTOMLEFT", header, "BOTTOMLEFT", 0, 0)
    hBorder:SetPoint("BOTTOMRIGHT", header, "BOTTOMRIGHT", 0, 0)
    hBorder:SetHeight(1)

    local title = header:CreateFontString(nil, "OVERLAY")
    title:SetFont(SK.Font, 13, "OUTLINE")
    title:SetPoint("LEFT", header, "LEFT", 10, 0)
    title:SetText("|cff00ffffEllesmereUI|r ShestakSkin 极简美化设置")

    -- 顶部关闭按钮 [X]
    local closeBtn = CreateFrame("Button", nil, header)
    closeBtn:SetSize(18, 18)
    closeBtn:SetPoint("RIGHT", header, "RIGHT", -6, 0)
    local closeTxt = closeBtn:CreateFontString(nil, "OVERLAY")
    closeTxt:SetFont(SK.Font, 12, "OUTLINE")
    closeTxt:SetPoint("CENTER", closeBtn, "CENTER", 0, 0)
    closeTxt:SetText("|cffff5555X|r")
    closeBtn:SetScript("OnEnter", function() closeTxt:SetTextColor(1, 0.2, 0.2, 1) end)
    closeBtn:SetScript("OnLeave", function() closeTxt:SetTextColor(0.8, 0.8, 0.8, 1) end)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    -- 滚动内容区域
    local scrollFrame = CreateFrame("ScrollFrame", nil, f)
    scrollFrame:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 12, -8)
    scrollFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -12, 42)

    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(596, 560)
    scrollFrame:SetScrollChild(content)

    -- 创建区块标题辅助函数
    local function CreateSectionHeader(parent, text, yPos)
        local sec = parent:CreateFontString(nil, "OVERLAY")
        sec:SetFont(SK.Font, 13, "OUTLINE")
        sec:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, yPos)
        sec:SetTextColor(0, 1, 1, 1)
        sec:SetText(text)

        local line = parent:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(0.25, 0.25, 0.25, 1)
        line:SetPoint("TOPLEFT", sec, "BOTTOMLEFT", 0, -3)
        line:SetSize(580, 1)

        return sec
    end


    local curY = -6

    -- 1. 全局与核心材质
    CreateSectionHeader(content, "全局核心与材质风格 (Core & Media)", curY)
    curY = curY - 26

    local cbEnable = CreatePixelCheckbox(content, "启用 ShestakSkin 总开关", "开启或关闭整个 Shestak 极简皮肤系统", function(val)
        SK.db.enable = val
        SK:Log("ShestakSkin 总开关变更为: %s", tostring(val))
    end)
    cbEnable:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)
    cbEnable:SetChecked(SK.db.enable)

    local cbTex = CreatePixelCheckbox(content, "全局强制 Flat 纯平状态条材质", "接管 EllesmereUI 状态条材质解析器，使所有生命条/能量条使用 Shestak Flat 纯平材质", function(val)
        SK.db.general.texture = val
    end)
    cbTex:SetPoint("TOPLEFT", content, "TOPLEFT", 260, curY)
    cbTex:SetChecked(SK.db.general.texture)
    curY = curY - 34

    -- 2. 玩家与目标头像 (UnitFrames)
    CreateSectionHeader(content, "玩家与目标头像美化 (UnitFrames)", curY)
    curY = curY - 26

    local cbUF = CreatePixelCheckbox(content, "启用头像 Shestak 样式", "启用 4px 能量条、外侧大号百分比、条内生命值/等级以及 1px 黑色硬边框", function(val)
        SK.db.unitframes.enable = val
        if SK.SkinAllUnitFrames then SK:SkinAllUnitFrames() end
    end)
    cbUF:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)
    cbUF:SetChecked(SK.db.unitframes.enable)
    curY = curY - 28

    local sliderAlpha = CreatePixelSlider(content, "2D 肖像半透明度", 0.1, 1.0, 0.05, function()
        return SK.db.unitframes.portraitAlpha or 0.35
    end, function(val)
        SK.db.unitframes.portraitAlpha = val
        if SK.SkinAllUnitFrames then SK:SkinAllUnitFrames() end
    end)
    sliderAlpha:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)

    local sliderPerc = CreatePixelSlider(content, "外侧百分比字号", 14, 32, 1, function()
        return SK.db.unitframes.percentFontSize or 22
    end, function(val)
        SK.db.unitframes.percentFontSize = math.floor(val)
        if SK.SkinAllUnitFrames then SK:SkinAllUnitFrames() end
    end)
    sliderPerc:SetPoint("TOPLEFT", content, "TOPLEFT", 280, curY)
    curY = curY - 48

    -- 3. 动作条与技能按钮 (ActionBars)
    CreateSectionHeader(content, "动作条与光环模块美化 (ActionBars & Auras)", curY)
    curY = curY - 26

    local cbAB = CreatePixelCheckbox(content, "动作条 1px 像素边框与裁切", "去除动作条浮雕边框，启用 0.1~0.9 紧凑裁切与纯黑 1px 像素边框", function(val)
        SK.db.actionbars.enable = val
        if SK.SkinActionBars then SK:SkinActionBars() end
    end)
    cbAB:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)
    cbAB:SetChecked(SK.db.actionbars.enable)

    local cbAura = CreatePixelCheckbox(content, "BUFF/DEBUFF 光环像素美化", "启用玩家增益/减益 1px 黑色边框、正方形裁切、Shestak 紧凑倒计时排版与减益染色", function(val)
        if not SK.db.auras then SK.db.auras = {} end
        SK.db.auras.enable = val
        if SK.SkinAuras then SK:SkinAuras() end
    end)
    cbAura:SetPoint("TOPLEFT", content, "TOPLEFT", 280, curY)
    cbAura:SetChecked(SK.db.auras and SK.db.auras.enable ~= false)
    curY = curY - 34

    -- 4. 姓名板美化 (Nameplates)
    CreateSectionHeader(content, "姓名板模块美化 (Nameplates)", curY)
    curY = curY - 26

    local cbNP = CreatePixelCheckbox(content, "启用姓名板纯平材质与 1px 边框", "美化敌方与友方姓名板生命条、施法条与光环图标", function(val)
        SK.db.nameplates.enable = val
        if SK.SkinNameplates then SK:SkinNameplates() end
    end)
    cbNP:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)
    cbNP:SetChecked(SK.db.nameplates.enable)
    curY = curY - 34

    -- 5. 伤害统计美化 (DamageMeters)
    CreateSectionHeader(content, "伤害统计模块美化 (DamageMeters)", curY)
    curY = curY - 26

    local cbDM = CreatePixelCheckbox(content, "启用伤害统计 1px 边框与平滑材质", "为 EllesmereUIDamageMeters 窗口及行池应用 1px 像素边框、平滑状态条与暗色底槽", function(val)
        SK.db.damagemeters.enable = val
        if SK.ApplyDamageMetersSkin then SK:ApplyDamageMetersSkin() end
    end)
    cbDM:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)
    cbDM:SetChecked(SK.db.damagemeters.enable)

    local cbDMHeader = CreatePixelCheckbox(content, "紧凑标题栏 (10px 文本 / 12px 图标)", "调整标题栏尺寸以契合极简像素排版，维持 2px 垂直间距", function(val)
        SK.db.damagemeters.compactHeader = val
        if SK.ApplyDamageMetersSkin then SK:ApplyDamageMetersSkin() end
    end)
    cbDMHeader:SetPoint("TOPLEFT", content, "TOPLEFT", 280, curY)
    cbDMHeader:SetChecked(SK.db.damagemeters.compactHeader ~= false)
    curY = curY - 34

    -- 6. 其他常用界面 (More Modules)
    CreateSectionHeader(content, "其他常用模块 (Other Modules)", curY)
    curY = curY - 26

    local cbMap = CreatePixelCheckbox(content, "小地图 1px 像素边框", "去除小地图圆弧外框，挂载 1px 黑色像素边框", function(val)
        SK.db.minimap.enable = val
        if SK.SkinMinimap then SK:SkinMinimap() end
    end)
    cbMap:SetPoint("TOPLEFT", content, "TOPLEFT", 10, curY)
    cbMap:SetChecked(SK.db.minimap.enable)

    local cbChat = CreatePixelCheckbox(content, "聊天输入框 1px 像素边框", "保留聊天框主体透明无遮罩，为输入框挂载 1px 黑色像素边框与暗色半透明底色", function(val)
        SK.db.chat.enable = val
        if SK.SkinChat then SK:SkinChat() end
    end)
    cbChat:SetPoint("TOPLEFT", content, "TOPLEFT", 200, curY)
    cbChat:SetChecked(SK.db.chat.enable)

    local cbBlizz = CreatePixelCheckbox(content, "暴雪系统常用框体边框", "为角色面板、法术书、好友等原生框体挂载 1px 边框", function(val)
        SK.db.blizzard.enable = val
        if SK.SkinBlizzard then SK:SkinBlizzard() end
    end)
    cbBlizz:SetPoint("TOPLEFT", content, "TOPLEFT", 390, curY)
    cbBlizz:SetChecked(SK.db.blizzard.enable)
    curY = curY - 40

    -- 底部功能按钮条
    local bottomBar = CreateFrame("Frame", nil, f)
    bottomBar:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 12, 10)
    bottomBar:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -12, 10)
    bottomBar:SetHeight(30)

    -- 全局扫描按钮
    local btnScan = CreatePixelButton(bottomBar, "立即扫描美化", 110, 24, function()
        SK:ScanAll()
    end)
    btnScan:SetPoint("LEFT", bottomBar, "LEFT", 0, 0)

    -- 恢复默认按钮
    local btnReset = CreatePixelButton(bottomBar, "恢复默认设置", 110, 24, function()
        _G.EllesmereUI_ShestakSkinDB = nil
        SK:InitDB()
        f:Hide()
        print("|cff00ffff[ShestakSkin]|r 配置已重置为默认值，正在重载界面...")
        C_UI.Reload()
    end)
    btnReset:SetPoint("LEFT", btnScan, "RIGHT", 10, 0)

    -- 重新加载界面按钮
    local btnReload = CreatePixelButton(bottomBar, "重新加载界面 (/reload)", 150, 24, function()
        C_UI.Reload()
    end)
    btnReload:SetPoint("RIGHT", bottomBar, "RIGHT", 0, 0)
    btnReload.Text:SetTextColor(0, 1, 0, 1)

    optionsFrame = f
    return optionsFrame
end

-- 打开或切换设置面板显示
function SK:ToggleOptions()
    local panel = BuildOptionsPanel()
    if panel:IsShown() then
        panel:Hide()
    else
        panel:Show()
    end
end

function SK:OpenOptions()
    local panel = BuildOptionsPanel()
    panel:Show()
end

-- 注册到暴雪系统设置 (Game Menu -> Options -> AddOns)
local function RegisterBlizzardCategory()
    local canvas = CreateFrame("Frame", nil, UIParent)
    canvas.name = "EllesmereUI ShestakSkin"

    local cTitle = canvas:CreateFontString(nil, "OVERLAY")
    cTitle:SetFont(SK.Font, 16, "OUTLINE")
    cTitle:SetPoint("TOPLEFT", canvas, "TOPLEFT", 16, -16)
    cTitle:SetText("|cff00ffffEllesmereUI|r ShestakSkin 美化子插件")

    local cDesc = canvas:CreateFontString(nil, "OVERLAY")
    cDesc:SetFont(SK.Font, 12, "OUTLINE")
    cDesc:SetPoint("TOPLEFT", cTitle, "BOTTOMLEFT", 0, -8)
    cDesc:SetText("包含玩家与目标头像、纯平 Flat 材质、1px 像素边框、动作条、姓名板与伤害统计等美化。\n点击下方按钮呼出独立设置面板，或在聊天框输入 /sskin 快捷呼出。")

    local cBtn = CreatePixelButton(canvas, "打开独立设置面板", 150, 28, function()
        if SettingsPanel and SettingsPanel:IsShown() then
            SettingsPanel:Hide()
        end
        SK:OpenOptions()
    end)
    cBtn:SetPoint("TOPLEFT", cDesc, "BOTTOMLEFT", 0, -16)

    -- 现代 10.0+ Settings API 注册
    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        local category = Settings.RegisterCanvasLayoutCategory(canvas, canvas.name)
        Settings.RegisterAddOnCategory(category)
        SK:Log("已注册设置分类至现代 Settings API")
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(canvas)
        SK:Log("已注册设置分类至传统 InterfaceOptions API")
    end
end

local optWatcher = CreateFrame("Frame")
optWatcher:RegisterEvent("PLAYER_LOGIN")
optWatcher:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    RegisterBlizzardCategory()
end)
