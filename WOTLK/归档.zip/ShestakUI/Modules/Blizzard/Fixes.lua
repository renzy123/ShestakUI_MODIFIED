local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	GameMenuButtonSettingsUI anchoring is now handled by AddButton API
--	in ShestakUI_Config (3.80.1+). No more manual anchor fixes needed.
----------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------
--	Hide 3.80.1 时光服 Retail-style micro buttons
--	Core.lua handles action bar frames (MainMenuBar HideOption, MultiBar DisableScripts,
--	PetBar/StanceBar SetParent HiddenFrame, DisableDefaultBarEvents, KillEditMode).
--	This handles micro buttons that need separate treatment.
----------------------------------------------------------------------------------------
if T.Classic and T.NewClassicUI then
	-- Move micro buttons into HiddenFrame (credit: NDui approach)
	-- Micro buttons don't host action bar buttons, so SetParent(HiddenFrame) is safe.
	-- Hook SetParent to prevent Blizzard's EditMode/LayoutManager from reparenting them back.
	-- NOTE: When micromenu is enabled, MicroMenu.lua takes ownership of micro buttons
	-- (SetParent to MicroAnchor + bu.SetParent = T.dummy), so we skip the hook in that case.
	local microButtons = {
		"CharacterMicroButton", "SpellbookMicroButton", "TalentMicroButton",
		"AchievementMicroButton", "QuestLogMicroButton", "GuildMicroButton",
		"LFDMicroButton", "CollectionsMicroButton", "EJMicroButton",
		"StoreMicroButton", "MainMenuMicroButton", "HelpMicroButton"
	}

	local function ResetMicroButtonParent(button, parent)
		-- Allow reparenting to HiddenFrame, MicroAnchor, or MicroMenu wrapper frames
		if parent == T.HiddenFrame then return end
		if _G.MicroAnchor and parent == _G.MicroAnchor then return end
		-- Allow reparenting to MicroMenu wrapper frames (button.__owner is set by MicroMenu.lua)
		if button.__owner and parent == button.__owner then return end
		-- Block any other reparenting — force back to HiddenFrame or __owner
		local target = button.__owner or T.HiddenFrame
		button:SetParent(target)
	end

	local hideFrame = CreateFrame("Frame")
	hideFrame:RegisterEvent("PLAYER_LOGIN")
	hideFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
	hideFrame:SetScript("OnEvent", function(self, event)
		if event == "PLAYER_LOGIN" then
			self:UnregisterEvent("PLAYER_LOGIN")
		end

		-- Move micro buttons into HiddenFrame (unless MicroMenu.lua owns them)
		if T.HiddenFrame then
			for _, name in ipairs(microButtons) do
				if _G[name] then
					-- If MicroMenu.lua has taken ownership, skip this button
					if not (_G.MicroAnchor and _G[name]:GetParent() == _G.MicroAnchor) then
						_G[name]:SetParent(T.HiddenFrame)
					end
					-- Hook SetParent to prevent Blizzard from reparenting them back
					if not _G[name].__resetParentHooked then
						hooksecurefunc(_G[name], "SetParent", ResetMicroButtonParent)
						_G[name].__resetParentHooked = true
					end
				end
			end
		end

		-- After PEW, do a final cleanup pass for any elements that load late
		if event == "PLAYER_ENTERING_WORLD" then
			C_Timer.After(1, function()
				if T.HiddenFrame then
					for _, name in ipairs(microButtons) do
						if _G[name] then
							if not (_G.MicroAnchor and _G[name]:GetParent() == _G.MicroAnchor) then
								_G[name]:SetParent(T.HiddenFrame)
							end
						end
					end
				end
			end)
			self:UnregisterEvent("PLAYER_ENTERING_WORLD")
		end
	end)
end
----------------------------------------------------------------------------------------
local bug = nil
local FixTooltip = CreateFrame("Frame")
FixTooltip:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
FixTooltip:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
FixTooltip:SetScript("OnEvent", function()
	if GameTooltip:IsShown() then
		bug = true
	end
end)

local FixTooltipBags = CreateFrame("Frame")
FixTooltipBags:RegisterEvent("BAG_UPDATE_DELAYED")
FixTooltipBags:SetScript("OnEvent", function()
	if StuffingFrameBags and StuffingFrameBags:IsShown() then
		if GameTooltip:IsShown() then
			bug = true
		end
	end
end)

GameTooltip:HookScript("OnTooltipCleared", function(self)
	if self:IsForbidden() then return end
	if bug and self:NumLines() == 0 then
		self:Hide()
		bug = false
	end
end)

----------------------------------------------------------------------------------------
--	Fix RemoveTalent() taint
----------------------------------------------------------------------------------------
if T.Mainline then
	FCF_StartAlertFlash = T.dummy
end

----------------------------------------------------------------------------------------
--	Fix DeclensionFrame strata
----------------------------------------------------------------------------------------
if T.client == "ruRU" then
	_G["DeclensionFrame"]:SetFrameStrata("HIGH")
end

----------------------------------------------------------------------------------------
--	Fix Keybind taint
----------------------------------------------------------------------------------------
if _G.SettingsPanel then
	_G.SettingsPanel.TransitionBackOpeningPanel = _G.HideUIPanel
end

----------------------------------------------------------------------------------------
-- !!NoTaint2 (Code by warbaby 2022-11 http://abyui.top https://github.com/aby-ui)
----------------------------------------------------------------------------------------
if T.Mainline then
	if IsAddOnLoaded("!!NoTaint2") then return end
	if not NoTaint2_Proc_ResetActionButtonAction then
		NoTaint2_Proc_ResetActionButtonAction = 1

		-- use /run ActionButton2.action = 2 ActionButton2:UpdateAction() to test

		function NoTaint2_ResetActionButtonAction(self)
			local ok, tainted_by = issecurevariable(self, "action")
			if not ok and not InCombatLockdown() then
				self.action=nil
				self:SetAttribute("_aby", "action")
				-- if self:IsVisible() then NoTaint2_ShowWarning(tainted_by) end
			end
		end

		for _, v in ipairs(ActionBarButtonEventsFrame.frames) do
			hooksecurefunc(v, "UpdateAction", NoTaint2_ResetActionButtonAction)
		end

		local f1 = CreateFrame("Frame")
		f1:RegisterEvent("PLAYER_REGEN_ENABLED")
		f1:SetScript("OnEvent", function(self, event, ...)
			for _, v in ipairs(ActionBarButtonEventsFrame.frames) do
				NoTaint2_ResetActionButtonAction(v)
			end
		end)
	end

	if not NoTaint2_CleanStaticPopups then
		--code since !NoTaint, test: /run StaticPopup_Show('PARTY_INVITE',"a") /dump issecurevariable(StaticPopup1, "which")
		function NoTaint2_CleanStaticPopups()
			for index = 1, STATICPOPUP_NUMDIALOGS, 1 do
				local frame = _G["StaticPopup"..index];
				if not issecurevariable(frame, "which") then
					if frame:IsShown() then
						local info = StaticPopupDialogs[frame.which];
						if info and not issecurevariable(info, "OnCancel") then
							info.OnCancel()
						end
						frame:Hide()
					end
					frame.which = nil
				end
			end
		end

		function NoTaint2_CleanDropDownList()
			local frameToShow = LFDQueueFrameTypeDropDown
			local parent = frameToShow:GetParent()
			frameToShow:SetParent(nil) --to show
			--RequestLFDPlayerLockInfo() --to trigger LFG_LOCK_INFO_RECEIVED
			frameToShow:SetParent(parent)
		end

		local global_obj_name = {
			UIDROPDOWNMENU_MAXBUTTONS = 1,
			UIDROPDOWNMENU_MAXLEVELS = 1,
			UIDROPDOWNMENU_OPEN_MENU = 1,
			UIDROPDOWNMENU_INIT_MENU = 1,
			OBJECTIVE_TRACKER_UPDATE_REASON = 1,
		}

		function NoTaint2_CleanGlobal(self)
			for k, _ in pairs(global_obj_name) do
				if not issecurevariable(k) then
					--print("clean", k, issecurevariable(k))
					_G[k] = nil
				end
			end
			--ObjectiveTrackerFrame.lastMapID = nil
		end

		hooksecurefunc(EditModeManagerFrame, "ClearActiveChangesFlags", function(self)
			for _, systemFrame in ipairs(self.registeredSystemFrames) do
				systemFrame:SetHasActiveChanges(nil);
			end
			self:SetHasActiveChanges(nil);
		end)

		-- not sure if this is of any use. PetFrame and ActionBar call it.
		hooksecurefunc(EditModeManagerFrame, "HideSystemSelections", function(self)
			if self.editModeActive == false then
				self.editModeActive = nil
			end
		end)

		hooksecurefunc(EditModeManagerFrame, "IsEditModeLocked", function()
			NoTaint2_CleanGlobal()
		end)

		local function cleanAll()
			NoTaint2_CleanDropDownList()
			NoTaint2_CleanStaticPopups()
			NoTaint2_CleanGlobal()
		end

		local Origin_IsShown = EditModeManagerFrame.IsShown
		hooksecurefunc(EditModeManagerFrame, "IsShown", function(self)
			if Origin_IsShown(self) then return end
			local stack = debugstack(4)
			--call from UIParent.lua if ( not frame or frame:IsShown() ) then
			--different when hooked
			if stack and stack:find('[string "=[C]"]: in function `ShowUIPanel\'\n', 1, true) then
				cleanAll()
			end
		end)

		-- In case the stack check is failed, assure the game menu entrance.
		-- Running cleanAll() multi times has no side effects.
		GameMenuButtonEditMode:HookScript("PreClick", cleanAll)
	end

	if not NoTaint2_Proc_StopEnterWorldLayout then
		NoTaint2_Proc_StopEnterWorldLayout = 1
		local f2 = CreateFrame("Frame")
		f2:RegisterEvent("PLAYER_LEAVING_WORLD")
		f2:RegisterEvent("PLAYER_ENTERING_WORLD")
		f2:SetScript("OnEvent", function(self, event, ...)
			if event == "PLAYER_ENTERING_WORLD" then
				local login, reload = ...
				if not login and not reload then
					NoTaint2_CleanDropDownList()
					NoTaint2_CleanStaticPopups()
					NoTaint2_CleanGlobal()
				end
				EditModeManagerFrame:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
			elseif event == "PLAYER_LEAVING_WORLD" then
				EditModeManagerFrame:UnregisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
			end
		end)
	end

	if not NoTaint2_Proc_CleanActionButtonFlyout then
		NoTaint2_Proc_CleanActionButtonFlyout = 1
		--[[------------------------------------------------------------
		this is totally magic, thanks god ObjectiveTrackerFrame is after the ActionBars
		---------------------------------------------------------------]]
		local barsToUpdate = { MainMenuBar, MultiBarBottomLeft, MultiBarBottomRight, StanceBar, PetActionBar, PossessActionBar, MultiBarRight, MultiBarLeft, MultiBar5, MultiBar6, MultiBar7 }
		for _, bar in ipairs(barsToUpdate) do
			hooksecurefunc(bar, "UpdateSpellFlyoutDirection", function(self)
				if not issecurevariable(self, "flyoutDirection") then
					self.flyoutDirection = nil
				end
				if not issecurevariable(self, "snappedToFrame") then
					self.snappedToFrame = nil
				end
			end)
		end

		hooksecurefunc("SetClampedTextureRotation", function(texture)
			local parent = texture and texture:GetParent()
			if parent and parent.FlyoutArrowPushed and parent.FlyoutArrowHighlight then
				if not issecurevariable(texture, "rotationDegrees") then
					texture.rotationDegrees = nil
				end
			end
		end)
	end
end