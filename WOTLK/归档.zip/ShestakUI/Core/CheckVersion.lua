local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	Check outdated UI version
----------------------------------------------------------------------------------------
local function ParseVersion(str)
	local major, minor, patch = str:match("(%d+)%.(%d+)%.(%d+)")
	if major then
		return tonumber(major) * 10000 + tonumber(minor) * 100 + tonumber(patch)
	end
	return tonumber(str) or 0
end

local check = function(self, event, prefix, message, _, sender)
	if event == "CHAT_MSG_ADDON" then
		if prefix ~= "ShestakUIVersion" or sender == T.name then return end
		if ParseVersion(message) > ParseVersion(T.version) then
			if T.Classic then
				print("|cffff0000"..L_MISC_UI_OUTDATED_CLASSIC.."|r")
			else
				print("|cffff0000"..L_MISC_UI_OUTDATED.."|r")
			end
			self:UnregisterEvent("CHAT_MSG_ADDON")
		end
	else
		if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
			C_ChatInfo.SendAddonMessage("ShestakUIVersion", T.version, "INSTANCE_CHAT")
		elseif IsInRaid(LE_PARTY_CATEGORY_HOME) then
			C_ChatInfo.SendAddonMessage("ShestakUIVersion", T.version, "RAID")
		elseif IsInGroup(LE_PARTY_CATEGORY_HOME) then
			C_ChatInfo.SendAddonMessage("ShestakUIVersion", T.version, "PARTY")
		elseif IsInGuild() then
			C_ChatInfo.SendAddonMessage("ShestakUIVersion", T.version, "GUILD")
		end
	end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("CHAT_MSG_ADDON")
frame:SetScript("OnEvent", check)
C_ChatInfo.RegisterAddonMessagePrefix("ShestakUIVersion")

----------------------------------------------------------------------------------------
--	Whisper UI version
----------------------------------------------------------------------------------------
local whisp = CreateFrame("Frame")
whisp:RegisterEvent("CHAT_MSG_WHISPER")
-- 3.80.2: CHAT_MSG_BN_WHISPER may not exist
pcall(function() whisp:RegisterEvent("CHAT_MSG_BN_WHISPER") end)
whisp:SetScript("OnEvent", function(_, event, text, name, ...)
	if text:lower():match("ui_version") or text:lower():match("уи_версия") then
		if event == "CHAT_MSG_WHISPER" then
			SendChatMessage("ShestakUI "..T.version, "WHISPER", nil, name)
		elseif event == "CHAT_MSG_BN_WHISPER" then
			BNSendWhisper(select(11, ...), "ShestakUI "..T.version)
		end
	end
end)
