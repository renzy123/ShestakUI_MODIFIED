local T, C, L = unpack(ShestakUI)
if C.actionbar.enable ~= true then return end

local strmatch = string.match

----------------------------------------------------------------------------------------
--	Hide Blizzard ActionBars stuff(by Tukz)
--	Adapted for 3.80.1 时光服 hybrid UI architecture (Retail-style EditMode + Classic API)
--	Uses mixed approach: HideOption/SetParent for safe frames, DisableAllScripts for
--	MultiBar frames that still host Blizzard buttons ShestakUI relies on.
--	Credit: NDui for DisableAllScripts, HideOption, DisableDefaultBarEvents patterns.
----------------------------------------------------------------------------------------

-- Create a hidden frame container for Blizzard action bar frames
T.HiddenFrame = CreateFrame("Frame")
T.HiddenFrame:Hide()

-- 3.80.1 注意：不要给 EditModeManagerFrame 赋字段（如 OnEditModeExit/OnEditModeEnter/HighlightSystem/ClearHighlight），
-- 否则会 taint 整个 EditModeManagerFrame 表，Blizzard 后续调用 ExitEditMode → OnEditModeExit →
-- ResetTargetAndFocus → ClearTarget() 等保护函数时会被 ADDON_ACTION_FORBIDDEN 归因到 ShestakUI。
-- 错误已验证：EditModeManagerFrame 上的字段赋值是 ClearTarget() taint 的根因。
-- Blizzard_EditMode 在加载时会通过 mixin 定义 OnEditModeExit 等方法，无需我们 stub。
-- 如果 Blizzard 因 hooksecurefunc 时机问题报错，应改用 hooksecurefunc("", "OnEditModeExit", noop) 模式，
-- 而非直接字段赋值。

-- Disable all script handlers on a frame (credit: NDui/Simpy)
local scripts = {
	"OnShow", "OnHide", "OnEvent", "OnEnter", "OnLeave", "OnUpdate",
	"OnValueChanged", "OnClick", "OnMouseDown", "OnMouseUp",
}
local function DisableAllScripts(frame)
	for _, script in pairs(scripts) do
		if frame:HasScript(script) then
			frame:SetScript(script, nil)
		end
	end
end

-- Kill EditMode highlight/selection overlays on a managed frame (credit: NDui)
local function KillEditMode(object)
	if object.HighlightSystem then object.HighlightSystem = function() end end
	if object.ClearHighlight then object.ClearHighlight = function() end end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function()
	MainMenuBar:SetMovable(true)
	MainMenuBar:SetUserPlaced(true)
	MainMenuBar.ignoreFramePositionManager = true
	MainMenuBar:SetAttribute("ignoreFramePositionManager", true)

	if T.NewClassicUI then
		-- =====================================================================
		-- 3.80.1 时光服: LibActionButton-1.0 approach (credit: NDui architecture)
		-- =====================================================================
		-- ROOT CAUSE of "bars disappear on hover" bug:
		--   3.80.1's EditMode system overrides Show/Hide/IsShown on ALL action
		--   bar frames. ShestakUI uses Blizzard's original buttons which are
		--   children of these EditMode-managed frames. Any EditMode state change
		--   can hide the parent frame, making all buttons vanish.
		--
		-- SOLUTION: Use LibActionButton-1.0 to create INDEPENDENT action buttons
		-- that have NO parent-child relationship with Blizzard's bar frames.
		-- Then simply SetParent(HiddenFrame) on all Blizzard frames.
		-- This is the same approach NDUI uses successfully.
		-- =====================================================================

		local LAB = LibStub("LibActionButton-1.0-ShestakUI")
		T.LabBars = {}   -- Store LAB header references [1-5]
		T.LabButtons = {} -- Store all LAB button references

		-- Page condition strings for Bar1 (same as original Bar1.lua)
		local Page = {
			["DRUID"] = "[bonusbar:1] 7; [bonusbar:2] 8; [bonusbar:3] 9; [bonusbar:4] 10;",
			["WARRIOR"] = "[bonusbar:1] 7; [bonusbar:2] 8; [bonusbar:3] 9;",
			["PRIEST"] = "[bonusbar:1] 7;",
			["ROGUE"] = "[bonusbar:1] 7; [form:3] 7;",
			["WARLOCK"] = "[form:2] 10;",
			["DEFAULT"] = "[possessbar] 16; [shapeshift] 17; [overridebar] 18; [vehicleui] 16; [bar:2] 2; [bar:3] 3; [bar:4] 4; [bar:5] 5; [bar:6] 6; [bonusbar: 5] 11;",
		}

		local function GetBar1Page()
			local condition = Page["DEFAULT"]
			local page = Page[T.class]
			if page then
				condition = condition.." "..page
			end
			condition = condition.." 1"
			return condition
		end

		-- LAB bar data: page index and key binding name prefix
		local LAB_BAR_DATA = {
			[1] = {page = 1, bindName = "ACTIONBUTTON"},
			[2] = {page = 6, bindName = "MULTIACTIONBAR1BUTTON"},
			[3] = {page = 5, bindName = "MULTIACTIONBAR2BUTTON"},
			[4] = {page = 3, bindName = "MULTIACTIONBAR3BUTTON"},
			[5] = {page = 4, bindName = "MULTIACTIONBAR4BUTTON"},
		}

		-- [1] Create LAB buttons for each bar, parented to secure handler headers
		local labHeaders = {}
		for index = 1, 5 do
			local data = LAB_BAR_DATA[index]
			local holderName = "Bar"..index.."Holder"
			-- MUST use SecureHandlerStateTemplate for WrapScript (LAB requirement)
			-- Bar1.lua already creates with SecureHandlerStateTemplate, but Bar2-5 use plain Frame.
			-- So we always create a new secure header and reparent any existing holder's children.
			-- Determine parent: Bar1-2 and Bar5(when rightbars<3, it's a bottom bar) -> ActionBarAnchor
			-- Bar3-4 and Bar5(when rightbars>=3, it's a right bar) -> RightActionBarAnchor
			-- This ensures toggle panel can independently control bottom bars (1/2/3) and right bars (0/1/2)
			-- without Bar5 visibility being affected by RightActionBarAnchor:Hide()
			local parent
			if index <= 2 or (index == 3 and C.actionbar.rightbars < 3) then
				parent = ActionBarAnchor
			else
				parent = RightActionBarAnchor
			end
			-- Dispose of existing holder if present (created by Bar#.lua before NewClassicUI return)
			local existingHolder = _G[holderName]
			if existingHolder then
				existingHolder:Hide()
				existingHolder:SetParent(UIParent)
				existingHolder:ClearAllPoints()
			end
			local header = CreateFrame("Frame", holderName, parent, "SecureHandlerStateTemplate")
			header:SetAllPoints(parent)

			header.buttons = {}

			for i = 1, 12 do
				local button = LAB:CreateButton(i, "Shestik_Bar"..index.."Button"..i, header)
				button:SetState(0, "action", i)
				for k = 1, 18 do
					button:SetState(k, "action", (k - 1) * 12 + i)
				end
				button.bindName = data.bindName..i
				button.keyBoundTarget = data.bindName..i

				tinsert(header.buttons, button)
				tinsert(T.LabButtons, button)
			end

			-- [2] Page switching via state driver
			header:SetAttribute("_onstate-page", [[
				self:SetAttribute("state", newstate)
				control:ChildUpdate("state", newstate)
			]])

			if index == 1 then
				RegisterStateDriver(header, "page", GetBar1Page())
			else
				RegisterStateDriver(header, "page", data.page)
			end

			T.LabBars[index] = header
			labHeaders[index] = header
		end

		-- [3] Position LAB buttons within their holders (mirrors Bar1-5.lua layout)
		-- Bar1: horizontal bottom
		for i = 1, 12 do
			local button = labHeaders[1].buttons[i]
			button:SetSize(C.actionbar.button_size, C.actionbar.button_size)
			button:ClearAllPoints()
			if i == 1 then
				button:SetPoint("BOTTOMLEFT", labHeaders[1], 0, 0)
			else
				button:SetPoint("LEFT", labHeaders[1].buttons[i-1], "RIGHT", T.Scale(C.actionbar.button_space), 0)
			end
		end

		-- Bar2: horizontal above Bar1
		for i = 1, 12 do
			local button = labHeaders[2].buttons[i]
			button:SetSize(C.actionbar.button_size, C.actionbar.button_size)
			button:ClearAllPoints()
			if i == 1 then
				button:SetPoint("BOTTOM", labHeaders[1].buttons[1], "TOP", 0, C.actionbar.button_space)
			else
				button:SetPoint("LEFT", labHeaders[2].buttons[i-1], "RIGHT", T.Scale(C.actionbar.button_space), 0)
			end
		end

		-- Bar4 (MultiBarRight): vertical right side outermost
		for i = 1, 12 do
			local button = labHeaders[4].buttons[i]
			button:SetSize(C.actionbar.button_size, C.actionbar.button_size)
			button:ClearAllPoints()
			if i == 1 then
				button:SetPoint("TOPRIGHT", RightActionBarAnchor, "TOPRIGHT", 0, 0)
			else
				button:SetPoint("TOP", labHeaders[4].buttons[i-1], "BOTTOM", 0, -C.actionbar.button_space)
			end
		end

		-- Bar5: vertical right side (left of Bar4)
		-- New layout: Bar5 is always right-side, positioned between Bar3 and Bar4
		for i = 1, 12 do
			local button = labHeaders[5].buttons[i]
			button:SetSize(C.actionbar.button_size, C.actionbar.button_size)
			button:ClearAllPoints()
			if i == 1 then
				if C.actionbar.rightbars == 3 then
					-- 3 right bars: Bar3(leftmost), Bar5(middle), Bar4(rightmost)
					button:SetPoint("TOP", RightActionBarAnchor, "TOP", 0, 0)
			else
					button:SetPoint("TOPLEFT", RightActionBarAnchor, "TOPLEFT", 0, 0)
			end
			else
				button:SetPoint("TOP", labHeaders[5].buttons[i-1], "BOTTOM", 0, -C.actionbar.button_space)
			end
		end

		-- Bar3 (MultiBarLeft): layout depends on config
		-- New layout: Bar3 is bottom 3rd bar (when rightbars<3) or right 1st bar (when rightbars==3)
		if C.actionbar.rightbars < 3 then
			-- Horizontal layout (above Bar2 as 3rd bottom bar)
			for i = 1, 12 do
				local button = labHeaders[3].buttons[i]
				button:SetSize(C.actionbar.button_size, C.actionbar.button_size)
				button:ClearAllPoints()
				if i == 1 then
					button:SetPoint("BOTTOM", labHeaders[2].buttons[1], "TOP", 0, C.actionbar.button_space)
				else
					button:SetPoint("LEFT", labHeaders[3].buttons[i-1], "RIGHT", T.Scale(C.actionbar.button_space), 0)
				end
			end
		else
			-- Vertical layout on right side (leftmost of 3 right bars)
			for i = 1, 12 do
				local button = labHeaders[3].buttons[i]
				button:SetSize(C.actionbar.button_size, C.actionbar.button_size)
				button:ClearAllPoints()
				if i == 1 then
					button:SetPoint("TOPLEFT", RightActionBarAnchor, "TOPLEFT", 0, 0)
				else
					button:SetPoint("TOP", labHeaders[3].buttons[i-1], "BOTTOM", 0, -C.actionbar.button_space)
				end
			end
		end

		-- [4] Configure LAB buttons
		-- NOTE: keyBoundTarget must go into button.config (not button itself),
		-- because LAB's GetHotkey() reads self.config.keyBoundTarget.
		-- keyBoundClickButton must be "Keybind" to match ReassignBindings' SetOverrideBindingClick.
		for index = 1, 5 do
			local data = LAB_BAR_DATA[index]
			for i, button in next, labHeaders[index].buttons do
				button:SetAttribute("buttonlock", GetCVarBool("lockActionBars"))
				button:SetAttribute("checkmouseovercast", true)
				button:SetAttribute("checkfocuscast", true)
				button:SetAttribute("checkselfcast", true)

				-- Per-button config: include keyBoundTarget so LAB's GetHotkey() can find the binding,
				-- and keyBoundClickButton="Keybind" to match ReassignBindings' SetOverrideBindingClick.
				local btnConfig = {
					hideElements = {
						hotkey = not C.actionbar.hotkey,
						macro = not C.actionbar.macro,
						equipped = not C.actionbar.classcolor_border,
					},
					showGrid = C.actionbar.show_grid,
					clickOnDown = GetCVarBool("ActionButtonUseKeyDown"),
					outOfRangeColoring = "button",
					keyBoundTarget = data.bindName..i,
					keyBoundClickButton = "Keybind",
				}
				button:UpdateConfig(btnConfig)

				-- Also store on button for ReassignBindings (which reads button.keyBoundTarget)
				button.keyBoundTarget = data.bindName..i
			end
		end

		-- [5] Key binding reassignment (credit: NDui)
		local function ReassignBindings()
			if InCombatLockdown() then return end
			for index = 1, 5 do
				local header = labHeaders[index]
				for _, button in next, header.buttons do
					for _, key in next, {GetBindingKey(button.keyBoundTarget)} do
						if key and key ~= "" then
							SetOverrideBindingClick(header, false, key, button:GetName(), "Keybind")
						end
					end
				end
			end
		end

		ReassignBindings()
		local labBindFrame = CreateFrame("Frame")
		labBindFrame:RegisterEvent("UPDATE_BINDINGS")
		labBindFrame:SetScript("OnEvent", ReassignBindings)

		-- [6] Hide Blizzard action bar frames (NDUI-style — simple and robust)
		-- Since LAB buttons are INDEPENDENT of Blizzard frames, we can safely
		-- SetParent(HiddenFrame) on ALL Blizzard bar frames without side effects.
		MainMenuBar:SetMovable(true)
		MainMenuBar:SetUserPlaced(true)
		MainMenuBar.ignoreFramePositionManager = true
		MainMenuBar:SetAttribute("ignoreFramePositionManager", true)

		local petBar = _G.PetActionBar or _G.PetActionBarFrame
		local stanceBar = _G.StanceBar or _G.StanceBarFrame
		local possessBar = _G.PossessActionBar or _G.PossessBarFrame

		local framesToHide = {
			MainMenuBar, MainMenuBarArtFrame,
			MultiBarBottomLeft, MultiBarBottomRight,
			MultiBarLeft, MultiBarRight,
			OverrideActionBar, possessBar,
			petBar, stanceBar,
			StatusTrackingBarManager, BagsBar, _G.MicroMenu,
		}
		if _G.MainActionBar then
			tinsert(framesToHide, _G.MainActionBar)
		end
		for _, f in pairs(framesToHide) do
			if f then f:SetParent(T.HiddenFrame) end
		end

		-- HideOption(MainActionBar) — extra safety (credit: NDui)
		if _G.MainActionBar then
			_G.MainActionBar:SetAlpha(0)
			_G.MainActionBar:SetScale(0.0001)
			_G.MainActionBar:ClearAllPoints()
			_G.MainActionBar:SetPoint("BOTTOMLEFT", UIParent, -100, -100)
		end

		local framesToDisable = {
			MainMenuBar, MainMenuBarArtFrame,
			MultiBarBottomLeft, MultiBarBottomRight, MultiBarLeft, MultiBarRight,
			OverrideActionBar, possessBar,
			petBar, stanceBar,
			MicroButtonAndBagsBar, StatusTrackingBarManager,
			MainMenuBarVehicleLeaveButton,
		}
		if _G.MainActionBar then
			tinsert(framesToDisable, _G.MainActionBar)
		end
		for _, f in pairs(framesToDisable) do
			if f then
				if f.UnregisterAllEvents then f:UnregisterAllEvents() end
				DisableAllScripts(f)
			end
		end

		-- Kill QuickKeybindFrame
		if _G.QuickKeybindFrame then
			_G.QuickKeybindFrame:SetParent(T.HiddenFrame)
			_G.QuickKeybindFrame:UnregisterAllEvents()
			DisableAllScripts(_G.QuickKeybindFrame)
		end

		-- Kill EditMode highlights
		-- 注意：不要对 _G.EditModeManagerFrame 调用 KillEditMode —— 它通过字段赋值
		-- (object.HighlightSystem = function() end) 污染 EditModeManagerFrame 表，
		-- 导致 Blizzard 退出 EditMode 时 ClearTarget() 被 taint 归因 ShestakUI。
		-- EditMode 高亮对 ShestakUI 用户无意义（所有 frame 已被 ShestakUI 接管），
		-- 不调用 KillEditMode 也不会有功能问题。
		-- if _G.EditModeManagerFrame then
		-- 	KillEditMode(_G.EditModeManagerFrame)
		-- end

		-- [7] DisableDefaultBarEvents (credit: NDui/Simpy)
		ActionBarController:UnregisterAllEvents()
		pcall(function() ActionBarController:RegisterEvent("SETTINGS_LOADED") end)
		ActionBarController:RegisterEvent("UPDATE_EXTRA_ACTIONBAR")
		ActionBarController.ignoreFramePositionManager = true

		if _G.ActionBarActionEventsFrame then
			_G.ActionBarActionEventsFrame:UnregisterAllEvents()
		end

		if _G.ActionBarButtonEventsFrame then
			_G.ActionBarButtonEventsFrame:UnregisterAllEvents()
			_G.ActionBarButtonEventsFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
			_G.ActionBarButtonEventsFrame:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")

			if _G.ActionBarButtonEventsFrame.RegisterFrame then
				local originalRegisterFrame = _G.ActionBarButtonEventsFrame.RegisterFrame
				_G.ActionBarButtonEventsFrame.RegisterFrame = function(self, added)
					if added and type(added.GetName) == "function" and added:GetName() then
						if not strmatch(added:GetName(), "ExtraActionButton%d") then
							return
						end
					end
					return originalRegisterFrame(self, added)
				end
				if _G.ActionBarButtonEventsFrame.frames then
					for index, f in pairs(_G.ActionBarButtonEventsFrame.frames) do
						if f and type(f.GetName) == "function" and f:GetName() then
							if not strmatch(f:GetName(), "ExtraActionButton%d") then
								_G.ActionBarButtonEventsFrame.frames[index] = nil
							end
						end
					end
				end
			end
		end
	else
		-- Original Classic/Mainline logic (unchanged)
		MainMenuBar:SetScale(0.00001)
		MainMenuBar:EnableMouse(false)

		local petBar = _G.PetActionBar or _G.PetActionBarFrame
		local stanceBar = _G.StanceBar or _G.StanceBarFrame
		if T.Classic then
			if petBar then
				petBar:EnableMouse(false)
				if petBar.UnregisterAllEvents then petBar:UnregisterAllEvents() end
			end
			if stanceBar then
				stanceBar:EnableMouse(false)
				if stanceBar.UnregisterAllEvents then stanceBar:UnregisterAllEvents() end
			end
		else
			PetActionBar:EnableMouse(false)
			PetActionBar:UnregisterAllEvents()
			StanceBar:EnableMouse(false)
			StanceBar:UnregisterAllEvents()
		end

		if T.Wrath or T.Cata or T.Mainline then
			OverrideActionBar:SetScale(0.00001)
			OverrideActionBar:EnableMouse(false)
		end

		if T.Mainline then
			MicroButtonAndBagsBar:SetScale(0.00001)
			MicroButtonAndBagsBar:EnableMouse(false)
			MicroButtonAndBagsBar:ClearAllPoints()
			MicroButtonAndBagsBar:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", 0, -99)
			if BagsBar then
				BagsBar:Hide()
				BagsBar:UnregisterAllEvents()
			end
		end

		if T.Mainline then
			if not C.actionbar.micromenu then
				MicroMenu:Hide()
				TalentMicroButton:ClearAllPoints()
				TalentMicroButton:SetPoint("TOP", UIParent, "TOP", 0, 100)
			end
		end

		local elements = {
			MainMenuBar, MainMenuBarArtFrame, OverrideActionBar, PossessBarFrame,
			_G.PetActionBar or _G.PetActionBarFrame,
			_G.StanceBar or _G.StanceBarFrame,
			StatusTrackingBarManager
		}
		local qkFrames = { MultiBarBottomLeft, MultiBarLeft, MultiBarBottomRight, MultiBarRight }
		for _, bar in pairs(qkFrames) do
			if bar and bar.QuickKeybindGlow then
				tinsert(elements, bar.QuickKeybindGlow)
			end
		end
		if T.Mainline then
			if not C_ClassTrial.IsClassTrialCharacter() then
				tinsert(elements, IconIntroTracker)
			end
		end
		for _, element in pairs(elements) do
			if element then
				if element.UnregisterAllEvents then element:UnregisterAllEvents() end
				if element ~= MainMenuBar then element:Hide() end
				element:SetAlpha(0)
			end
		end
	end

	if T.Wrath or T.Cata or T.Mainline then
		for i = 1, 6 do
			local b = _G["OverrideActionBarButton"..i]
			b:UnregisterAllEvents()
			b:SetAttribute("statehidden", true)
			b:SetAttribute("showgrid", 1)
		end
	end

	if T.Vanilla then
		hooksecurefunc("PlayerTalentFrame_LoadUI", function()
			PlayerTalentFrame:UnregisterEvent("CHARACTER_POINTS_CHANGED")
		end)
	else
		hooksecurefunc("TalentFrame_LoadUI", function()
			if T.Classic then
				PlayerTalentFrame:UnregisterEvent("CHARACTER_POINTS_CHANGED")
				if T.Wrath or T.Cata then
					PlayerTalentFrame:UnregisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
				end
			else
				PlayerTalentFrame:UnregisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
			end
		end)
	end

	-- Fixed SetPointBase and ShowBase taints after finish Pet Battle, entering new combat and summon Hunter pet.
	ActionBarController:UnregisterEvent("UPDATE_VEHICLE_ACTIONBAR")
	ActionBarController:UnregisterEvent("UPDATE_OVERRIDE_ACTIONBAR")
end)

----------------------------------------------------------------------------------------
--	Set mouseover for bars
----------------------------------------------------------------------------------------
function RightBarMouseOver(alpha)
	RightActionBarAnchor:SetAlpha(alpha)
	PetActionBarAnchor:SetAlpha(alpha)
	StanceBarAnchor:SetAlpha(alpha)

	if T.NewClassicUI then
		-- LAB bar approach: directly set alpha on LAB buttons, no IsShown check needed
		-- Bar3 (MultiBarLeft)
		if T.LabBars[3] then
			for i = 1, 12 do
				local button = T.LabBars[3].buttons[i]
				if button then
					button:SetAlpha(alpha)
					if button.cooldown then
						T.HideSpiral(button.cooldown, alpha)
					end
				end
			end
			T.LabBars[3]:SetAlpha(alpha)
		end

		-- Bar4 (MultiBarRight)
		if T.LabBars[4] then
			for i = 1, 12 do
				local button = T.LabBars[4].buttons[i]
				if button then
					button:SetAlpha(alpha)
					if button.cooldown then
						T.HideSpiral(button.cooldown, alpha)
					end
				end
			end
			T.LabBars[4]:SetAlpha(alpha)
		end

		-- Bar5 (MultiBarBottomRight) — only when rightbars > 2
		if C.actionbar.rightbars > 2 and T.LabBars[5] then
			for i = 1, 12 do
				local button = T.LabBars[5].buttons[i]
				if button then
					button:SetAlpha(alpha)
					if button.cooldown then
						T.HideSpiral(button.cooldown, alpha)
					end
				end
			end
			T.LabBars[5]:SetAlpha(alpha)
		end
	else
		if MultiBarLeft:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarLeftButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarLeftButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
			MultiBarLeft:SetAlpha(alpha)
		end

		if MultiBarRight:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarRightButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarRightButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
			MultiBarRight:SetAlpha(alpha)
		end

		if C.actionbar.rightbars > 2 then
			if T.Classic then
				if MultiBarBottomRight:IsShown() then
					for i = 1, 12 do
						local b = _G["MultiBarBottomRightButton"..i]
						b:SetAlpha(alpha)
						local c = _G["MultiBarBottomRightButton"..i.."Cooldown"]
						T.HideSpiral(c, alpha)
					end
					MultiBarBottomRight:SetAlpha(alpha)
				end
			else
				if MultiBar5:IsShown() then
					for i = 1, 12 do
						local b = _G["MultiBar5Button"..i]
						b:SetAlpha(alpha)
						local c = _G["MultiBar5Button"..i.."Cooldown"]
						T.HideSpiral(c, alpha)
					end
					MultiBar5:SetAlpha(alpha)
				end
			end
		end
	end

	if C.actionbar.petbar_horizontal == false and C.actionbar.petbar_hide == false then
		if PetHolder:IsShown() then
			for i = 1, NUM_PET_ACTION_SLOTS do
				local b = _G["PetActionButton"..i]
				b:SetAlpha(alpha)
				local c = _G["PetActionButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
			PetHolder:SetAlpha(alpha)
		end
	end

	if C.actionbar.stancebar_horizontal == false and C.actionbar.stancebar_hide == false then
		if StanceHolder:IsShown() then
			for i = 1, 10 do
				local b = _G["StanceButton"..i]
				b:SetAlpha(alpha)
				local c = _G["StanceButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
			StanceHolder:SetAlpha(alpha)
		end
	end
end

function StanceBarMouseOver(alpha)
	for i = 1, 10 do
		local b = _G["StanceButton"..i]
		b:SetAlpha(alpha)
		local c = _G["StanceButton"..i.."Cooldown"]
		T.HideSpiral(c, alpha)
	end
	StanceHolder:SetAlpha(alpha)
end

function PetBarMouseOver(alpha)
	for i = 1, NUM_PET_ACTION_SLOTS do
		local b = _G["PetActionButton"..i]
		b:SetAlpha(alpha)
		local c = _G["PetActionButton"..i.."Cooldown"]
		T.HideSpiral(c, alpha)
	end
	PetHolder:SetAlpha(alpha)
end

if C.actionbar.rightbars_mouseover == true then
	RightActionBarAnchor:SetAlpha(0)
	RightActionBarAnchor:SetScript("OnEnter", function() RightBarMouseOver(1) end)
	RightActionBarAnchor:SetScript("OnLeave", function() if not HoverBind.enabled then RightBarMouseOver(0) end end)
end

function BottomBarMouseOver(alpha)
	if T.NewClassicUI then
		-- LAB bar approach: directly set alpha on LAB buttons
		-- Bar1 (main action bar)
		if T.LabBars[1] then
			for i = 1, 12 do
				local button = T.LabBars[1].buttons[i]
				if button then
					button:SetAlpha(alpha)
					if button.cooldown then
						T.HideSpiral(button.cooldown, alpha)
					end
				end
			end
		end

		-- Bar2 (MultiBarBottomLeft)
		if C.actionbar.bottombars > 1 and T.LabBars[2] then
			for i = 1, 12 do
				local button = T.LabBars[2].buttons[i]
				if button then
					button:SetAlpha(alpha)
					if button.cooldown then
						T.HideSpiral(button.cooldown, alpha)
					end
				end
			end
		end

		-- Bar5 (MultiBarBottomRight) when shown at bottom
		if C.actionbar.bottombars > 2 and T.LabBars[5] then
			for i = 1, 12 do
				local button = T.LabBars[5].buttons[i]
				if button then
					button:SetAlpha(alpha)
					if button.cooldown then
						T.HideSpiral(button.cooldown, alpha)
					end
				end
			end
		end
	else
		for i = 1, 12 do
			local b = _G["ActionButton"..i]
			b:SetAlpha(alpha)
			local c = _G["ActionButton"..i.."Cooldown"]
			T.HideSpiral(c, alpha)
		end

		if C.actionbar.bottombars > 1 and MultiBarBottomLeft:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarBottomLeftButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarBottomLeftButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
		end

		if C.actionbar.bottombars > 2 and MultiBarBottomRight:IsShown() then
			if C.actionbar.toggle_mode == true and ShestakUISettingsPerChar.BottomBars == 1 then
				for i = 4, 6 do
					local b = _G["MultiBarBottomRightButton"..i]
					b:SetAlpha(alpha)
					local c = _G["MultiBarBottomRightButton"..i.."Cooldown"]
					T.HideSpiral(c, alpha)
				end

				for i = 10, 12 do
					local b = _G["MultiBarBottomRightButton"..i]
					b:SetAlpha(alpha)
					local c = _G["MultiBarBottomRightButton"..i.."Cooldown"]
					T.HideSpiral(c, alpha)
				end
			else
				for i = 1, 12 do
					local b = _G["MultiBarBottomRightButton"..i]
					b:SetAlpha(alpha)
					local c = _G["MultiBarBottomRightButton"..i.."Cooldown"]
					T.HideSpiral(c, alpha)
				end
			end
		end
	end
end

if C.actionbar.bottombars_mouseover then
	ActionBarAnchor:SetScript("OnEnter", function() BottomBarMouseOver(1) end)
	ActionBarAnchor:SetScript("OnLeave", function() if not HoverBind.enabled then BottomBarMouseOver(0) end end)

	if C.actionbar.split_bars == true then
		SplitBarLeft:SetScript("OnEnter", function() BottomBarMouseOver(1) end)
		SplitBarLeft:SetScript("OnLeave", function() if not HoverBind.enabled then BottomBarMouseOver(0) end end)

		SplitBarRight:SetScript("OnEnter", function() BottomBarMouseOver(1) end)
		SplitBarRight:SetScript("OnLeave", function() if not HoverBind.enabled then BottomBarMouseOver(0) end end)
	end
end

function Bar1MouseOver(alpha)
	if T.NewClassicUI and T.LabBars[1] then
		for i = 1, 12 do
			local button = T.LabBars[1].buttons[i]
			if button then
				button:SetAlpha(alpha)
				if button.cooldown then T.HideSpiral(button.cooldown, alpha) end
			end
		end
	else
		for i = 1, 12 do
			local b = _G["ActionButton"..i]
			b:SetAlpha(alpha)
			local c = _G["ActionButton"..i.."Cooldown"]
			T.HideSpiral(c, alpha)
		end
	end
end

function Bar2MouseOver(alpha)
	if T.NewClassicUI and T.LabBars[2] then
		for i = 1, 12 do
			local button = T.LabBars[2].buttons[i]
			if button then
				button:SetAlpha(alpha)
				if button.cooldown then T.HideSpiral(button.cooldown, alpha) end
			end
		end
	else
		if MultiBarBottomLeft:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarBottomLeftButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarBottomLeftButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
		end
	end
end

function Bar3MouseOver(alpha)
	if T.NewClassicUI and T.LabBars[3] then
		for i = 1, 12 do
			local button = T.LabBars[3].buttons[i]
			if button then
				button:SetAlpha(alpha)
				if button.cooldown then T.HideSpiral(button.cooldown, alpha) end
			end
		end
	else
		if MultiBarLeft:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarLeftButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarLeftButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
		end
	end
end

function Bar4MouseOver(alpha)
	if T.NewClassicUI and T.LabBars[4] then
		for i = 1, 12 do
			local button = T.LabBars[4].buttons[i]
			if button then
				button:SetAlpha(alpha)
				if button.cooldown then T.HideSpiral(button.cooldown, alpha) end
			end
		end
	else
		if MultiBarRight:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarRightButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarRightButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
		end
	end
end

function Bar5MouseOver(alpha)
	if T.NewClassicUI and T.LabBars[5] then
		for i = 1, 12 do
			local button = T.LabBars[5].buttons[i]
			if button then
				button:SetAlpha(alpha)
				if button.cooldown then T.HideSpiral(button.cooldown, alpha) end
			end
		end
	else
		if MultiBarBottomRight:IsShown() then
			for i = 1, 12 do
				local b = _G["MultiBarBottomRightButton"..i]
				b:SetAlpha(alpha)
				local c = _G["MultiBarBottomRightButton"..i.."Cooldown"]
				T.HideSpiral(c, alpha)
			end
		end
	end
end

function Bar6MouseOver(alpha)
	if MultiBar5:IsShown() then
		for i = 1, 12 do
			local b = _G["MultiBar6Button"..i]
			b:SetAlpha(alpha)
			local c = _G["MultiBar6Button"..i.."Cooldown"]
			T.HideSpiral(c, alpha)
		end
	end
end

function Bar7MouseOver(alpha)
	if MultiBar6:IsShown() then
		for i = 1, 12 do
			local b = _G["MultiBar6Button"..i]
			b:SetAlpha(alpha)
			local c = _G["MultiBar6Button"..i.."Cooldown"]
			T.HideSpiral(c, alpha)
		end
	end
end

function Bar8MouseOver(alpha)
	if MultiBar7:IsShown() then
		for i = 1, 12 do
			local b = _G["MultiBar7Button"..i]
			b:SetAlpha(alpha)
			local c = _G["MultiBar7Button"..i.."Cooldown"]
			T.HideSpiral(c, alpha)
		end
	end
end

----------------------------------------------------------------------------------------
--	Fix cooldown spiral alpha (WoD bug)
----------------------------------------------------------------------------------------
function T.HideSpiral(f, alpha)
	f:SetSwipeColor(0, 0, 0, alpha * 0.8)
	f:SetDrawBling(alpha == 1)
end

local EventSpiral = CreateFrame("Frame")
EventSpiral:RegisterEvent("PLAYER_ENTERING_WORLD")
EventSpiral:SetScript("OnEvent", function()
	if C.actionbar.rightbars_mouseover == true then
		RightBarMouseOver(0)
	end

	if C.actionbar.petbar_mouseover == true and C.actionbar.petbar_horizontal == true and C.actionbar.petbar_hide ~= true then
		PetBarMouseOver(0)
	end

	if C.actionbar.stancebar_mouseover == true and C.actionbar.stancebar_horizontal == true and C.actionbar.stancebar_hide ~= true then
		StanceBarMouseOver(C.actionbar.stancebar_mouseover_alpha)
	end

	if C.actionbar.bottombars_mouseover then
		BottomBarMouseOver(0)
	end

	if C.actionbar.editor then
		if C.actionbar.bar1_mouseover then
			Bar1MouseOver(0)
		end

		if C.actionbar.bar2_mouseover then
			Bar2MouseOver(0)
		end

		if C.actionbar.bar3_mouseover then
			Bar3MouseOver(0)
		end

		if C.actionbar.bar4_mouseover then
			Bar4MouseOver(0)
		end

		if C.actionbar.bar5_mouseover then
			Bar5MouseOver(0)
		end

		if T.Mainline and C.actionbar.bar6_mouseover then
			Bar6MouseOver(0)
		end
	end

	if T.Mainline and C.actionbar.bar7_mouseover then
		Bar7MouseOver(0)
	end

	if T.Mainline and C.actionbar.bar8_mouseover then
		Bar8MouseOver(0)
	end

	EventSpiral:UnregisterEvent("PLAYER_ENTERING_WORLD")
end)

if (C.actionbar.rightbars_mouseover == true and C.actionbar.petbar_horizontal == false and C.actionbar.petbar_hide == false) or (C.actionbar.petbar_mouseover == true and C.actionbar.petbar_horizontal == true and C.actionbar.petbar_hide == false) then
	local EventPetSpiral = CreateFrame("Frame")
	EventPetSpiral:RegisterEvent("PET_BAR_UPDATE_COOLDOWN")
	EventPetSpiral:SetScript("OnEvent", function()
		for i = 1, NUM_PET_ACTION_SLOTS do
			local c = _G["PetActionButton"..i.."Cooldown"]
			T.HideSpiral(c, 0)
		end
		EventPetSpiral:UnregisterEvent("PET_BAR_UPDATE_COOLDOWN")
	end)
end

----------------------------------------------------------------------------------------
--	Show grid function
----------------------------------------------------------------------------------------
	if T.NewClassicUI then
	-- LAB buttons handle showGrid internally via buttonConfig.showGrid.
	-- Just set the CVar so Blizzard's internal state is consistent.
	local frame = CreateFrame("Frame")
	frame:RegisterEvent("PLAYER_ENTERING_WORLD")
	frame:SetScript("OnEvent", function(self)
		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
		SetActionBarToggles(1, 1, 1, 1, 0)
		if C.actionbar.show_grid == true then
			SetCVar("alwaysShowActionBars", 1)
		else
			SetCVar("alwaysShowActionBars", 0)
		end
	end)
	elseif T.Classic then
	local frame = CreateFrame("Frame")
	frame:RegisterEvent("PLAYER_ENTERING_WORLD")
	frame:SetScript("OnEvent", function(self)
		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
		SetActionBarToggles(1, 1, 1, 1, 0)
		if C.actionbar.show_grid == true then
			SetCVar("alwaysShowActionBars", 1)
			for i = 1, 12 do
				local reason = ACTION_BUTTON_SHOW_GRID_REASON_EVENT or 2
				local button = _G[format("ActionButton%d", i)]
				button.noGrid = nil
				button:SetAttribute("showgrid", 1)
				if ActionButton_ShowGrid then
					ActionButton_ShowGrid(button, reason)
				else
					button:SetAlpha(1)
				end
				button:SetAttribute("statehidden", true)

				button = _G[format("MultiBarRightButton%d", i)]
				button.noGrid = nil
				button:SetAttribute("showgrid", 1)
				if ActionButton_ShowGrid then
					ActionButton_ShowGrid(button, reason)
				else
					button:SetAlpha(1)
				end
				button:SetAttribute("statehidden", true)

				button = _G[format("MultiBarBottomRightButton%d", i)]
				button.noGrid = nil
				button:SetAttribute("showgrid", 1)
				if ActionButton_ShowGrid then
					ActionButton_ShowGrid(button, reason)
				else
					button:SetAlpha(1)
				end
				button:SetAttribute("statehidden", true)

				button = _G[format("MultiBarLeftButton%d", i)]
				button.noGrid = nil
				button:SetAttribute("showgrid", 1)
				if ActionButton_ShowGrid then
					ActionButton_ShowGrid(button, reason)
				else
					button:SetAlpha(1)
				end
				button:SetAttribute("statehidden", true)

				button = _G[format("MultiBarBottomLeftButton%d", i)]
				button.noGrid = nil
				button:SetAttribute("showgrid", 1)
				if ActionButton_ShowGrid then
					ActionButton_ShowGrid(button, reason)
				else
					button:SetAlpha(1)
				end
				button:SetAttribute("statehidden", true)

				if T.Wrath or T.Cata then
					if _G["VehicleMenuBarActionButton"..i] then
						_G["VehicleMenuBarActionButton"..i]:SetAttribute("statehidden", true)
					end
				end
			end
		else
			SetCVar("alwaysShowActionBars", 0)
		end
	end)
else
	if not C.actionbar.show_grid then
		local allButtons = {}
		for i = 1, 12 do
			local button = _G[format("ActionButton%d", i)]
			tinsert(allButtons, button)

			local button = _G[format("MultiBarRightButton%d", i)]
			tinsert(allButtons, button)

			button = _G[format("MultiBarBottomRightButton%d", i)]
			tinsert(allButtons, button)

			button = _G[format("MultiBarLeftButton%d", i)]
			tinsert(allButtons, button)

			button = _G[format("MultiBarBottomLeftButton%d", i)]
			tinsert(allButtons, button)

			button = _G[format("MultiBar5Button%d", i)]
			tinsert(allButtons, button)

			button = _G[format("MultiBar6Button%d", i)]
			tinsert(allButtons, button)

			button = _G[format("MultiBar7Button%d", i)]
			tinsert(allButtons, button)
		end

		local frame = CreateFrame("Frame")
		frame:RegisterEvent("ACTIONBAR_SHOWGRID")
		frame:RegisterEvent("ACTIONBAR_HIDEGRID")
		frame:RegisterEvent("PLAYER_ENTERING_WORLD")
		frame:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
		frame:RegisterEvent("ACTIONBAR_UPDATE_STATE")
		frame:RegisterEvent("UPDATE_VEHICLE_ACTIONBAR")
		frame:SetScript("OnEvent", function(self, event)
			if event == "ACTIONBAR_SHOWGRID" then
				for i = 1, #allButtons do
					allButtons[i]:SetAlpha(1)
				end
			elseif event == "ACTIONBAR_PAGE_CHANGED" or event == "ACTIONBAR_UPDATE_STATE" or event == "UPDATE_VEHICLE_ACTIONBAR" then
				C_Timer.After(0.02, function()
					for i = 1, #allButtons do
						local button = allButtons[i]
						button:SetAlpha(1)
						if not button:HasAction() then
							button:SetAlpha(0)
						end
					end
				end)
			else
				C_Timer.After(0.05, function()
					for i = 1, #allButtons do
						local button = allButtons[i]
						if not button:HasAction() then
							button:SetAlpha(0)
						end
					end
				end)
			end
		end)
	end
end

----------------------------------------------------------------------------------------
--	Pet/StanceBar style functions
----------------------------------------------------------------------------------------
T.ShiftBarUpdate = function()
	local numForms = GetNumShapeshiftForms()
	local texture, isActive, isCastable
	local button, icon, cooldown
	local start, duration, enable
	for i = 1, 10 do
		button = _G["StanceButton"..i]
		icon = _G["StanceButton"..i.."Icon"]
		if i <= numForms then
			texture, isActive, isCastable = GetShapeshiftFormInfo(i)
			icon:SetTexture(texture)

			cooldown = _G["StanceButton"..i.."Cooldown"]
			if texture then
				cooldown:SetAlpha(1)
			else
				cooldown:SetAlpha(0)
			end

			start, duration, enable = GetShapeshiftFormCooldown(i)
			CooldownFrame_Set(cooldown, start, duration, enable)

			if isActive then
				if T.Classic then
					local stanceBar = _G.StanceBar or _G.StanceBarFrame
					if stanceBar then
						stanceBar.lastSelected = button:GetID()
					end
				end
				button:SetChecked(true)
			else
				button:SetChecked(false)
			end

			if isCastable then
				icon:SetVertexColor(1.0, 1.0, 1.0)
			else
				icon:SetVertexColor(0.4, 0.4, 0.4)
			end
		end
	end
end

	T.PetBarUpdate = function()
	local petActionButton, petActionIcon, petAutoCastableTexture, petAutoCastShine, petAutoCastOverlay
	for i = 1, NUM_PET_ACTION_SLOTS, 1 do
		local buttonName = "PetActionButton"..i
		petActionButton = _G[buttonName]
		if not petActionButton then return end
		petActionIcon = _G[buttonName.."Icon"]
		local name, texture, isToken, isActive, autoCastAllowed, autoCastEnabled = GetPetActionInfo(i)

		if not isToken then
			if petActionIcon then petActionIcon:SetTexture(texture) end
			petActionButton.tooltipName = name
		else
			if petActionIcon then petActionIcon:SetTexture(_G[texture]) end
			petActionButton.tooltipName = _G[name]
		end

		petActionButton.isToken = isToken

		if isActive and name ~= "PET_ACTION_FOLLOW" then
			petActionButton:SetChecked(true)
			if IsPetAttackAction(i) then
				if T.NewClassicUI then
					-- 3.80.1: use button object methods (not global functions)
					petActionButton:StartFlash()
					petActionButton:GetCheckedTexture():SetAlpha(0.5)
				elseif T.Classic then
					if PetActionButton_StartFlash then
						PetActionButton_StartFlash(petActionButton)
					end
				else
					petActionButton:StartFlash()
					petActionButton:GetCheckedTexture():SetAlpha(0.5)
				end
			end
		else
			petActionButton:SetChecked(false)
			if IsPetAttackAction(i) then
				if T.NewClassicUI then
					petActionButton:StopFlash()
					petActionButton:GetCheckedTexture():SetAlpha(1.0)
				elseif T.Classic then
					if PetActionButton_StopFlash then
						PetActionButton_StopFlash(petActionButton)
					end
				else
					petActionButton:StopFlash()
					petActionButton:GetCheckedTexture():SetAlpha(1.0)
				end
			end
		end

		-- Auto-cast handling: 3.80.1 uses AutoCastOverlay, old Classic uses AutoCastable + AutoCastShine
		if T.NewClassicUI then
			petAutoCastOverlay = petActionButton.AutoCastOverlay
			if petAutoCastOverlay then
				petAutoCastOverlay:SetShown(autoCastAllowed)
				if petAutoCastOverlay.ShowAutoCastEnabled then
					petAutoCastOverlay:ShowAutoCastEnabled(autoCastEnabled)
				end
			end
		else
			petAutoCastableTexture = petActionButton.AutoCastable or _G[buttonName.."AutoCastable"]
			petAutoCastShine = _G[buttonName.."Shine"]
			if autoCastAllowed then
				if petAutoCastableTexture then petAutoCastableTexture:Show() end
			else
				if petAutoCastableTexture then petAutoCastableTexture:Hide() end
			end
			if autoCastEnabled then
				if petAutoCastShine and AutoCastShine_AutoCastStart then
					AutoCastShine_AutoCastStart(petAutoCastShine)
				end
			else
				if petAutoCastShine and AutoCastShine_AutoCastStop then
					AutoCastShine_AutoCastStop(petAutoCastShine)
				end
			end
		end

		if name then
			if not C.actionbar.show_grid then
				petActionButton:SetAlpha(1)
			end
		else
			if not C.actionbar.show_grid then
				petActionButton:SetAlpha(0)
			end
		end

		if texture then
			if petActionIcon then
				if GetPetActionSlotUsable(i) then
					SetDesaturation(petActionIcon, nil)
				else
					SetDesaturation(petActionIcon, 1)
				end
				petActionIcon:Show()
			end
		else
			if petActionIcon then petActionIcon:Hide() end
		end

		if not PetHasActionBar() and texture and name ~= "PET_ACTION_FOLLOW" then
			if T.NewClassicUI then
				petActionButton:StopFlash()
			elseif T.Classic then
				if PetActionButton_StopFlash then
					PetActionButton_StopFlash(petActionButton)
				end
			else
				petActionButton:StopFlash()
			end
			if petActionIcon then SetDesaturation(petActionIcon, 1) end
			petActionButton:SetChecked(false)
		end
	end
end
