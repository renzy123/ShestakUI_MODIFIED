local T, C, L = unpack(ShestakUI)

----------------------------------------------------------------------------------------
--	Kill all stuff on default UI that we don't need
----------------------------------------------------------------------------------------

-- Shared hidden frame for reparenting Blizzard frames (same as NDUI's B.HiddenFrame)
-- Reparenting to a hidden frame is the most reliable way to prevent Blizzard from re-showing frames
local hiddenFrame = CreateFrame("Frame")
hiddenFrame:Hide()

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(_, _, addon)
	if addon == "Blizzard_AchievementUI" then
		if C.tooltip.enable then
			if T.Classic then
				hooksecurefunc("AchievementFrameCategories_DisplayButton", function(button) button.showTooltipFunc = nil end)
			end
		end
	end

	if ClassPowerBar then
		ClassPowerBar.OnEvent = T.dummy -- Fix error with druid on logon
	end

	if C.unitframe.enable and C.raidframe.layout ~= "BLIZZARD" then
		if T.NewClassicUI then
			-- 3.80.1 时光服: Uses Retail-style CompactUnitFrame system.
			-- Do NOT use T.dummy to overwrite globals — it taints the execution path
			-- and causes ADDON_ACTION_BLOCKED on SetSize()/SetPoint() during combat.
			-- Strategy (same as NDUI): SetParent(hiddenFrame) + UnregisterAllEvents + IsShown=0

			-- Hide raid frame manager
			if CompactRaidFrameManager then
				if not InCombatLockdown() then
					if CompactRaidFrameManager_SetSetting then
						CompactRaidFrameManager_SetSetting("IsShown", "0")
					end
					CompactRaidFrameManager:Hide()
					CompactRaidFrameManager:SetParent(hiddenFrame)
				end
				CompactRaidFrameManager:UnregisterAllEvents()
				if CompactRaidFrameContainer then
					CompactRaidFrameContainer:UnregisterAllEvents()
				end
				-- Safety hooks in case something tries to re-show
				CompactRaidFrameManager:HookScript("OnShow", function(self)
					self:UnregisterAllEvents()
					if not InCombatLockdown() then
						self:Hide()
						self:SetParent(hiddenFrame)
					end
				end)
				if CompactRaidFrameContainer then
					CompactRaidFrameContainer:HookScript("OnShow", function(self)
					self:UnregisterAllEvents()
					if not InCombatLockdown() then
						self:Hide()
					end
				end)
				end
			end

			-- Prevent UIParent from re-showing party/raid frames on group changes
			UIParent:UnregisterEvent("GROUP_ROSTER_UPDATE")

			-- 3.80.1 NewClassicUI: The party frames use Retail-style PartyFrame + PartyMemberFramePool
			-- Pool frames are created lazily, so we must hook the container's OnShow and enumerate pool
			local function KillPartyFrame()
				-- Kill the Retail-style PartyFrame container
				if PartyFrame then
					PartyFrame:UnregisterAllEvents()
					if not InCombatLockdown() then
						PartyFrame:Hide()
						PartyFrame:SetParent(hiddenFrame)
					end
					-- Kill any pool frames that already exist
					if PartyFrame.PartyMemberFramePool then
						for frame in PartyFrame.PartyMemberFramePool:EnumerateActive() do
							frame:UnregisterAllEvents()
							if not InCombatLockdown() then
								frame:Hide()
							end
						end
					end
				end
				-- Kill CompactPartyFrame + members (may coexist on 3.80.1)
				if CompactPartyFrame then
					CompactPartyFrame:UnregisterAllEvents()
					if not InCombatLockdown() then
						CompactPartyFrame:Hide()
						CompactPartyFrame:SetParent(hiddenFrame)
					end
				end
				for i = 1, MEMBERS_PER_RAID_GROUP or 5 do
					local member = _G["CompactPartyFrameMember"..i]
					if member then
						member:UnregisterAllEvents()
						if not InCombatLockdown() then
							member:Hide()
							member:SetParent(hiddenFrame)
						end
					end
				end
			end
			KillPartyFrame()

			-- Persistent hooks: prevent Blizzard from re-showing party frames
			if PartyFrame then
				PartyFrame:HookScript("OnShow", function(self)
					self:UnregisterAllEvents()
					if not InCombatLockdown() then
						self:Hide()
						self:SetParent(hiddenFrame)
					end
					-- Kill any new pool frames that may have been created
					if self.PartyMemberFramePool then
						for frame in self.PartyMemberFramePool:EnumerateActive() do
							frame:UnregisterAllEvents()
							if not InCombatLockdown() then
								frame:Hide()
							end
						end
					end
				end)
			end
			if CompactPartyFrame then
				CompactPartyFrame:HookScript("OnShow", function(self)
					self:UnregisterAllEvents()
					if not InCombatLockdown() then
						self:Hide()
						self:SetParent(hiddenFrame)
					end
				end)
			end
			for i = 1, MEMBERS_PER_RAID_GROUP or 5 do
				local member = _G["CompactPartyFrameMember"..i]
				if member then
					member:HookScript("OnShow", function(self)
						self:UnregisterAllEvents()
						if not InCombatLockdown() then
							self:Hide()
							self:SetParent(hiddenFrame)
						end
					end)
				end
			end
		elseif T.Classic then
			-- 修复：检查 InterfaceOptionsFrameCategoriesButton11 是否存在
			local interfaceButton = _G["InterfaceOptionsFrameCategoriesButton11"]
			if interfaceButton then
				interfaceButton:SetScale(0.00001)
				interfaceButton:SetAlpha(0)
			end

			if not InCombatLockdown() then
				if C.raidframe.show_raid or not IsAddOnLoaded("Grid2") then -- may need to add more addons here
					-- 修复：安全的框架隐藏
					if CompactRaidFrameManager then
						CompactRaidFrameManager:Hide()
						CompactRaidFrameManager:UnregisterAllEvents()
					end
					if CompactRaidFrameContainer then
						CompactRaidFrameContainer:Hide()
						CompactRaidFrameContainer:UnregisterAllEvents()
					end
				end
			end

			-- CAUTION: T.dummy overwrites taint execution paths on 3.80.1.
			-- Only safe on pure Classic (1.x) clients where these functions are never called during combat.
			if not T.NewClassicUI then
				ShowPartyFrame = T.dummy
				HidePartyFrame = T.dummy
				CompactUnitFrameProfiles_ApplyProfile = T.dummy
				if CompactRaidFrameManager_UpdateShown then
					CompactRaidFrameManager_UpdateShown = T.dummy
				end
				if CompactRaidFrameManager_UpdateOptionsFlowContainer then
					CompactRaidFrameManager_UpdateOptionsFlowContainer = T.dummy
				end
			end
		else
			if CompactRaidFrameManager then
				local function HideFrames()
					CompactRaidFrameManager:UnregisterAllEvents()
					CompactRaidFrameContainer:UnregisterAllEvents()
					if not InCombatLockdown() then
						CompactRaidFrameManager:Hide()
						local shown = CompactRaidFrameManager_GetSetting("IsShown")
						if shown and shown ~= "0" then
							CompactRaidFrameManager_SetSetting("IsShown", "0")
						end
					end
				end
				hooksecurefunc("CompactRaidFrameManager_UpdateShown", HideFrames)
				CompactRaidFrameManager:HookScript("OnShow", HideFrames)
				CompactRaidFrameContainer:HookScript("OnShow", HideFrames)
				HideFrames()
			end
		end
	end

	if T.Classic then
		-- 修复：安全的UI缩放选项隐藏
		local Advanced_UseUIScale = _G["Advanced_UseUIScale"]
		if Advanced_UseUIScale then
			Advanced_UseUIScale:Hide()
		end
		
		local Advanced_UIScaleSlider = _G["Advanced_UIScaleSlider"]
		if Advanced_UIScaleSlider then
			Advanced_UIScaleSlider:Hide()
		end
		
		local BagHelpBox = _G["BagHelpBox"]
		if BagHelpBox then
			BagHelpBox:Hide()
		end
	else
		TutorialFrameAlertButton:Kill()
	end
	
	SetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_WORLD_MAP_FRAME, true)
	if LE_FRAME_TUTORIAL_PET_JOURNAL then
		SetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_PET_JOURNAL, true)
	end
	if T.Mainline then
		SetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_GARRISON_BUILDING, true)
		SetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_TALENT_CHANGES, true)
	end

	SetCVar("countdownForCooldowns", 0)
	if T.Classic then
		local InterfaceOptionsActionBarsPanelCountdownCooldowns = _G["InterfaceOptionsActionBarsPanelCountdownCooldowns"]
		if InterfaceOptionsActionBarsPanelCountdownCooldowns then
			InterfaceOptionsActionBarsPanelCountdownCooldowns:Hide()
		end
	end

	if C.chat.enable then
		if T.Classic then
			local InterfaceOptionsSocialPanelChatStyle = _G["InterfaceOptionsSocialPanelChatStyle"]
			if InterfaceOptionsSocialPanelChatStyle then
				InterfaceOptionsSocialPanelChatStyle:Hide()
			end
		end
		SetCVar("chatStyle", "im")
	end

	if C.unitframe.enable then
		if T.class == "DEATHKNIGHT" and C.unitframe_class_bar.rune ~= true then
			if RuneFrame then
				RuneFrame:Hide()
				RuneFrame:UnregisterAllEvents()
			end
		end
		if T.Classic then
			-- 修复：安全的界面选项隐藏
			local InterfaceOptionsDisplayPanelDisplayDropDown = _G["InterfaceOptionsDisplayPanelDisplayDropDown"]
			if InterfaceOptionsDisplayPanelDisplayDropDown then
				InterfaceOptionsDisplayPanelDisplayDropDown:Hide()
			end
			
			local InterfaceOptionsCombatPanelTargetOfTarget = _G["InterfaceOptionsCombatPanelTargetOfTarget"]
			if InterfaceOptionsCombatPanelTargetOfTarget then
				InterfaceOptionsCombatPanelTargetOfTarget:Hide()
			end
		end
		SetCVar("showPartyBackground", 0)

		-- 3.80.1 NewClassicUI: Force compact party frames mode for consistent hiding
		if T.NewClassicUI then
			SetCVar("useCompactPartyFrames", 1)
		end

		-- 3.80.1 NewClassicUI: Hide default Blizzard casting bars with persistent hooks.
		-- The oUF CastBar element handles CastBarFrame/CastingBarFrame_SetUnit,
		-- but PlayerCastingBarFrame (Retail-style) may also exist and re-show itself.
		if T.NewClassicUI then
			local function KillCastBar(frame)
				if not frame then return end
				frame:UnregisterAllEvents()
				frame:Hide()
				if frame.HookScript then
					frame:HookScript("OnShow", function(self)
						self:UnregisterAllEvents()
						self:Hide()
					end)
				end
			end
			KillCastBar(CastingBarFrame)
			KillCastBar(PlayerCastingBarFrame)
			KillCastBar(PetCastingBarFrame)
		end
	end

	if C.actionbar.enable then
		if T.Classic then
			-- 修复：安全的动作条选项隐藏
			local InterfaceOptionsActionBarsPanelBottomLeft = _G["InterfaceOptionsActionBarsPanelBottomLeft"]
			if InterfaceOptionsActionBarsPanelBottomLeft then
				InterfaceOptionsActionBarsPanelBottomLeft:Hide()
			end
			
			local InterfaceOptionsActionBarsPanelBottomRight = _G["InterfaceOptionsActionBarsPanelBottomRight"]
			if InterfaceOptionsActionBarsPanelBottomRight then
				InterfaceOptionsActionBarsPanelBottomRight:Hide()
			end
			
			local InterfaceOptionsActionBarsPanelRight = _G["InterfaceOptionsActionBarsPanelRight"]
			if InterfaceOptionsActionBarsPanelRight then
				InterfaceOptionsActionBarsPanelRight:Hide()
			end
			
			local InterfaceOptionsActionBarsPanelRightTwo = _G["InterfaceOptionsActionBarsPanelRightTwo"]
			if InterfaceOptionsActionBarsPanelRightTwo then
				InterfaceOptionsActionBarsPanelRightTwo:Hide()
			end
			
			local InterfaceOptionsActionBarsPanelAlwaysShowActionBars = _G["InterfaceOptionsActionBarsPanelAlwaysShowActionBars"]
			if InterfaceOptionsActionBarsPanelAlwaysShowActionBars then
				InterfaceOptionsActionBarsPanelAlwaysShowActionBars:Hide()
			end
			
			local InterfaceOptionsActionBarsPanelStackRightBars = _G["InterfaceOptionsActionBarsPanelStackRightBars"]
			if InterfaceOptionsActionBarsPanelStackRightBars then
				InterfaceOptionsActionBarsPanelStackRightBars:Hide()
			end
			
			if not InCombatLockdown() then
				SetCVar("multiBarRightVerticalLayout", 0)
			end
		end
	end

	if C.nameplate.enable then
		SetCVar("ShowClassColorInNameplate", 1)
	end

	if C.minimap.enable then
		if T.Classic then
			local InterfaceOptionsDisplayPanelRotateMinimap = _G["InterfaceOptionsDisplayPanelRotateMinimap"]
			if InterfaceOptionsDisplayPanelRotateMinimap then
				InterfaceOptionsDisplayPanelRotateMinimap:Hide()
			end
		else
			SetCVar("minimapTrackingShowAll", 1)
		end
	end

	if C.bag.enable then
		C_Container.SetInsertItemsLeftToRight(false)
		if T.Mainline then
			C_Container.SetSortBagsRightToLeft(true)
		end
	end

	if C.combattext.enable then
		if T.Classic then
			local InterfaceOptionsCombatPanelEnableFloatingCombatText = _G["InterfaceOptionsCombatPanelEnableFloatingCombatText"]
			if InterfaceOptionsCombatPanelEnableFloatingCombatText then
				InterfaceOptionsCombatPanelEnableFloatingCombatText:Hide()
			end
		end
		if C.combattext.incoming then
			SetCVar("enableFloatingCombatText", 1)
		else
			SetCVar("enableFloatingCombatText", 0)
		end
	end
end)

if T.Mainline then
	local function AcknowledgeTips()
		if InCombatLockdown() then return end

		for frame in _G.HelpTip.framePool:EnumerateActive() do
			frame:Acknowledge()
		end
	end

	AcknowledgeTips()
	hooksecurefunc(_G.HelpTip, "Show", AcknowledgeTips)
end