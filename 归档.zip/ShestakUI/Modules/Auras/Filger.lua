local T, C, L, _ = unpack(ShestakUI)
if C.unitframe.enable ~= true or C.filger.enable ~= true then return end
if T.Midnight then return end
----------------------------------------------------------------------------------------
--	Lightweight buff/debuff tracking (Filger by Nils Ruesch, editors Affli/SinaC/Ildyria)
----------------------------------------------------------------------------------------
P_BUFF_ICON_Anchor:SetPoint(unpack(C.position.filger.player_buff_icon))
P_BUFF_ICON_Anchor:SetSize(C.filger.buffs_size, C.filger.buffs_size)

P_PROC_ICON_Anchor:SetPoint(unpack(C.position.filger.player_proc_icon))
P_PROC_ICON_Anchor:SetSize(C.filger.buffs_size, C.filger.buffs_size)

SPECIAL_P_BUFF_ICON_Anchor:SetPoint(unpack(C.position.filger.special_proc_icon))
SPECIAL_P_BUFF_ICON_Anchor:SetSize(C.filger.buffs_size, C.filger.buffs_size)

T_DEBUFF_ICON_Anchor:SetPoint(unpack(C.position.filger.target_debuff_icon))
T_DEBUFF_ICON_Anchor:SetSize(C.filger.buffs_size, C.filger.buffs_size)

T_CC_Anchor:SetPoint(unpack(C.position.filger.target_buff_icon))
T_CC_Anchor:SetSize(C.filger.pvp_size, C.filger.pvp_size)

T_BUFF_Anchor:SetPoint("LEFT", T_CC_Anchor, "LEFT", C.filger.pvp_size + 3, 0)
T_BUFF_Anchor:SetSize(C.filger.pvp_size, C.filger.pvp_size)

PVE_PVP_DEBUFF_Anchor:SetPoint(unpack(C.position.filger.pve_debuff))
PVE_PVP_DEBUFF_Anchor:SetSize(C.filger.pvp_size, C.filger.pvp_size)

FOCUS_CC_Anchor:SetPoint(unpack(C.position.filger.focus_cc))
FOCUS_CC_Anchor:SetSize(221, 25)

COOLDOWN_Anchor:SetPoint(C.position.filger.cooldown[1], C.position.filger.cooldown[2], C.position.filger.cooldown[3], C.position.filger.cooldown[4], C.unitframe.plugins_swing and C.position.filger.cooldown[5] + 12 or C.position.filger.cooldown[5])
COOLDOWN_Anchor:SetSize(C.filger.cooldown_size, C.filger.cooldown_size)

local IsPortrait = C.unitframe.portrait_enable and C.unitframe.portrait_type ~= "OVERLAY"

T_DE_BUFF_BAR_Anchor:SetPoint(C.position.filger.target_bar[1], IsPortrait and "oUF_Target_Portrait" or C.position.filger.target_bar[2], C.position.filger.target_bar[3], IsPortrait and C.position.filger.target_bar[4] - 3 or C.position.filger.target_bar[4], IsPortrait and C.position.filger.target_bar[5] + 38 or C.position.filger.target_bar[5])
T_DE_BUFF_BAR_Anchor:SetSize(218, 25)

P_BUFF_BAR_Anchor:SetPoint(C.position.filger.player_bar[1], IsPortrait and "oUF_Player_Portrait" or C.position.filger.player_bar[2], C.position.filger.player_bar[3], IsPortrait and C.position.filger.player_bar[4] + 3 or C.position.filger.player_bar[4], IsPortrait and C.position.filger.player_bar[5] + 38 or C.position.filger.player_bar[5])
P_BUFF_BAR_Anchor:SetSize(218, 25)

SpellActivationOverlayFrame:SetFrameStrata("BACKGROUND")

local SPELL_HOLDER = 100

C["filger_spells"] = {
	["ALL"] = {
		{
			Name = "P_BUFF_ICON",
			Direction = "LEFT",
			Mode = "ICON",
			Interval = C.filger.buffs_space,
			Alpha = 1,
			IconSize = C.filger.buffs_size,
			Position = {"TOP", P_BUFF_ICON_Anchor},
			Filter = "HELPFUL|PLAYER|RAID_IN_COMBAT",
			FilterExclude = {"HELPFUL|BIG_DEFENSIVE", "HELPFUL|EXTERNAL_DEFENSIVE"},
			Unit = "player",

			-- Player buffs
			{spellID = SPELL_HOLDER, unitID = "player", caster = "player", filter = "BUFF"},
		},
		-- {
			-- Name = "T_DEBUFF_ICON",
			-- Direction = "RIGHT",
			-- Mode = "ICON",
			-- Interval = C.filger.buffs_space,
			-- Alpha = 1,
			-- IconSize = C.filger.buffs_size,
			-- Position = {"TOP", T_DEBUFF_ICON_Anchor},
			-- Filter = "HARMFUL|PLAYER",
			-- FilterExclude = {"HARMFUL|CROWD_CONTROL"},
			-- Unit = "target",

			-- -- Player debuffs on target
			-- {spellID = SPELL_HOLDER, unitID = "target", caster = "player", filter = "DEBUFF"},
		-- },
		-- {
			-- Name = "T_DE/BUFF_BAR",
			-- Direction = "UP",
			-- IconSide = "LEFT",
			-- Mode = "BAR",
			-- Interval = 3,
			-- Alpha = 1,
			-- IconSize = 25,
			-- BarWidth = 186,
			-- Position = {"LEFT", T_DE_BUFF_BAR_Anchor},
			-- Filter = "HELPFUL|PLAYER|RAID_IN_COMBAT",
			-- Unit = "target",

			-- -- Player hots on target
			-- {spellID = SPELL_HOLDER, unitID = "target", caster = "player", filter = "BUFF"},
		-- },
		{
			Name = "FOCUS_CC",
			Direction = "DOWN",
			IconSide = "LEFT",
			Mode = "BAR",
			Interval = 3,
			Alpha = 1,
			IconSize = 25,
			BarWidth = 189,
			Position = {"LEFT", FOCUS_CC_Anchor},
			Filter = "HARMFUL|CROWD_CONTROL",
			Unit = "focus",

			-- Crowd Controls on focus
			{spellID = SPELL_HOLDER, unitID = "focus", caster = "player", filter = "DEBUFF"},
		},
		{
			Name = "SPECIAL_P_BUFF_ICON",
			Direction = "LEFT",
			Mode = "ICON",
			Interval = C.filger.buffs_space,
			Alpha = 1,
			IconSize = C.filger.buffs_size,
			Position = {"TOP", SPECIAL_P_BUFF_ICON_Anchor},
			Filter = "HELPFUL",
			FilterInclude = {"HELPFUL|BIG_DEFENSIVE", "HELPFUL|EXTERNAL_DEFENSIVE"},
			Unit = "player",

			-- Defensive spells
			{spellID = SPELL_HOLDER, unitID = "player", caster = "player", filter = "BUFF"},
		},
		-- {
			-- Name = "P_BUFF_BAR",
			-- Direction = "UP",
			-- IconSide = "RIGHT",
			-- Mode = "BAR",
			-- Interval = 3,
			-- Alpha = 1,
			-- IconSize = 25,
			-- BarWidth = 186,
			-- Position = {"RIGHT", P_BUFF_BAR_Anchor},
			-- -- Filter = "HARMFUL|CROWD_CONTROL",
			-- Unit = "player",

			-- -- Spell holder to enable this section
			-- {spellID = SPELL_HOLDER, unitID = "player", caster = "all", filter = "BUFF"},
		-- },
		{
			Name = "PVE/PVP_DEBUFF",
			Direction = "UP",
			Mode = "ICON",
			Interval = C.filger.pvp_space,
			Alpha = 1,
			IconSize = C.filger.pvp_size,
			Position = {"TOP", PVE_PVP_DEBUFF_Anchor},
			Filter = "HARMFUL|CROWD_CONTROL",
			Unit = "player",

			-- Crowd Controls
			{spellID = SPELL_HOLDER, unitID = "player", caster = "all", filter = "DEBUFF"},
		},
		{
			Name = "T_CC",
			Direction = "UP",
			Mode = "ICON",
			Interval = C.filger.pvp_space,
			Alpha = 1,
			IconSize = C.filger.pvp_size,
			Position = {"TOP", T_CC_Anchor},
			Filter = "HARMFUL|CROWD_CONTROL",
			Unit = "target",

			-- Crowd Controls on target
			{spellID = SPELL_HOLDER, unitID = "target", caster = "all", filter = "DEBUFF"},
		},
		{
			Name = "T_BUFF",
			Direction = "UP",
			Mode = "ICON",
			Interval = C.filger.pvp_space,
			Alpha = 1,
			IconSize = C.filger.pvp_size,
			Position = {"TOP", T_BUFF_Anchor},
			Filter = "HELPFUL",
			FilterInclude = {"HELPFUL|BIG_DEFENSIVE", "HELPFUL|EXTERNAL_DEFENSIVE"},
			Unit = "target",

			-- Defensive spells on target
			{spellID = SPELL_HOLDER, unitID = "target", caster = "all", filter = "BUFF"},
		},
	},
}

if C.filger.show_aura_bar and (T.class == "PRIEST" or T.class == "WARLOCK") then
	tinsert(C["filger_spells"]["ALL"],
		{
			Name = "T_DEBUFF_ICON",
			Direction = "RIGHT",
			Mode = "ICON",
			Interval = C.filger.buffs_space,
			Alpha = 1,
			IconSize = C.filger.buffs_size,
			Position = {"TOP", T_DEBUFF_ICON_Anchor},
			Filter = "HELPFUL|PLAYER|RAID_IN_COMBAT",
			Unit = "target",

			-- Player hots on target
			{spellID = SPELL_HOLDER, unitID = "target", caster = "player", filter = "DEBUFF"},
		}
	)
	tinsert(C["filger_spells"]["ALL"],
		{
			Name = "T_DE/BUFF_BAR",
			Direction = "UP",
			IconSide = "LEFT",
			Mode = "BAR",
			Interval = 3,
			Alpha = 1,
			IconSize = 25,
			BarWidth = 186,
			Position = {"LEFT", T_DE_BUFF_BAR_Anchor},
			Filter = "HARMFUL|PLAYER",
			FilterExclude = {"HARMFUL|CROWD_CONTROL"},
			Unit = "target",

			-- Player debuffs on target
			{spellID = SPELL_HOLDER, unitID = "target", caster = "player", filter = "BUFF"},
		}
	)
else
	tinsert(C["filger_spells"]["ALL"],
		{
			Name = "T_DEBUFF_ICON",
			Direction = "RIGHT",
			Mode = "ICON",
			Interval = C.filger.buffs_space,
			Alpha = 1,
			IconSize = C.filger.buffs_size,
			Position = {"TOP", T_DEBUFF_ICON_Anchor},
			Filter = "HARMFUL|PLAYER",
			FilterExclude = {"HARMFUL|CROWD_CONTROL"},
			Unit = "target",

			-- Player debuffs on target
			{spellID = SPELL_HOLDER, unitID = "target", caster = "player", filter = "DEBUFF"},
		}
	)
	tinsert(C["filger_spells"]["ALL"],
		{
			Name = "T_DE/BUFF_BAR",
			Direction = "UP",
			IconSide = "LEFT",
			Mode = "BAR",
			Interval = 3,
			Alpha = 1,
			IconSize = 25,
			BarWidth = 186,
			Position = {"LEFT", T_DE_BUFF_BAR_Anchor},
			Filter = "HELPFUL|PLAYER|RAID_IN_COMBAT",
			Unit = "target",

			-- Player hots on target
			{spellID = SPELL_HOLDER, unitID = "target", caster = "player", filter = "BUFF"},
		}
	)
end

if not C["filger_spells"][T.class] then
	C["filger_spells"][T.class] = C["filger_spells"]["ALL"]
end

-- Cache
local GetTime, GetSpellCooldown, GetSpellInfo = GetTime, GetSpellCooldown, GetSpellInfo
local pairs, ipairs, unpack, format = pairs, ipairs, unpack, string.format

local Filger = {}
local MyUnits = {player = true, vehicle = true, pet = true}
local SpellGroups = {}
local tempActiveTable = {}

function Filger:TooltipOnEnter()
	GameTooltip:ClearLines()
	GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT", 0, 3)
	GameTooltip:SetUnitAuraByAuraInstanceID(self.unit, self.spellID)
	GameTooltip:Show()
end

function Filger:TooltipOnLeave()
	GameTooltip:Hide()
end

function Filger:UpdateCD()
	self.time:SetFormattedText("%.1f", self.duration:GetRemainingDuration())
end

function Filger:DisplayActives()
	if not self.actives then return end
	if not self.bars then self.bars = {} end
	local id = self.Id
	local index = 1
	local previous = nil
	wipe(tempActiveTable)

	for _, value in pairs(self.actives) do
		local bar = self.bars[index]
		if not bar then
			bar = CreateFrame("Frame", "FilgerAnchor"..id.."Frame"..index, self)
			bar:SetScale(1)
			bar:SetTemplate("Default")

			if index == 1 then
				bar:SetPoint(unpack(self.Position))
			else
				if self.Direction == "UP" then
					bar:SetPoint("BOTTOM", previous, "TOP", 0, self.Interval)
				elseif self.Direction == "RIGHT" then
					bar:SetPoint("LEFT", previous, "RIGHT", self.Mode == "ICON" and self.Interval or (self.BarWidth + self.Interval + 7), 0)
				elseif self.Direction == "LEFT" then
					bar:SetPoint("RIGHT", previous, "LEFT", self.Mode == "ICON" and -self.Interval or -(self.BarWidth + self.Interval + 7), 0)
				else
					bar:SetPoint("TOP", previous, "BOTTOM", 0, -self.Interval)
				end
			end

			if not bar.icon then
				bar.icon = bar:CreateTexture("$parentIcon", "BORDER")
				bar.icon:SetPoint("TOPLEFT", 2, -2)
				bar.icon:SetPoint("BOTTOMRIGHT", -2, 2)
				bar.icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
			end

			if self.Mode == "ICON" then
				if not bar.cooldown then
					bar.cooldown = CreateFrame("Cooldown", "$parentCD", bar, "CooldownFrameTemplate")
					bar.cooldown:SetAllPoints(bar.icon)
					bar.cooldown:SetReverse(true)
					bar.cooldown:SetDrawEdge(false)
					bar.cooldown:SetFrameLevel(3)
					T.SkinCooldown(bar.cooldown, "actionbar")
					bar.cooldown:SetSwipeColor(0, 0, 0, 0.5)
				end

				if not bar.count then
					bar.count = bar:CreateFontString("$parentCount", "OVERLAY")
					bar.count:SetFont(C.font.cooldown_timers_font, C.font.cooldown_timers_font_size, C.font.cooldown_timers_font_style)
					bar.count:SetShadowOffset(C.font.cooldown_timers_font_shadow and 1 or 0, C.font.cooldown_timers_font_shadow and -1 or 0)
					bar.count:SetPoint("BOTTOMRIGHT", 1, -2)
					bar.count:SetJustifyH("RIGHT")
				end
			else
				if not bar.statusbar then
					bar.statusbar = CreateFrame("StatusBar", "$parentStatusBar", bar)
					bar.statusbar:SetWidth(self.BarWidth)
					bar.statusbar:SetHeight(self.IconSize - 10)
					bar.statusbar:SetStatusBarTexture(C.media.texture)
					bar.statusbar:SetStatusBarColor(T.color.r, T.color.g, T.color.b, 1)
					if self.IconSide == "LEFT" then
						bar.statusbar:SetPoint("BOTTOMLEFT", bar, "BOTTOMRIGHT", 5, 2)
					elseif self.IconSide == "RIGHT" then
						bar.statusbar:SetPoint("BOTTOMRIGHT", bar, "BOTTOMLEFT", -5, 2)
					end
				end
				bar.statusbar:SetMinMaxValues(0, 1)
				bar.statusbar:SetValue(0)

				if not bar.bg then
					bar.bg = CreateFrame("Frame", "$parentBG", bar.statusbar)
					bar.bg:SetPoint("TOPLEFT", -2, 2)
					bar.bg:SetPoint("BOTTOMRIGHT", 2, -2)
					bar.bg:SetFrameStrata("BACKGROUND")
					bar.bg:SetTemplate("Default")
				end

				if not bar.background then
					bar.background = bar.statusbar:CreateTexture(nil, "BACKGROUND")
					bar.background:SetAllPoints()
					bar.background:SetTexture(C.media.texture)
					bar.background:SetVertexColor(T.color.r, T.color.g, T.color.b, 0.2)
				end

				if not bar.time then
					bar.time = bar.statusbar:CreateFontString("$parentTime", "OVERLAY")
					bar.time:SetFont(C.font.filger_font, C.font.filger_font_size, C.font.filger_font_style)
					bar.time:SetShadowOffset(C.font.filger_font_shadow and 1 or 0, C.font.filger_font_shadow and -1 or 0)
					bar.time:SetPoint("RIGHT", bar.statusbar, 0, 0)
					bar.time:SetJustifyH("RIGHT")
				end

				if not bar.count then
					bar.count = bar:CreateFontString("$parentCount", "OVERLAY")
					bar.count:SetFont(C.font.filger_font, C.font.filger_font_size, C.font.filger_font_style)
					bar.count:SetShadowOffset(C.font.filger_font_shadow and 1 or 0, C.font.filger_font_shadow and -1 or 0)
					bar.count:SetPoint("BOTTOMRIGHT", 1, 0)
					bar.count:SetJustifyH("RIGHT")
				end

				if not bar.spellname then
					bar.spellname = bar.statusbar:CreateFontString("$parentSpellName", "OVERLAY")
					bar.spellname:SetFont(C.font.filger_font, C.font.filger_font_size, C.font.filger_font_style)
					bar.spellname:SetShadowOffset(C.font.filger_font_shadow and 1 or 0, C.font.filger_font_shadow and -1 or 0)
					bar.spellname:SetPoint("LEFT", bar.statusbar, 2, 0)
					bar.spellname:SetPoint("RIGHT", bar.time, "LEFT")
					bar.spellname:SetJustifyH("LEFT")
				end
			end
			bar.spellID = 0
			self.bars[index] = bar
		end
		previous = bar
		index = index + 1
		table.insert(tempActiveTable, value)
	end

	-- local function sortTable(a, b)
		-- if C.filger.expiration and a.data.filter == "CD" then
			-- return (a.start + a.duration) < (b.start + b.duration)
		-- else
			-- return a.sort < b.sort
		-- end
	-- end
	-- table.sort(tempActiveTable, sortTable)

	local iconSize = self.IconSize or C.filger.buffs_size
	local limit = (C.actionbar.button_size * 12) / iconSize

	index = 1
	for activeIndex, value in pairs(tempActiveTable) do
		if activeIndex >= limit then
			break
		end
		local bar = self.bars[index]
		bar.spellName = GetSpellInfo(value.spid)
		if self.Mode == "BAR" then
			bar.spellname:SetText(bar.spellName)
		end
		bar.icon:SetTexture(value.icon)
		if value.count then
			bar.count:SetText(C_UnitAuras.GetAuraApplicationDisplayCount(value.unit, value.auraInstanceID, 2, 999))
		else
			bar.count:SetText()
		end
		if value.duration then
			if self.Mode == "ICON" then
				if value.unit and value.auraInstanceID then
					local duration = C_UnitAuras.GetAuraDuration(value.unit, value.auraInstanceID)
					if duration then
						bar.cooldown:SetCooldownFromDurationObject(duration)
						bar.cooldown:Show()
					else
						bar.cooldown:Hide()
					end
				end

				-- if value.start + value.duration - GetTime() > 0.3 then
					-- bar.cooldown:SetCooldown(value.start, value.duration)
				-- end
				-- if value.data.filter == "CD" or value.data.filter == "ICD" then
					-- bar.value = value
					-- bar:SetScript("OnUpdate", Filger.UpdateCD)
				-- else
					-- bar:SetScript("OnUpdate", nil)
				-- end
				-- bar.cooldown:Show()
			else
				local duration = C_UnitAuras.GetAuraDuration(value.unit, value.auraInstanceID)
				if duration then
					bar.statusbar:SetTimerDuration(duration, Enum.StatusBarInterpolation.Immediate, Enum.StatusBarTimerDirection.RemainingTime)
					bar.duration = duration
					bar:SetScript("OnUpdate", Filger.UpdateCD)
				else
					bar:SetScript("OnUpdate", nil)
				end
			end
		else
			if self.Mode == "ICON" then
				bar.cooldown:Hide()
			else
				bar.statusbar:SetMinMaxValues(0, 1)
				bar.statusbar:SetValue(1)
				bar.time:SetText("")
			end
			bar:SetScript("OnUpdate", nil)
		end
		bar.spellID = value.auraInstanceID
		if C.filger.show_tooltip then
			bar.unit = self.Unit
			bar:EnableMouse(true)
			bar:SetScript("OnEnter", Filger.TooltipOnEnter)
			bar:SetScript("OnLeave", Filger.TooltipOnLeave)
		end
		bar:SetSize(iconSize, iconSize)
		bar:SetAlpha(value.data.opacity or 1)
		bar:Show()
		index = index + 1
	end

	for i = index, #self.bars, 1 do
		local bar = self.bars[i]
		bar:Hide()
	end
end

local function checkFilters(self, unit, auraInstanceID)
	if self.FilterInclude then
		for i = 1, #self.FilterInclude do
			local filter = self.FilterInclude[i]
			local shown = not C_UnitAuras.IsAuraFilteredOutByInstanceID(unit, auraInstanceID, filter)
			return shown -- if not found then hide aura
		end
	elseif self.FilterExclude then
		for i = 1, #self.FilterExclude do
			local filter = self.FilterExclude[i]
			local shown = not C_UnitAuras.IsAuraFilteredOutByInstanceID(unit, auraInstanceID, filter)
			if shown then
				return false -- if not found then allow aura
			end
		end
	end

	return true
end

local function FindAuras(self, unit)
	for spid in pairs(self.actives) do
		if self.actives[spid].data.filter ~= "CD" and self.actives[spid].data.filter ~= "ICD" and self.actives[spid].data.unitID == unit then
			self.actives[spid] = nil
		end
	end

	if unit == self.Unit then
		for i, auraData in ipairs(C_UnitAuras.GetUnitAuras(unit, self.Filter, 6, Enum.UnitAuraSortRule.Expiration)) do
			if auraData and auraData.auraInstanceID then
				local allow = checkFilters(self, unit, auraData.auraInstanceID)
				local spell_name = GetSpellInfo(SPELL_HOLDER)
				local data = SpellGroups[self.Id].spells[spell_name] or SpellGroups[self.Id].spells[SPELL_HOLDER]
				if data and allow then
					self.actives[i] = {data = data, unit = unit, auraData = auraData, auraInstanceID = auraData.auraInstanceID, name = auraData.name, icon = auraData.icon, count = auraData.applications, duration = auraData.duration, spid = auraData.spellId}
				end
			end
		end
	end

	Filger.DisplayActives(self)
end

function Filger:OnEvent(event, ...)
	if event == "UNIT_AURA" then
		local unit = ...
		if unit == "player" or unit == "target" or unit == "pet" or unit == "focus" then
			FindAuras(self, unit)
		end
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
		local unit, _, castID = ...
		if unit == "player" then
			local name, _, icon = GetSpellInfo(castID)
			local data = SpellGroups[self.Id].spells[name]
			if data and data.filter == "ICD" and data.trigger == "NONE" and (not data.spec or data.spec == T.Spec) then
				local start, duration = GetTime(), data.duration
				if data.totem then
					local haveTotem, _, startTime, durationTime = GetTotemInfo(1)
					if canaccessvalue(haveTotem) and haveTotem or startTime then
						if canaccessvalue(durationTime) then
							start, duration = startTime, durationTime
						end
					end
				end
				self.actives[data.spellID] = {data = data, name = name, icon = icon, count = nil, start = start, duration = duration, spid = data.spellID, sort = data.sort}
				Filger.DisplayActives(self)
			end
		end
	elseif event == "PLAYER_TARGET_CHANGED" then
		FindAuras(self, "target")
	elseif event == "PLAYER_FOCUS_CHANGED" then
		FindAuras(self, "focus")
	elseif event == "PLAYER_ENTERING_WORLD" or event == "SPELL_UPDATE_COOLDOWN" then
		if event == "PLAYER_ENTERING_WORLD" then
			local _, instanceType = IsInInstance()
			if instanceType == "raid" or instanceType == "pvp" then
				if self:IsEventRegistered("UNIT_AURA") then
					self:UnregisterEvent("UNIT_AURA")
					self:SetScript("OnUpdate", function(timer, elapsed)
						timer.elapsed = (timer.elapsed or 0) + elapsed
						if timer.elapsed < 0.1 then return end
						timer.elapsed = 0
						for spid in pairs(self.actives) do
							if self.actives[spid].data.filter ~= "CD" and self.actives[spid].data.filter ~= "ICD" then
								self.actives[spid] = nil
							end
						end
						FindAuras(self, "player")
						if UnitExists("target") then
							FindAuras(self, "target")
						end
						if UnitExists("pet") then
							FindAuras(self, "pet")
						end
						if UnitExists("focus") then
							FindAuras(self, "focus")
						end
					end)
				end
			else
				if self:GetScript("OnUpdate") then
					self:SetScript("OnUpdate", nil)
					self:RegisterEvent("UNIT_AURA")
				end
			end

			for spid in pairs(self.actives) do
				if self.actives[spid].data.filter ~= "CD" and self.actives[spid].data.filter ~= "ICD" then
					self.actives[spid] = nil
				end
			end
			FindAuras(self, "player")
			if UnitExists("pet") then
				FindAuras(self, "pet")
			end
		elseif event == "SPELL_UPDATE_COOLDOWN" then
			-- for spid in pairs(self.actives) do
				-- if self.actives[spid].data.filter == "CD" then
					-- self.actives[spid] = nil
				-- end
			-- end
		end

		-- for i = 1, #C["filger_spells"][T.class][self.Id], 1 do
			-- local data = C["filger_spells"][T.class][self.Id][i]

			-- if data.filter == "CD" and (not data.spec or data.spec == T.Spec) then
				-- local name, icon, start, duration, spid
				-- if data.spellID then
					-- name, _, icon = GetSpellInfo(data.spellID)
					-- if name then
						-- if data.absID then
							-- start, duration = GetSpellCooldown(data.spellID)
						-- else
							-- start, duration = GetSpellCooldown(name)
						-- end
						-- spid = data.spellID
					-- end
				-- elseif data.slotID then
					-- spid = data.slotID
					-- local slotLink = GetInventoryItemLink("player", data.slotID)
					-- if slotLink then
						-- name, _, _, _, _, _, _, _, _, icon = C_Item.GetItemInfo(slotLink)
						-- start, duration = GetInventoryItemCooldown("player", data.slotID)
					-- end
				-- end
				-- if name and canaccessvalue(duration) and (duration or 0) > 1.9 and duration < 900 then
					-- if not (T.class == "DEATHKNIGHT" and data.filter == "CD" and duration < 10) then -- Filter rune cd
						-- self.actives[spid] = {data = data, name = name, icon = icon, count = nil, start = start, duration = duration, spid = spid, sort = data.sort}
					-- end
				-- end
			-- end
		-- end

		Filger.DisplayActives(self)
	end
end

if C["filger_spells"] and C["filger_spells"]["ALL"] then
	if not C["filger_spells"][T.class] then
		C["filger_spells"][T.class] = {}
	end

	for i = 1, #C["filger_spells"]["ALL"], 1 do
		local merge = false
		local spellListAll = C["filger_spells"]["ALL"][i]
		local spellListClass = nil
		for j = 1, #C["filger_spells"][T.class], 1 do
			spellListClass = C["filger_spells"][T.class][j]
			local mergeAll = spellListAll.Merge or false
			local mergeClass = spellListClass.Merge or false
			if spellListClass.Name == spellListAll.Name and (mergeAll or mergeClass) then
				merge = true
				break
			end
		end
		if not merge or not spellListClass then
			table.insert(C["filger_spells"][T.class], C["filger_spells"]["ALL"][i])
		else
			for j = 1, #spellListAll, 1 do
				table.insert(spellListClass, spellListAll[j])
			end
		end
	end
end

T.CustomFilgerSpell = T.CustomFilgerSpell or {}
T.FilgerIgnoreSpell = T.FilgerIgnoreSpell or {}

if C["filger_spells"] and C["filger_spells"][T.class] then
	for class in pairs(C["filger_spells"]) do
		if class ~= T.class then
			C["filger_spells"][class] = nil
		end
	end

	local idx = {}
	for i = 1, #C["filger_spells"][T.class], 1 do
		local jdx = {}
		local data = C["filger_spells"][T.class][i]
		local group = {spells = {}}

		for _, import in pairs(T.CustomFilgerSpell) do
			if data.Name == import[1] then
				tinsert(data, import[2])
			end
		end

		for j = 1, #data, 1 do
			local name
			if data[j].spellID then
				name = GetSpellInfo(data[j].spellID)
			else
				local slotLink = GetInventoryItemLink("player", data[j].slotID)
				if slotLink then
					name = C_Item.GetItemInfo(slotLink)
				end
			end
			if name or data[j].slotID then
				if T.FilgerIgnoreSpell[name] and not data[j].custom then
					table.insert(jdx, j)
				else
					local info = data[j].spellID and C_Spell.GetSpellInfo(data[j].spellID)
					local id = data[j].absID and data[j].spellID or (info and info.name) or data[j].slotID
					data[j].sort = j
					group.spells[id] = data[j]
				end
			end
			if not name and not data[j].slotID then
				print("|cffff0000ShestakUI: Filger spell ID ["..(data[j].spellID or data[j].slotID or "UNKNOWN").."] no longer exists!|r")
				table.insert(jdx, j)
			end
		end

		for _, v in ipairs(jdx) do
			table.remove(data, v)
		end

		group.data = data
		table.insert(SpellGroups, i, group)

		if #data == 0 then
			-- print("|cffff0000ShestakUI: Filger section ["..data.Name.."] is empty! Report this to Shestak.|r")
			table.insert(idx, i)
		end
	end

	for _, v in ipairs(idx) do
		table.remove(C["filger_spells"][T.class], v)
	end

	local isEnabled = {
		["P_BUFF_ICON"] = C.filger.show_buff,
		-- ["P_PROC_ICON"] = C.filger.show_proc,
		["T_DEBUFF_ICON"] = C.filger.show_debuff,
		["T_DE/BUFF_BAR"] = C.filger.show_aura_bar,
		-- ["P_BUFF_BAR"] = C.filger.show_aura_bar,
		["FOCUS_CC"] = C.filger.show_aura_bar,
		["SPECIAL_P_BUFF_ICON"] = C.filger.show_special,
		["PVE/PVP_DEBUFF"] = C.filger.show_pvp_player,
		["T_CC"] = C.filger.show_pvp_target,
		["T_BUFF"] = C.filger.show_pvp_target,
		-- ["COOLDOWN"] = C.filger.show_cd,
	}

	for i = 1, #SpellGroups, 1 do
		local data = SpellGroups[i].data
		if isEnabled[data.Name] then
			local frame = CreateFrame("Frame", "FilgerFrame"..i.."_"..data.Name, T_PetBattleFrameHider)
			frame.Id = i
			frame.Name = data.Name
			frame.Direction = data.Direction or "DOWN"
			frame.IconSide = data.IconSide or "LEFT"
			frame.Mode = data.Mode or "ICON"
			frame.Interval = data.Interval or 3
			frame:SetAlpha(data.Alpha or 1)
			frame.IconSize = data.IconSize or C.filger.buffs_size
			frame.BarWidth = data.BarWidth or 186
			frame.Position = data.Position or "CENTER"
			frame:SetPoint(unpack(data.Position))
			frame.Filter = data.Filter or ""
			frame.FilterInclude = data.FilterInclude
			frame.FilterExclude = data.FilterExclude
			frame.Unit = data.Unit or "player"
			frame.actives = {}

			if C.filger.test_mode then
				frame.actives = {}
				for j = 1, math.min(C.filger.max_test_icon, #C["filger_spells"][T.class][i]), 1 do
					local data = C["filger_spells"][T.class][i][j]
					local name, icon
					if data.spellID then
						name, _, icon = GetSpellInfo(data.spellID)
					elseif data.slotID then
						local slotLink = GetInventoryItemLink("player", data.slotID)
						if slotLink then
							name, _, _, _, _, _, _, _, _, icon = C_Item.GetItemInfo(slotLink)
						end
					end
					frame.actives[j] = {data = data, name = name, icon = icon, count = 9, start = 0, duration = 0, spid = data.spellID or data.slotID, sort = data.sort}
				end
				Filger.DisplayActives(frame)
			else
				for j = 1, #C["filger_spells"][T.class][i], 1 do
					local data = C["filger_spells"][T.class][i][j]
					if data.filter == "BUFF" or data.filter == "DEBUFF" or (data.filter == "ICD" and (data.trigger == "BUFF" or data.trigger == "DEBUFF")) then
						frame:RegisterEvent("UNIT_AURA")
					elseif data.filter == "CD" then
						frame:RegisterEvent("SPELL_UPDATE_COOLDOWN")
					elseif data.trigger == "NONE" then
						frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
					end
					if data.unitID == "target" then
						frame:RegisterEvent("PLAYER_TARGET_CHANGED")
					elseif data.unitID == "focus" then
						frame:RegisterEvent("PLAYER_FOCUS_CHANGED")
					end
				end
				frame:RegisterEvent("PLAYER_ENTERING_WORLD")
				frame:SetScript("OnEvent", Filger.OnEvent)
			end
		end
	end
end