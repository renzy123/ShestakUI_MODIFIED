local T, C, L = unpack(ShestakUI)
if C.skins.blizzard_frames ~= true then return end

----------------------------------------------------------------------------------------
--	Calendar skin
----------------------------------------------------------------------------------------
local function LoadSkin()
	local frames = {
		CalendarFrame,
		CalendarCreateEventFrame,
		CalendarCreateEventFrame.Header,
		CalendarCreateEventInviteList,
		CalendarCreateEventDescriptionContainer,
		CalendarCreateEventInviteListSection,
		CalendarTexturePickerFrame,
		CalendarTexturePickerFrame.Header,
		CalendarMassInviteFrame,
		CalendarMassInviteFrame.Header,
		CalendarViewRaidFrame,
		CalendarViewRaidFrame.Header,
		CalendarViewHolidayFrame.Header,
		CalendarViewEventFrame,
		CalendarViewEventFrame.Header,
		CalendarViewEventDescriptionContainer,
		CalendarViewEventInviteList,
		CalendarViewEventInviteListSection,
		CalendarEventPickerFrame,
		CalendarEventPickerFrame.Header
	}

	for _, frame in pairs(frames) do
		-- 3.80.1 时光服 Calendar 部分子 frame 可能不存在（如 CalendarViewRaidFrame.Header）
		if frame then frame:StripTextures() end
	end

	CalendarFrame:CreateBackdrop("Transparent")
	CalendarFrame.backdrop:SetPoint("TOPLEFT", 0, 0)
	CalendarFrame.backdrop:SetPoint("BOTTOMRIGHT", 0, -5)

	T.SkinCloseButton(CalendarCloseButton)

	T.SkinNextPrevButton(CalendarPrevMonthButton)
	T.SkinNextPrevButton(CalendarNextMonthButton)

	-- Dropdown button
	-- 3.80.1 时光服可能没有 CalendarFilterFrame（日历过滤下拉）
	do
		local frame = CalendarFilterFrame
		local button = CalendarFilterButton

		if frame and button then
			frame:StripTextures()
			frame:SetWidth(155)

			_G[frame:GetName().."Text"]:ClearAllPoints()
			_G[frame:GetName().."Text"]:SetPoint("RIGHT", button, "LEFT", -2, 0)

			button:ClearAllPoints()
			button:SetPoint("RIGHT", frame, "RIGHT", -10, 3)
			button.SetPoint = T.dummy

			T.SkinNextPrevButton(button)

			frame:CreateBackdrop("Default")
			frame.backdrop:SetPoint("TOPLEFT", 20, 2)
			frame.backdrop:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 2, -2)
		end
	end

	-- Backdrop
	local bg = CreateFrame("Frame", "CalendarFrameBackdrop", CalendarFrame)
	bg:SetTemplate("Default")
	bg:SetPoint("TOPLEFT", 10, -72)
	bg:SetPoint("BOTTOMRIGHT", -8, 3)

	-- 3.80.1 时光服 Calendar 可能没有 ContextMenu（右键菜单托管给了别的系统）
	if CalendarContextMenu and CalendarContextMenu.NineSlice then
		CalendarContextMenu.NineSlice:SetTemplate("Transparent")
	end
	if CalendarInviteStatusContextMenu and CalendarInviteStatusContextMenu.NineSlice then
		CalendarInviteStatusContextMenu.NineSlice:SetTemplate("Transparent")
	end

	-- Boost frame levels
	for i = 1, 42 do
		if _G["CalendarDayButton"..i] then
			_G["CalendarDayButton"..i]:SetFrameLevel(_G["CalendarDayButton"..i]:GetFrameLevel() + 1)
		end
	end

	-- CreateEventFrame
	-- 3.80.1 时光服 Calendar 是裁剪版，大量子 frame 可能不存在。下面所有调用都加 nil 检查。
	if CalendarCreateEventFrame then
		CalendarCreateEventFrame:SetTemplate("Transparent")
		CalendarCreateEventFrame:SetPoint("TOPLEFT", CalendarFrame, "TOPRIGHT", 3, 0)
	end

	if CalendarCreateEventCreateButton then CalendarCreateEventCreateButton:SkinButton(true) end
	if CalendarCreateEventMassInviteButton then CalendarCreateEventMassInviteButton:SkinButton(true) end
	if CalendarCreateEventInviteButton then
		CalendarCreateEventInviteButton:SkinButton(true)
		if CalendarCreateEventInviteEdit then
			CalendarCreateEventInviteButton:SetPoint("TOPLEFT", CalendarCreateEventInviteEdit, "TOPRIGHT", 4, 2)
		end
	end
	if CalendarCreateEventInviteEdit and CalendarCreateEventInviteList then
		CalendarCreateEventInviteEdit:SetPoint("TOPLEFT", CalendarCreateEventInviteList, "BOTTOMLEFT", 2, -3)
	end

	if CalendarCreateEventInviteList then CalendarCreateEventInviteList:SetTemplate("Overlay") end

	if CalendarCreateEventInviteEdit then
		T.SkinEditBox(CalendarCreateEventInviteEdit, CalendarCreateEventInviteEdit:GetWidth() - 2, CalendarCreateEventInviteEdit:GetHeight() - 2)
	end
	if CalendarCreateEventTitleEdit then
		T.SkinEditBox(CalendarCreateEventTitleEdit)
		if CalendarCreateEventTitleEdit.backdrop then
			CalendarCreateEventTitleEdit.backdrop:SetPoint("TOPLEFT", -3, 1)
			CalendarCreateEventTitleEdit.backdrop:SetPoint("BOTTOMRIGHT", -3, -1)
		end
	end
	if CalendarCreateEventTypeDropDown then T.SkinDropDownBox(CalendarCreateEventTypeDropDown, 120) end

	if CalendarCreateEventDescriptionContainer then CalendarCreateEventDescriptionContainer:SetTemplate("Overlay") end

	if CalendarCreateEventCloseButton then T.SkinCloseButton(CalendarCreateEventCloseButton) end
	if CalendarCreateEventLockEventCheck then T.SkinCheckBox(CalendarCreateEventLockEventCheck) end

	if CalendarCreateEventHourDropDown then T.SkinDropDownBox(CalendarCreateEventHourDropDown, 68) end
	if CalendarCreateEventMinuteDropDown then T.SkinDropDownBox(CalendarCreateEventMinuteDropDown, 68) end
	if CalendarCreateEventAMPMDropDown then T.SkinDropDownBox(CalendarCreateEventAMPMDropDown, 68) end
	if CalendarCreateEventDifficultyOptionDropDown then T.SkinDropDownBox(CalendarCreateEventDifficultyOptionDropDown) end
	if CalendarCreateEventIcon then
		CalendarCreateEventIcon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
		CalendarCreateEventIcon.SetTexCoord = T.dummy
	end

	if CalendarClassButtonContainer then
		CalendarClassButtonContainer:HookScript("OnShow", function()
			for i, class in ipairs(CLASS_SORT_ORDER) do
				local button = _G["CalendarClassButton"..i]
				if button then
					button:StripTextures()
					button:CreateBackdrop("Default")

					local tcoords = CLASS_ICON_TCOORDS[class]
					local buttonIcon = button:GetNormalTexture()
					if tcoords and buttonIcon then
						buttonIcon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
						buttonIcon:SetTexCoord(tcoords[1] + 0.015, tcoords[2] - 0.02, tcoords[3] + 0.018, tcoords[4] - 0.02)
					end
				end
			end

			if CalendarClassButton1 then
				CalendarClassButton1:SetPoint("TOPLEFT", CalendarClassButtonContainer, "TOPLEFT", 5, 0)
			end

			if CalendarClassTotalsButton then
				CalendarClassTotalsButton:StripTextures()
				CalendarClassTotalsButton:CreateBackdrop("Default")
			end
		end)
	end

	-- Texture Picker Frame
	if CalendarTexturePickerFrame then
		CalendarTexturePickerFrame:SetTemplate("Transparent")
		if CalendarTexturePickerFrame.ScrollBar then T.SkinScrollBar(CalendarTexturePickerFrame.ScrollBar) end
	end
	if CalendarTexturePickerAcceptButton then CalendarTexturePickerAcceptButton:SkinButton(true) end
	if CalendarTexturePickerCancelButton then CalendarTexturePickerCancelButton:SkinButton(true) end
	if CalendarCreateEventRaidInviteButton then CalendarCreateEventRaidInviteButton:SkinButton(true) end

	-- Mass Invite Frame
	if CalendarMassInviteFrame then
		CalendarMassInviteFrame:CreateBackdrop("Overlay")
	end
	if CalendarMassInviteCommunityDropDown then T.SkinDropDownBox(CalendarMassInviteCommunityDropDown, 190) end
	if CalendarMassInviteRankMenu then T.SkinDropDownBox(CalendarMassInviteRankMenu) end
	if CalendarMassInviteMinLevelEdit then T.SkinEditBox(CalendarMassInviteMinLevelEdit) end
	if CalendarMassInviteMaxLevelEdit then T.SkinEditBox(CalendarMassInviteMaxLevelEdit) end
	if CalendarMassInviteAcceptButton then CalendarMassInviteAcceptButton:SkinButton() end
	if CalendarMassInviteCloseButton then T.SkinCloseButton(CalendarMassInviteCloseButton) end
	if CalendarCreateEventCommunityDropDown then T.SkinDropDownBox(CalendarCreateEventCommunityDropDown, 240) end

	-- Raid View
	if CalendarViewRaidFrame then
		CalendarViewRaidFrame:SetTemplate("Transparent")
		CalendarViewRaidFrame:SetPoint("TOPLEFT", CalendarFrame, "TOPRIGHT", 3, 0)
	end
	if CalendarViewRaidCloseButton then T.SkinCloseButton(CalendarViewRaidCloseButton) end

	-- Holiday View
	if CalendarViewHolidayFrame then
		CalendarViewHolidayFrame:StripTextures(true)
		CalendarViewHolidayFrame:SetTemplate("Transparent")
		CalendarViewHolidayFrame:SetPoint("TOPLEFT", CalendarFrame, "TOPRIGHT", 3, 0)
	end
	if CalendarViewHolidayCloseButton then T.SkinCloseButton(CalendarViewHolidayCloseButton) end

	-- Event View
	if CalendarViewEventFrame then
		CalendarViewEventFrame:SetTemplate("Transparent")
		CalendarViewEventFrame:SetPoint("TOPLEFT", CalendarFrame, "TOPRIGHT", 3, 0)
	end
	if CalendarViewEventDescriptionContainer then CalendarViewEventDescriptionContainer:SetTemplate("Overlay") end
	if CalendarViewEventInviteList then CalendarViewEventInviteList:SetTemplate("Overlay") end
	if CalendarViewEventCloseButton then T.SkinCloseButton(CalendarViewEventCloseButton) end

	if CalendarEventPickerFrame then CalendarEventPickerFrame:SetTemplate("Transparent") end
	if CalendarEventPickerCloseButton then CalendarEventPickerCloseButton:SkinButton(true) end

	local buttons = {
		"CalendarViewEventAcceptButton",
		"CalendarViewEventTentativeButton",
		"CalendarViewEventRemoveButton",
		"CalendarViewEventDeclineButton"
	}

	for _, button in pairs(buttons) do
		if _G[button] then _G[button]:SkinButton() end
	end
end

T.SkinFuncs["Blizzard_Calendar"] = LoadSkin
