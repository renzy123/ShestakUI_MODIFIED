local T, C, L = unpack(ShestakUI)
if C.skins.details ~= true or not IsAddOnLoaded("Details") then return end

----------------------------------------------------------------------------------------
--	Details Skin — ShestakUI Pixel Style
--	Dark background, warm brown border, ShestakUI texture, Chinese font support
----------------------------------------------------------------------------------------

local FONT = C.media.normal_font
local TEXTURE = C.media.texture
local BORDER_R, BORDER_G, BORDER_B = unpack(C.media.border_color)
local BACKDROP_R, BACKDROP_G, BACKDROP_B = unpack(C.media.backdrop_color)

----------------------------------------------------------------------------------------
--	Post-hook: style new bars as they are created
----------------------------------------------------------------------------------------
hooksecurefunc(_detalhes.gump, "CreateNewLine", function(_, instancia, index)
	local bar = _G["DetailsBarra_"..instancia.meu_id.."_"..index]
	local icon = _G["DetailsBarra_IconFrame_"..instancia.meu_id.."_"..index]

	if bar and not bar.backdrop then
		bar:CreateBackdrop("Default")
		bar.backdrop:SetPoint("TOPLEFT", icon, -2, 2)

		bar.bg = bar:CreateTexture(nil, "BORDER")
		bar.bg:SetAllPoints(bar)
		bar.bg:SetTexture(TEXTURE)
		bar.bg:SetVertexColor(0.15, 0.15, 0.15, 0.25)

		-- Icon cropping handled by skin icon_file setting
	end

	-- Style the title bar frame
	local frame = _G["DetailsUpFrameInstance"..instancia.meu_id]
	if frame and not frame.b then
		frame.b = CreateFrame("Frame", nil, frame:GetParent())
		frame.b:SetTemplate("Overlay")
		frame.b:SetPoint("TOPLEFT", frame, "TOPLEFT", -23, 2)
		frame.b:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 34, 4)
		frame.b:SetFrameLevel(frame:GetFrameLevel() - 1)
	end
end)

----------------------------------------------------------------------------------------
--	Font fix: replace ShestakUI pixel font in font outline callback
----------------------------------------------------------------------------------------
hooksecurefunc(_detalhes, "SetFontOutline", function(_, fontString)
	local fonte, size = fontString:GetFont()
	if fonte and fonte:find("ShestakUI") then
		fontString:SetFont(FONT, size, "OUTLINE")
		if fontString.GetShadowColor then
			fontString:SetShadowColor(0, 0, 0, 0)
		end
	end
end)

----------------------------------------------------------------------------------------
--	Skin Table — ShestakUI Pixel Style
----------------------------------------------------------------------------------------
local skinTable = {
	file = [[Interface\AddOns\Details\images\skins\simplygray_skin.blp]],
	author = "ShestakUI",
	version = "2.0",
	site = "unknown",
	desc = "ShestakUI Pixel Style — dark theme with warm brown borders and custom texture.",

	-- Micro display frames (bottom status bar plugins)
	micro_frames = {
		color = {0.85, 0.85, 0.85, 1},
		font = FONT,
		size = 12,
		textymod = 1,
	},

	can_change_alpha_head = true,

	-- Icon anchoring
	icon_anchor_main = {-1, -5},
	icon_anchor_plugins = {-7, -13},
	icon_plugins_size = {19, 18},

	-- Toolbar anchors (top side)
	icon_point_anchor = {-37, 0},
	left_corner_anchor = {-107, 0},
	right_corner_anchor = {96, 0},

	-- Toolbar anchors (bottom side)
	icon_point_anchor_bottom = {-37, 12},
	left_corner_anchor_bottom = {-107, 0},
	right_corner_anchor_bottom = {96, 0},

	icon_on_top = true,
	icon_ignore_alpha = true,
	icon_titletext_position = {3, 3},

	-- Instance property overwrites
	instance_cprops = {
		["show_statusbar"] = false,
		["menu_icons_size"] = 0.85,

		-- Title bar color: dark with warm brown tint matching C.media.border_color
		["color"] = {BORDER_R, BORDER_G, BORDER_B, 0.95},

		["menu_anchor"] = {16, 6, ["side"] = 2},
		["menu_anchor_down"] = {16, -3},

		-- Background: near-black
		["bg_r"] = 0.04,
		["bg_g"] = 0.04,
		["bg_b"] = 0.04,
		["bg_alpha"] = 0.85,

		["color_buttons"] = {1, 1, 1, 1},
		["skin_custom"] = "",
		["micro_displays_locked"] = true,

		-- Row animation
		["row_show_animation"] = {["anim"] = "Fade", ["options"] = {}},

		-- Tooltip
		["tooltip"] = {["n_abilities"] = 3, ["n_enemies"] = 3},

		-- Total bar
		["total_bar"] = {
			["enabled"] = false,
			["only_in_group"] = true,
			["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
			["color"] = {1, 1, 1},
		},

		["show_sidebars"] = false,
		["instance_button_anchor"] = {-27, 1},

		-- Bar layout — ShestakUI signature: compact rows with custom texture
		["row_info"] = {
			["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
			["use_spec_icons"] = true,

			-- Font: C.media.normal_font for Chinese, OUTLINE no shadow
			["font_face"] = FONT,
			["font_face_file"] = FONT,
			["font_size"] = 12,
			["font_shadow"] = "OUTLINE",

			-- Text outlines
			["textL_outline"] = true,
			["textR_outline"] = true,
			["textL_outline_small"] = false,
			["textR_outline_small"] = false,

			-- Text colors: white, no per-text class coloring
			["fixed_text_color"] = {1, 1, 1},
			["textL_class_colors"] = false,
			["textR_class_colors"] = false,

			-- Data display
			["textL_show_number"] = true,
			["textL_enable_custom_text"] = false,
			["textL_custom_text"] = "{data1}. {data3}{data2}",
			["textR_show_data"] = {true, true, true},
			["textR_enable_custom_text"] = false,
			["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
			["textR_bracket"] = "(",
			["textR_separator"] = ",",

			-- Bar dimensions — ShestakUI standard: height 14, spacing 7
			["height"] = 14,
			["alpha"] = 1,
			["no_icon"] = false,
			["percent_type"] = 1,

			-- Spacing between bars
			["space"] = {["right"] = 0, ["left"] = 0, ["between"] = 7},

			-- ShestakUI custom texture for bars
			["texture"] = "Smooth!",
			["texture_file"] = TEXTURE,
			["texture_custom"] = TEXTURE,
			["texture_class_colors"] = true,
			["texture_background"] = "Smooth!",
			["texture_background_file"] = TEXTURE,
			["texture_background_class_color"] = false,
			["fixed_texture_color"] = {0, 0, 0},
			["fixed_texture_background_color"] = {0, 0, 0, 0.25},

			-- Highlight
			["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",

			-- Icon
			["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["start_after_icon"] = true,

			-- Bar border (disabled — we add our own via CreateBackdrop hook)
			["backdrop"] = {
				["enabled"] = false,
				["size"] = 12,
				["color"] = {1, 1, 1, 1},
				["texture"] = "Details BarBorder 2",
			},

			-- 3D models disabled
			["models"] = {
				["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
				["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
				["upper_alpha"] = 0.5,
				["lower_enabled"] = false,
				["lower_alpha"] = 0.1,
				["upper_enabled"] = false,
			},

			["fast_ps_update"] = false,
		},

		-- Following bar (disabled)
		["following"] = {
			["bar_color"] = {1, 1, 1},
			["enabled"] = false,
			["text_color"] = {1, 1, 1},
		},

		-- Plugins
		["plugins_grow_direction"] = 1,
		["toolbar_side"] = 1,
		["grab_on_top"] = false,

		-- Menu icons
		["menu_icons"] = {
			true, true, true, true, true, false,
			["space"] = -2,
			["shadow"] = false,
		},
		["desaturated_menu"] = false,

		-- Menu alpha (no hover effect)
		["menu_alpha"] = {
			["enabled"] = false,
			["onleave"] = 1,
			["ignorebars"] = false,
			["iconstoo"] = true,
			["onenter"] = 1,
		},

		["auto_hide_menu"] = {["left"] = false, ["right"] = false},
		["micro_displays_side"] = 2,

		-- Status bar
		["statusbar_info"] = {
			["alpha"] = 0.7,
			["overlay"] = {0.08, 0.08, 0.08},
		},

		-- Strata & grow direction
		["strata"] = "LOW",
		["bars_grow_direction"] = 1,
		["bars_sort_direction"] = 1,

		-- Backdrop texture
		["backdrop_texture"] = "Details Ground",

		-- Window scale
		["window_scale"] = 1,

		-- Hide the large icon in top-left
		["hide_icon"] = true,

		-- Combat settings
		["hide_out_of_combat"] = false,
		["hide_in_combat_alpha"] = 0,
		["ignore_mass_showhide"] = false,

		-- Wallpaper disabled
		["wallpaper"] = {
			["enabled"] = false,
			["texcoord"] = {0, 1, 0, 0.7},
			["overlay"] = {1, 1, 1, 1},
			["anchor"] = "all",
			["height"] = 114,
			["alpha"] = 0.5,
			["width"] = 283,
		},

		["stretch_button_side"] = 1,

		-- Attribute text (the mode label like "Damage", "Healing")
		["attribute_text"] = {
			["enabled"] = true,
			["shadow"] = false,
			["side"] = 1,
			["text_size"] = 12,
			["custom_text"] = "{name}",
			["text_face"] = FONT,
			["anchor"] = {-19, 9},
			["text_color"] = {1, 1, 1, 1},
			["enable_custom_text"] = false,
			["show_timer"] = {true, true, true},
		},
	},
}

_detalhes:InstallSkin("ShestakUI Pixel", skinTable)

----------------------------------------------------------------------------------------
--	Apply skin to existing instances at load time
----------------------------------------------------------------------------------------
local lower_instance = _detalhes:GetLowerInstanceNumber()
if lower_instance then
	for i = lower_instance, #_detalhes.tabela_instancias do
		local instance = Details:GetInstance(i)
		if instance and instance.rows_fit_in_window then
			-- Add backdrops and crop icons on existing bars
			for j = 1, instance.rows_fit_in_window do
				local bar = _G["DetailsBarra_Statusbar_"..i.."_"..j]
				local icon = _G["DetailsBarra_IconFrame_"..i.."_"..j]
				if bar and not bar.backdrop then
					bar:CreateBackdrop("Default")
					bar.backdrop:SetPoint("TOPLEFT", icon, -2, 2)

					bar.bg = bar:CreateTexture(nil, "BORDER")
					bar.bg:SetAllPoints(bar)
					bar.bg:SetTexture(TEXTURE)
					bar.bg:SetVertexColor(0.15, 0.15, 0.15, 0.25)
				end
				-- Icon crop handled by skin icon_file, not SetTexCoord on frame
			end

			-- Style title bar frame
			local frame = _G["DetailsUpFrameInstance"..i]
			if frame and not frame.b then
				frame.b = CreateFrame("Frame", nil, frame:GetParent())
				frame.b:SetTemplate("Overlay")
				frame.b:SetPoint("TOPLEFT", frame, "TOPLEFT", -23, 2)
				frame.b:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 34, 4)
				frame.b:SetFrameLevel(frame:GetFrameLevel() - 1)
			end

			instance:ChangeSkin("ShestakUI Pixel")
		end
	end
end
